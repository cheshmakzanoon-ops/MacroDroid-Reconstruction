Unrelated checkout root content; fixture only
