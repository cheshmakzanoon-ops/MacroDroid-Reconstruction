#!/usr/bin/env python3
"""Independently check fresh full-host results before labeling the WIP build accepted."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import math
from pathlib import Path
import re
import shutil
import stat
import sys
import zipfile

import inputs

JVM_FLAGS = ('-XX:-OmitStackTraceInFastThrow', '-XX:+ShowCodeDetailsInExceptionMessages')
NUMERIC_METHOD = ('Lcom/arlosoft/macrodroid/triggers/DayTrigger;->r0('
                  'Lcom/arlosoft/macrodroid/variables/VariableValue$DictionaryEntry;)I')


def count(value, expected, message):
    inputs.require(type(value) is int and value == expected, message)


def flags(value, expected, message):
    inputs.require(all(value.get(key) is wanted for key, wanted in expected.items()), message)


def epoch_ns(value):
    inputs.require(isinstance(value, str), 'Missing timestamp')
    parsed = datetime.fromisoformat(value)
    inputs.require(parsed.tzinfo is not None, 'Timestamp lacks timezone')
    delta = parsed - datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (delta.days * 86400 + delta.seconds) * 1_000_000_000 + delta.microseconds * 1000


class Artifacts:
    """Every result path is canonical, fresh, and physically distinct from other paths."""
    def __init__(self, root, started_ns, ended_ns):
        self.root = Path(root)
        self.started_ns, self.ended_ns = started_ns, ended_ns
        self.rows, self.physical = {}, {}

    def path(self, name):
        path = inputs.regular(self.root, name)
        status = path.stat()
        inputs.require(self.started_ns <= status.st_mtime_ns <= self.ended_ns
                       and self.started_ns <= status.st_ctime_ns <= self.ended_ns,
                       'Result is outside the actual execution interval: ' + name)
        key = (status.st_dev, status.st_ino)
        inputs.require(key not in self.physical or self.physical[key] == name,
                       'One physical result file represents multiple artifacts: ' + name)
        row = {'path': name, **inputs.identity(path), 'device': status.st_dev, 'inode': status.st_ino,
               'mtime_ns': status.st_mtime_ns, 'ctime_ns': status.st_ctime_ns,
               'mode': status.st_mode, 'links': status.st_nlink}
        inputs.require(name not in self.rows or self.rows[name] == row, 'Result changed during verification: ' + name)
        self.rows[name] = row
        self.physical[key] = name
        return path

    def raw(self, name):
        raw = self.path(name).read_bytes()
        inputs.require(inputs.byte_identity(raw) == {k: self.rows[name][k] for k in ('bytes', 'sha256')},
                       'Result changed while reading: ' + name)
        return raw

    def json(self, name):
        return inputs.document(self.raw(name))

    def hash(self, name, expected):
        self.path(name)
        inputs.require(self.rows[name]['sha256'] == expected, 'Recorded result hash differs: ' + name)


def checked_clock(value, role):
    inputs.require(isinstance(value, dict) and set(value) == {'unix_ns', 'monotonic_ns', 'utc'},
                   'Exact clock fields differ: ' + role)
    inputs.require(type(value['unix_ns']) is int and value['unix_ns'] > 0
                   and type(value['monotonic_ns']) is int and value['monotonic_ns'] > 0,
                   'Missing exact integer clocks: ' + role)
    seconds, fraction = divmod(value['unix_ns'], 1_000_000_000)
    expected = datetime.fromtimestamp(seconds, timezone.utc).replace(microsecond=fraction // 1000).isoformat(timespec='microseconds')
    inputs.require(value['utc'] == expected, 'ISO text is not the exact integer-clock truncation: ' + role)
    return value


def row_clock(row, prefix, role):
    return checked_clock({'unix_ns': row.get(prefix + '_unix_ns'),
                          'monotonic_ns': row.get(prefix + '_monotonic_ns'),
                          'utc': row.get(prefix + '_utc')}, role)


def clocks_ordered(first, second, role, strict=False):
    for name in ('unix_ns', 'monotonic_ns'):
        inputs.require(first[name] < second[name] if strict else first[name] <= second[name],
                       'Command clocks reverse or escape their ordered operation: ' + role)


def checked_stat(value, role):
    fields = {'device', 'inode', 'mode', 'links', 'bytes', 'mtime_ns', 'ctime_ns'}
    inputs.require(isinstance(value, dict) and set(value) == fields
                   and all(type(value[key]) is int for key in fields), 'Exact filesystem stat fields differ: ' + role)
    inputs.require(value['device'] > 0 and value['inode'] > 0 and stat.S_ISREG(value['mode'])
                   and value['links'] == 1 and value['bytes'] >= 0
                   and value['mtime_ns'] > 0 and value['ctime_ns'] > 0,
                   'File is not one owned regular inode: ' + role)
    return value


def verify_file_creation(receipt, name, artifacts, witness=False):
    """Check recorded creation against the live host file, not extracted ZIP stats."""
    fields = {'path', 'exclusive_mode', 'open_started', 'initial_stat', 'initial_sha256', 'opened',
              'closing', 'final_stat', 'closed', 'bytes', 'sha256', 'hashed'}
    inputs.require(isinstance(receipt, dict) and set(receipt) == fields
                   and receipt.get('path') == name and receipt.get('exclusive_mode') == 'xb',
                   'Exclusive file role or creation receipt differs: ' + name)
    clocks = [checked_clock(receipt[stage], name + ':' + stage)
              for stage in ('open_started', 'opened', 'closing', 'closed', 'hashed')]
    for first, second in zip(clocks, clocks[1:]):
        clocks_ordered(first, second, name)
    initial = checked_stat(receipt['initial_stat'], name + ':initial')
    final = checked_stat(receipt['final_stat'], name + ':final')
    inputs.require(initial['bytes'] == 0 and receipt['initial_sha256'] == hashlib.sha256(b'').hexdigest()
                   and initial['mtime_ns'] == initial['ctime_ns'], 'Exclusive file was not initially empty: ' + name)
    inputs.require(all(initial[key] == final[key] for key in ('device', 'inode', 'mode', 'links')),
                   'Exclusive file inode ownership changed: ' + name)
    inputs.require(initial['mtime_ns'] <= final['mtime_ns'] and initial['ctime_ns'] <= final['ctime_ns'],
                   'File metadata predates its recorded exclusive creation: ' + name)
    artifacts.hash(name, receipt['sha256'])
    actual = artifacts.rows[name]
    inputs.require({key: actual[key] for key in final} == final,
                   'Live file differs from the recorded final fstat: ' + name)
    count(receipt['bytes'], final['bytes'], 'Final stream byte count differs')
    if witness:
        inputs.require(initial == final and final['bytes'] == 0
                       and receipt['sha256'] == hashlib.sha256(b'').hexdigest(),
                       'Filesystem witness was written, changed or substituted: ' + name)
    return receipt


def verify_command_stream_evidence(row, prefix, label, artifacts):
    value = row.get('stream_evidence')
    fields = {'schema', 'started', 'streams', 'after_witnesses', 'after_witness_attempt_limit',
              'after_witness_poll_ns', 'filesystem_bracket_complete', 'before_witness',
              'invocation_started', 'invocation_finished', 'finished'}
    inputs.require(isinstance(value, dict) and set(value) == fields,
                   'Missing, partial or additional command creation evidence: ' + label)
    count(value['schema'], 2, 'Command creation evidence schema differs')
    count(value['after_witness_attempt_limit'], 16, 'Filesystem witness attempt bound differs')
    count(value['after_witness_poll_ns'], 5_000_000, 'Filesystem witness polling bound differs')
    inputs.require(value['filesystem_bracket_complete'] is True, 'Actual filesystem bracket did not complete')
    start = checked_clock(value['started'], label + ':start')
    end = checked_clock(value['finished'], label + ':finish')
    clocks_ordered(start, end, label, strict=True)
    inputs.require(row_clock(row, 'started', label) == start and row_clock(row, 'ended', label) == end,
                   'Command timestamps differ from its stream-creation evidence')
    inputs.require(type(row.get('duration_seconds')) in (int, float)
                   and math.isfinite(row['duration_seconds'])
                   and row['duration_seconds'] == (end['monotonic_ns'] - start['monotonic_ns']) / 1_000_000_000,
                   'Command duration differs from its exact monotonic interval')
    prefix = prefix + '/' if prefix else ''
    before = verify_file_creation(value['before_witness'], prefix + label + '.filesystem-before.log', artifacts, True)
    clocks_ordered(start, before['open_started'], label + ':before-witness')
    inputs.require(isinstance(value['streams'], dict) and set(value['streams']) == {'stdout', 'stderr'},
                   'Exclusive command stream inventory differs')
    previous = before['hashed']
    receipts = []
    for stream in ('stdout', 'stderr'):
        name = prefix + label + '.' + stream + '.log'
        receipt = verify_file_creation(value['streams'][stream], name, artifacts)
        inputs.require(row.get(stream) == {key: receipt[key] for key in ('path', 'bytes', 'sha256')},
                       'Command reused, renamed or substituted another stream: ' + name)
        clocks_ordered(previous, receipt['open_started'], name + ':open')
        previous = receipt['opened']
        receipts.append(receipt)
    invocation_start = checked_clock(value['invocation_started'], label + ':invocation-start')
    invocation_end = checked_clock(value['invocation_finished'], label + ':invocation-end')
    clocks_ordered(previous, invocation_start, label + ':invoke')
    clocks_ordered(invocation_start, invocation_end, label + ':return')
    previous = invocation_end
    for receipt in reversed(receipts):
        clocks_ordered(previous, receipt['closing'], receipt['path'] + ':close')
        previous = receipt['hashed']
    witnesses = value['after_witnesses']
    inputs.require(isinstance(witnesses, list) and 1 <= len(witnesses) <= 16, 'After-witness inventory differs')
    for index, witness in enumerate(witnesses):
        witness = verify_file_creation(witness, prefix + label + f'.filesystem-after-{index:02d}.log', artifacts, True)
        clocks_ordered(previous, witness['open_started'], label + ':after-witness')
        if index:
            inputs.require(witness['open_started']['monotonic_ns'] - previous['monotonic_ns'] >= 5_000_000,
                           'After-witness retry omitted its recorded polling interval')
        previous = witness['hashed']
        floor, ceiling = before['final_stat'], witness['final_stat']
        complete = all(floor['device'] == observed['device'] == ceiling['device']
            and floor['ctime_ns'] <= observed['mtime_ns'] <= ceiling['ctime_ns']
            and floor['ctime_ns'] <= observed['ctime_ns'] <= ceiling['ctime_ns']
            for receipt in receipts for observed in (receipt['initial_stat'], receipt['final_stat']))
        inputs.require(complete is (index == len(witnesses) - 1),
                       'Witness inventory did not stop at the first actual filesystem bracket')
    clocks_ordered(previous, end, label + ':complete')
    return start, end


def verify_execution(execution, prepared, pins):
    flags(execution, {'passed': True, 'build_inputs_unchanged': True, 'active_promoted': False,
                      'android_runtime_executed': False, 'full_runtime_1_to_1_established': False},
          'Execution wrapper did not complete exactly')
    inputs.require(execution.get('status') == 'HOST_ACCEPTANCE_PROCESS_EXITED_ZERO'
                   and 'error' not in execution and execution.get('project') == prepared['project'],
                   'Wrong wrapper result or project')
    inputs.require(execution.get('input_snapshot_before') == execution.get('input_snapshot_after') == pins['future_snapshot'],
                   'Wrapper input identity differs')
    child = execution.get('execution', {})
    count(child.get('returncode'), 0, 'Acceptance process did not exit zero')
    inputs.require(execution.get('python_executable') == sys.executable
                   and execution.get('python_executable_identity') == inputs.identity(Path(sys.executable).resolve(strict=True)),
                   'Acceptance Python executable differs from the actual verifier runtime')
    count(child.get('timeout_seconds'), pins['acceptance_timeout_seconds'], 'Overall acceptance bound differs')
    inputs.require(child.get('timed_out') is False and 'error' not in child
                   and child.get('argv') == [execution['python_executable'], '-B', 'acceptance.py']
                   and child.get('cwd') == prepared['project'], 'Acceptance invocation differs')
    start, end = child.get('started_unix_ns'), child.get('ended_unix_ns')
    inputs.require(type(start) is int and type(end) is int and 0 < start < end,
                   'Missing actual execution interval')
    return start, end


def verify_wrapper_streams(execution, prepared, output):
    """Bind outer streams to exact live files and separately ordered integer clocks."""
    count(execution.get('schema'), 2, 'Wrapper creation-evidence schema differs')
    beginning = row_clock(execution, 'started', 'wrapper-start')
    completion = row_clock(execution, 'finished', 'wrapper-finish')
    clocks_ordered(beginning, completion, 'wrapper', strict=True)
    versions = execution.get('java_versions')
    inputs.require(isinstance(versions, list) and len(versions) == 2, 'Java observation inventory differs')
    expected = [('java-version', ['java', '-version'], versions[0], 15),
                ('javac-version', ['javac', '-version'], versions[1], 15),
                ('acceptance', [sys.executable, '-B', 'acceptance.py'], execution['execution'], None)]
    last = execution['execution'].get('stream_evidence', {}).get('after_witnesses')
    inputs.require(isinstance(last, list) and 1 <= len(last) <= 16, 'Missing final wrapper filesystem witness')
    # These bounds come from the live expected witness files. Their recorded
    # identity and actual exclusive-open operation are checked below as well.
    first_path = inputs.regular(output, 'java-version.filesystem-before.log')
    final_path = inputs.regular(output, f'acceptance.filesystem-after-{len(last)-1:02d}.log')
    artifacts = Artifacts(output, first_path.stat().st_ctime_ns, final_path.stat().st_ctime_ns)
    previous = beginning
    for label, argv, row, timeout in expected:
        inputs.require(row.get('argv') == argv and row.get('cwd') == prepared['project']
                       and row.get('timed_out') is False and 'error' not in row,
                       'Outer child invocation or outcome differs: ' + label)
        count(row.get('returncode'), 0, 'Outer child did not exit zero: ' + label)
        if timeout is not None:
            count(row.get('timeout_seconds'), timeout, 'Java observation timeout differs')
        start, end = verify_command_stream_evidence(row, '', label, artifacts)
        clocks_ordered(previous, start, 'outer child:' + label)
        clocks_ordered(end, completion, 'outer completion:' + label)
        previous = end
    return sorted(artifacts.rows.values(), key=lambda row: row['path'])

def verify_gates(latest, execution, pins, artifacts):
    flags(latest, {'host_acceptance_passed': True, 'source_edit_probe_skipped': False,
                   'build_inputs_unchanged': True, 'android_runtime_executed': False,
                   'full_runtime_1_to_1_established': False, 'complete_high_level_java_kotlin_source': False},
          'Incomplete or out-of-scope acceptance result')
    count(latest.get('input_files'), pins['future_snapshot']['files'], 'Acceptance input count differs')
    inputs.require(latest.get('input_snapshot_before') == latest.get('input_snapshot_after') == pins['future_snapshot']['snapshot_sha256']
                   and 'failure' not in latest and 'remaining_not_executed' not in latest, 'Acceptance source or completion differs')
    inputs.require(artifacts.started_ns <= epoch_ns(latest.get('started_utc')) <= epoch_ns(latest.get('finished_utc')) <= artifacts.ended_ns,
                   'Acceptance report is outside the invocation interval')
    commands = latest.get('commands')
    inputs.require(isinstance(commands, list) and len(commands) == 16, 'Missing full gate inventory')
    folder = str(inputs.relative(commands[0]['log']).parent)
    inputs.require(re.fullmatch(r'reports/acceptance-[0-9]{8}T[0-9]{12}Z', folder), 'Unexpected acceptance result directory')
    actual_folders = sorted(path.relative_to(artifacts.root).as_posix() for path in (artifacts.root / 'reports').glob('acceptance-*') if path.is_dir())
    inputs.require(actual_folders == [folder], 'Missing, additional, or historical acceptance directory')
    inputs.require(artifacts.raw(folder + '/result.json') == artifacts.raw('reports/acceptance-latest.json'),
                   'Latest and session result bytes differ')
    for index, (row, expected) in enumerate(zip(commands, pins['gate_commands']), 1):
        label, arguments = expected
        inputs.require(row.get('label') == label and row.get('command') == [execution['python_executable'], *arguments],
                       'Gate order or exact command differs')
        inputs.require(row.get('log') == f'{folder}/{index:02d}-{label}.log', 'Gate reused or renamed another log')
        count(row.get('exit_code'), 0, 'A required gate did not exit zero')
        count(row.get('timeout_seconds'), 5400 if label == 'ui-negative-controls' else 1200, 'Per-gate bound differs')
        inputs.require(row.get('passed') is True and 'error' not in row
                       and type(row.get('seconds')) in (int, float) and math.isfinite(row['seconds']) and row['seconds'] >= 0,
                       'Malformed or failed gate outcome')
        artifacts.hash(row['log'], row['log_sha256'])
    hashes = latest.get('fresh_evidence_sha256')
    inputs.require(isinstance(hashes, dict) and set(hashes) == set(pins['fresh_reports']) and len(hashes) == 24,
                   'Missing or additional fresh acceptance report')
    reports = {}
    for name in pins['fresh_reports']:
        artifacts.hash('reports/' + name, hashes[name])
        reports[name] = artifacts.json('reports/' + name)
    return reports


def verify_python(raw, expected):
    text = raw.decode('utf-8')
    summaries = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', text, re.M)
    headers = re.findall(r'^test_\S+ \(.*\) \.\.\. ', text, re.M)
    successes = re.findall(r'(?:\.\.\. |^)ok$', text, re.M)
    inputs.require(len(summaries) == 1 and int(summaries[0][0]) == expected
                   and len(headers) == len(successes) == expected and text.rstrip().endswith('\nOK'),
                   'Python success count is incomplete or includes skips/failures')
    return {'tests': expected, 'individual_successes': len(successes), 'seconds': float(summaries[0][1])}


def verify_apks(latest, pins, artifacts, reports):
    rows = latest.get('apks')
    inputs.require(isinstance(rows, dict) and set(rows) == {'baseline', 'hybrid'}, 'Missing actual APK inventory')
    actual = {}
    for variant in ('baseline', 'hybrid'):
        row = rows[variant]
        name = f'dist/MacroDroid-5.67.8-v9-{variant}.apk'
        inputs.require(row.get('path') == name, 'Unexpected APK path')
        value = inputs.identity(artifacts.path(name))
        inputs.require(value == {k: row[k] for k in ('bytes', 'sha256')}, 'Actual APK identity differs from acceptance')
        if variant == 'baseline':
            inputs.require(value == pins['baseline_apk'], 'Unchanged baseline APK did not reproduce')
        else:
            inputs.require(value != pins['previous_active_apk'], 'Numeric method did not change the old hybrid artifact')
        built = artifacts.json('reports/' + variant + '-build.json')
        inputs.require(built.get('variant') == variant and built.get('apk') == name
                       and built.get('bytes') == value['bytes'] and built.get('sha256') == value['sha256'], 'Build/APK result differs')
        flags(built, {'original_apk_build_input': False, 'original_dex_build_input': False}, 'Original APK/DEX became an application build input')
        count(built.get('source_dex_partitions'), 9, 'Application DEX partition count differs')
        for suffix in ('-roundtrip.json', '-resource-parity.json'):
            report = reports[variant + suffix]
            inputs.require(report.get('pass') is True and report.get('variant') == variant
                           and report.get('apk_sha256') == value['sha256'], 'APK code/resource report is misbound')
        actual[variant] = value
    return actual


def verify_suite_scope(name, report):
    if name == 'engine':
        # The unchanged EngineParityTests report uses these exact scope/selection
        # fields rather than emitting an androidRuntime field. Do not generalize
        # that omission to other suites, or accept a contradictory explicit flag.
        inputs.require(report.get('scope') == 'Original selected DEX / recovered Java / rebuilt DEX, with controlled Android/action/store/clock/thread boundaries; not Android runtime'
                       and report.get('selection') == 'all'
                       and ('androidRuntime' not in report or report['androidRuntime'] is False),
                       'Engine report changed its exact host scope or selection')
    else:
        inputs.require(report.get('androidRuntime') is False, 'Suite omitted its explicit host-only runtime flag: ' + name)


def verify_registry_and_partition(project, pins, apk, reports, artifacts):
    registry = inputs.read_json(inputs.regular(project, 'source/java-method-map.json'))
    keys = [row['target'] + '->' + row['method'] for row in registry]
    inputs.require(len(keys) == len(set(keys)) == pins['registered_methods']
                   and len({row['target'] for row in registry}) == pins['target_classes'], 'Registry count, class count, or uniqueness differs')
    fixture = inputs.identity(inputs.regular(project, 'tests/fixtures/original-methods.dex'))
    inputs.require(fixture == pins['fixture'], 'Test-only original fixture differs')
    provenance = inputs.read_json(inputs.regular(project, 'tests/fixtures/provenance.json'))
    for key, expected in [('methods', pins['fixture_methods']), ('classes', pins['fixture_classes']),
                          ('registered_methods', pins['registered_methods']), ('dependency_methods', pins['original_dependency_methods'])]:
        count(provenance.get(key), expected, 'Fixture registration/dependency credit differs')
    inputs.require(provenance.get('original_apk_sha256') == pins['original_apk_sha256']
                   and provenance.get('fixture_sha256') == fixture['sha256'], 'Fixture provenance differs')
    all_path = reports['java-all-path-parity.json']
    flags(all_path, {'passed': True, 'schemaValid': True, 'androidRuntime': False,
                     'exactMethodKeyPartitionVerified': True, 'rebuiltDexComparedToApk': True}, 'All-path host report is incomplete')
    for key, expected in [('cases', pins['all_cases']), ('methodsCovered', pins['registered_methods']), ('methodsExpected', pins['registered_methods']),
                          ('paths', 3), ('failedCases', 0), ('unsupportedExecutions', 0)]:
        count(all_path.get(key), expected, 'All-path count differs: ' + key)
    inputs.require(all_path.get('suiteCases') == pins['suite_cases'] and all_path.get('apkSha256') == apk
                   and all_path.get('fixtureSha256') == fixture['sha256'], 'All-path source/APK or case partition differs')
    suites, flat = {}, []
    for name, stem in [('legacy', 'java'), ('core', 'java-core'), ('environment', 'java-environment'), ('engine', 'java-engine'), ('ui', 'java-ui')]:
        report = artifacts.json(f'reports/{stem}-three-path-parity.json')
        count(report.get('cases'), pins['suite_cases'][name], 'Suite case count differs: ' + name)
        count(report.get('paths'), 3, 'Suite did not execute all three paths')
        count(report.get('failedCases', report.get('failures')), 0, 'Suite has failures')
        count(report.get('unsupportedExecutions'), 0, 'Suite has unsupported execution')
        verify_suite_scope(name, report)
        inputs.require(report.get('passed', report.get('pass')) is True
                       and report.get('fixture_sha256') == fixture['sha256'] and report.get('rebuilt_apk_sha256') == apk
                       and report.get('rebuilt_dex_compared_to_apk') is True, 'Suite identity or scoped result differs')
        selected = report.get('methodKeys')
        inputs.require(isinstance(selected, list) and all(isinstance(key, str) for key in selected)
                       and len(selected) == len(set(selected)), 'Suite method inventory is invalid')
        count(report.get('methodsCovered'), len(selected), 'Suite method count differs from its inventory')
        flat += selected
        suites[name] = report
    inputs.require(len(flat) == len(set(flat)) == pins['registered_methods'] and set(flat) == set(keys), 'Executed method keys do not exactly partition the registry')
    hybrid = reports['hybrid-roundtrip.json']
    changed = [row[0] + '->' + row[1] for row in hybrid.get('changed_methods', [])]
    inputs.require(len(changed) == len(set(changed)) == pins['registered_methods'] and set(changed) == set(keys)
                   and len(hybrid.get('changed_classes', [])) == 605
                   and set(hybrid.get('changed_classes', [])) == {row['target'] for row in registry}, 'Signed APK change inventory differs from the registered source delta')
    for report in (hybrid, reports['baseline-roundtrip.json']):
        for field in ('baseline_source_hash_mismatches', 'missing', 'extra', 'unexpected_changed_methods',
                      'omitted_registered_changes', 'altered_opaque_payload', 'misaligned'):
            inputs.require(report.get(field) == [], 'Code roundtrip has an unexplained difference: ' + field)
        count(report.get('classes_compared'), 71267, 'Code roundtrip omitted classes')
        count(report.get('methods_total'), 349972, 'Code roundtrip omitted methods')
    inputs.require(reports['baseline-roundtrip.json'].get('changed_methods') == []
                   and reports['baseline-roundtrip.json'].get('changed_classes') == [], 'Baseline code changed')
    return suites


def retain_class(project, relative_path, output, retained):
    path = inputs.regular(project, relative_path)
    value = inputs.identity(path)
    if relative_path in retained:
        inputs.require(retained[relative_path]['identity'] == value, 'A retained runtime class changed')
        return
    target = output / 'runtime-classes' / relative_path
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(path.read_bytes())
    inputs.require(inputs.identity(target) == value, 'Retained runtime class bytes differ')
    retained[relative_path] = {'source_path': relative_path,
                               'retained_path': target.relative_to(output).as_posix(), 'identity': value}


def verify_combined_ui_inventory(pins, rows):
    wanted = pins['ui_mutation_inventory']
    inputs.require(len(wanted) == 101 and wanted[:91] == pins['numeric_ui_mutation_inventory']
                   and all(row['name'].startswith('day-lookup-') for row in wanted[91:]),
                   'Frozen combined UI catalog or unchanged 91-control prefix differs')
    inputs.require(isinstance(rows, list) and len(rows) == 101
                   and [row.get('mutation') for row in rows] == [row['name'] for row in wanted],
                   'UI fault inventory or order differs')
    return wanted


def verify_ui_controls(project, pins, report, ui, artifacts, output, retained):
    flags(report, {'pass': True, 'positiveRestorationPassed': True, 'positiveRestorationExactBaseline': True,
                   'sourceFixtureAndApkUnchanged': True, 'dayNumericDexControlsPassed': True, 'dayLookupDexControlsPassed': True, 'androidRuntime': False},
          'UI fault controls or exact restoration did not pass')
    inputs.require(report.get('status') == 'ALL_101_JAVA_AND_FOUR_DAY_DEX_FAULTS_DETECTED_EXACT_POSITIVE_RESTORED', 'UI control completion status differs')
    for name in ('expectedControlCount', 'controlsCount'):
        count(report.get(name), 101, 'UI fault control count differs')
    count(report.get('restorationCases'), pins['suite_cases']['ui'], 'UI restoration omitted cases')
    rows = report.get('controls')
    wanted = verify_combined_ui_inventory(pins, rows)
    fixed = ('cases', 'paths', 'methodsCovered', 'methodKeys', 'methods', 'instructionCoverage',
             'independentExpectedResultChecks', 'expectedResultFailures', 'unsupportedExecutions',
             'dayNumericRecoveredMethods', 'dayNumericOriginalDependencyMethods', 'dayNumericOriginalDependencyKeys',
             'dayNumericInputInventorySha256', 'dayNumericOriginalCoverage',
             'dayLookupRecoveredMethods', 'dayLookupOriginalDependencyMethods', 'dayLookupOriginalDependencyKeys',
             'dayLookupInputInventorySha256', 'dayLookupOriginalCoverage', 'dayLookupGeneratedNullMessageCases',
             'dayLookupObserverRecordControls')
    baseline = artifacts.json('reports/ui-negative-baseline.json')
    restored = artifacts.json('reports/ui-positive-restoration.json')
    stripped = {key: value for key, value in ui.items() if key not in ('fixture_sha256', 'rebuilt_apk_sha256', 'rebuilt_dex_compared_to_apk')}
    inputs.require(baseline == restored == stripped and baseline.get('passed') is True, 'Full positive UI restoration differs from the final actual suite')
    artifacts.hash('reports/java-ui-three-path-parity.json', report['positiveBaselineSha256'])
    checks = []
    for row, expected in zip(rows, wanted):
        name = expected['name']
        stem = Path(expected['source']).stem
        source_name = f'reports/ui-mutants/{name}/{stem}.java'
        class_name = f'reports/ui-mutants/{name}/{stem}.class'
        inputs.require(row.get('retainedSource') == source_name and row.get('retainedClass') == class_name
                       and row.get('requiredCases') == expected['required_cases'] and row.get('requiredCase') == expected['required_cases'][0],
                       'UI mutation changed retained artifact or required case identities')
        flags(row, {'pass': True, 'requiredCaseRejected': True, 'sourceFixtureAndApkUnchanged': True,
                    'originalCoverageAndInventoryUnchanged': True}, 'UI fault is incomplete')
        count(row.get('exitCode'), 2, 'UI fault did not produce the expected rejection exit')
        count(row.get('unsupportedExecutions'), 0, 'UI fault used unsupported execution')
        inputs.require(type(row.get('failedCases')) is int and row['failedCases'] > 0, 'UI fault has no actual failures')
        artifacts.hash(source_name, expected['mutant_sha256'])
        inputs.require(row.get('mutantSourceSha256') == expected['mutant_sha256'], 'UI mutant source differs from the frozen compiled-control selection')
        artifacts.hash(class_name, row['mutantClassSha256'])
        positive_name = f'build/java/hostclasses/recovered/ui/{stem}.class'
        positive = inputs.identity(inputs.regular(project, positive_name))
        inputs.require(row.get('positiveClassSha256') == positive['sha256'] != row['mutantClassSha256'], 'UI fault did not use a distinct class from the final positive compilation')
        retain_class(project, positive_name, output, retained)
        negative = artifacts.json('reports/' + name + '-negative-failures.json')
        flags(negative, {'passed': False, 'androidRuntime': False}, 'UI negative result reports success')
        count(negative.get('failedCases'), row['failedCases'], 'UI negative failure count differs')
        inputs.require(all(negative.get(key) == baseline[key] for key in fixed)
                       and set(expected['required_cases']).issubset(negative.get('failedCaseLabels', [])), 'UI negative evidence changed the original coverage, input inventory, or required failures')
        checks.append({'mutation': name, 'failed_cases': row['failedCases'], 'source': source_name,
                       'class': class_name, 'source_sha256': expected['mutant_sha256'], 'class_sha256': row['mutantClassSha256']})
    return checks


def expected_numeric_commands(project, folder, java):
    """Reconstruct the fixed producer commands without trusting recorded argv."""
    project, output = Path(project), Path(project) / inputs.relative(folder)
    jar = str(project / 'tools/lib/jadx-r2721.4574686-all.jar')
    cp = ':'.join([jar, str(project / 'build/java/hostclasses'), str(project / 'tools/classes')])
    expected = []
    def pipeline(name):
        path = output / name
        commands = [
            ('d8-helper', [java, '-Xmx512m', '-cp', jar, 'com.android.tools.r8.D8', '--release',
                           '--no-desugaring', '--min-api', '23', '--output', path / 'd8', path / 'inputs.jar']),
            ('disassemble-helper', [java, '-Xmx512m', '-cp', jar, 'com.android.tools.smali.baksmali.Main',
                                    'd', '--api', '23', '--use-locals', '-o', path / 'helper-smali', path / 'd8/classes.dex']),
            ('assemble-target', [java, '-Xmx512m', '-cp', jar, 'com.android.tools.smali.smali.Main',
                                 'a', '--api', '23', '-j', '2', '-o', path / 'numeric-target.dex', path / 'target-smali'])]
        expected.extend((name, label, 0, list(map(str, argv))) for label, argv in commands)
    def execute(name, code):
        expected.append((name, 'execute', code, [java, *JVM_FLAGS, '-Xmx512m', '-cp', cp,
                        'DayNumericControlHarness', str(output / name / 'config.json'), str(output / name / 'result.json')]))
    pipeline('positive-pipeline')
    for name, dex in [('signed-apk', project / 'build/hybrid/classes3.dex'),
                      ('positive-transplant', output / 'positive-pipeline/numeric-target.dex')]:
        expected.append(('', name + '-instructions', 0, [java, '-Xmx512m', '-cp', cp, 'InspectMethod',
                        str(dex), NUMERIC_METHOD, str(output / (name + '-instructions.json'))]))
    execute('positive', 0)
    for name in ('integer-zero', 'decimal-zero'):
        pipeline(name + '-pipeline')
        execute(name + '-dex-fault', 3)
    for name, code in [('original-as-rebuilt-rejected', 1), ('wrong-helper-class-rejected', 1), ('positive-restoration', 0)]:
        execute(name, code)
    return expected


def verify_numeric_commands(report, folder, artifacts, java):
    expected = expected_numeric_commands(artifacts.root, folder, java)
    commands = report.get('commands')
    count(report.get('schema'), 2, 'Numeric command creation-evidence schema differs')
    inputs.require(isinstance(commands, list) and len(commands) == len(expected) == 17, 'Numeric actual command inventory differs')
    previous = row_clock(report, 'started', 'numeric-report-start')
    completion = row_clock(report, 'finished', 'numeric-report-finish')
    clocks_ordered(previous, completion, 'numeric report', strict=True)
    inputs.require(artifacts.started_ns <= previous['unix_ns']
                   and completion['unix_ns'] <= artifacts.ended_ns, 'Numeric report is outside acceptance')
    for row, (subdir, label, code, argv) in zip(commands, expected):
        inputs.require(row.get('name') == label, 'Numeric command order differs')
        inputs.require(row.get('argv') == argv, 'Numeric exact command, JVM policy or input role differs: ' + label)
        count(row.get('returncode'), code, 'Numeric actual subprocess outcome differs')
        count(row.get('timeout_seconds'), 120, 'Numeric child timeout differs')
        prefix = folder + ('/' + subdir if subdir else '')
        start, end = verify_command_stream_evidence(row, prefix, label, artifacts)
        clocks_ordered(previous, start, 'numeric child:' + label)
        clocks_ordered(end, completion, 'numeric completion:' + label)
        previous = end

def verify_java_policy(artifacts):
    policy = artifacts.json('reports/ui-runtime-policy.json')
    flags(policy, {'passed': True, 'androidRuntime': False}, 'Numeric Java policy did not pass in host scope')
    selected = shutil.which('java')
    inputs.require(selected is not None, 'Observed Java executable is unavailable')
    java = Path(selected).resolve(strict=True)
    vm = java.parent.parent / 'lib/server/libjvm.so'
    expected = [str(java), *JVM_FLAGS, '-XX:+PrintFlagsFinal', '-version']
    inputs.require(policy.get('java_executable') == str(java)
                   and policy.get('java_sha256') == inputs.identity(java)['sha256']
                   and policy.get('vm_library') == str(vm)
                   and policy.get('vm_library_sha256') == inputs.identity(vm)['sha256']
                   and policy.get('argv') == expected and policy.get('log') == 'ui-runtime-policy.log'
                   and policy.get('scope') == 'Host UI exception runtime only; unchanged APK and exact injected messages',
                   'Numeric Java/VM executable identity or exact policy command differs')
    artifacts.hash('reports/ui-runtime-policy.log', policy['log_sha256'])
    text = artifacts.raw('reports/ui-runtime-policy.log').decode('utf-8')
    first = text.splitlines()[0]
    inputs.require(first.startswith('COMMAND: ') and inputs.document(first[len('COMMAND: '):]) == expected,
                   'Java policy raw command differs')
    observed = {}
    for name, wanted in [('OmitStackTraceInFastThrow', False), ('ShowCodeDetailsInExceptionMessages', True)]:
        rows = re.findall(r'^\s*bool\s+' + re.escape(name) + r'\s*=\s*(true|false)\s+.*$', text, re.M)
        inputs.require(len(rows) == 1 and (rows[0] == 'true') is wanted, 'Java effective flag differs: ' + name)
        observed[name] = wanted
    inputs.require(policy.get('effective_flags') == observed, 'Java flag summary differs from the raw observation')
    return str(java)


def expected_provenance_config(config, name):
    wanted = copy.deepcopy(config)
    if name == 'original-as-rebuilt-rejected':
        wanted['targetDex'] = copy.deepcopy(config['originalFixture'])
    elif name == 'wrong-helper-class-rejected':
        wanted['classPins']['recovered.ui.DayTriggerValueMethods']['sha256'] = '0' * 64
    else:
        raise ValueError('Unknown numeric provenance control')
    return wanted


def verify_provenance_config(actual, positive, name):
    inputs.require(actual == expected_provenance_config(positive, name),
                   'Numeric provenance configuration changed another input or did not inject the declared fault')


def verify_numeric(project, pins, apk, ui, controls, report, artifacts, output, retained):
    # Import only after the independent full input scan, which binds these exact
    # validators to the published nineteen-file delta and immutable baseline.
    sys.path.insert(0, str(project))
    import day_numeric_dex_controls as numeric
    import ui_mutation_catalog as catalog
    flags(report, {'passed': True, 'androidRuntime': False, 'positive_signed_apk_instruction_match': True,
                   'positive_restoration_byte_exact': True, 'source_class_fixture_and_apk_unchanged': True},
          'Numeric signed-D8 acceptance is incomplete')
    inputs.require(report.get('status') == 'TWO_ACTUAL_NUMERIC_DEX_FAULTS_DETECTED_SIGNED_POSITIVE_RESTORED'
                   and report.get('signed_apk_sha256') == apk and report.get('original_fixture_sha256') == pins['fixture']['sha256']
                   and report.get('input_inventory_sha256') == catalog.DAY_INPUT_INVENTORY_SHA256, 'Numeric acceptance identity differs')
    for key, expected in [('schema', 2), ('primary_recovered_methods', 1), ('original_dependency_methods', 3),
                          ('expected_java_faults', 13), ('expected_actual_dex_faults', 2), ('provenance_controls_rejected', 2),
                          ('cases', 1291), ('execution_paths', 3), ('original_instruction_count', 32),
                          ('rebuilt_instruction_count', 25), ('conditional_edges_per_path', 4)]:
        count(report.get(key), expected, 'Numeric acceptance count differs: ' + key)
    artifacts.hash('reports/day-numeric-dex-controls.json', controls['dayNumericDexControlsSha256'])
    folder = report.get('evidence_directory')
    inputs.require(isinstance(folder, str) and re.fullmatch(r'reports/day-numeric-dex-[A-Za-z0-9_]+', folder), 'Numeric evidence directory differs')
    java = verify_java_policy(artifacts)
    verify_numeric_commands(report, folder, artifacts, java)
    inputs.require(report.get('positive_pipeline') == pins['numeric_positive_pipeline'], 'Fresh numeric production transplant differs from the reviewed pipeline')
    inputs.require(artifacts.json(folder + '/positive-pipeline/method-body-binding.json') == pins['numeric_positive_pipeline'],
                   'Positive method-body binding differs')
    artifacts.hash(folder + '/positive-pipeline/numeric-target.dex', pins['numeric_positive_pipeline']['target_dex_sha256'])
    inputs.require(artifacts.raw(folder + '/signed-apk-instructions.json') == artifacts.raw(folder + '/positive-transplant-instructions.json'),
                   'Actual signed-method instructions differ from the positive transplant')
    positive = artifacts.json(folder + '/positive/result.json')
    restoration = artifacts.json(folder + '/positive-restoration/result.json')
    numeric.validate_positive(positive)
    numeric.validate_positive(restoration)
    inputs.require(positive == restoration and artifacts.raw(folder + '/positive/result.json') == artifacts.raw(folder + '/positive-restoration/result.json'),
                   'Numeric raw positive restoration is not byte-exact')
    cfg = artifacts.json(folder + '/positive/config.json')
    count(cfg.get('schema'), 1, 'Numeric positive configuration schema differs')
    inputs.require(set(cfg) == {'schema', 'originalFixture', 'rebuiltApk', 'rebuiltGetterDex', 'targetDex', 'classPins'},
                   'Numeric positive configuration inventory differs')
    inputs.require(positive.get('inputIdentities') == cfg and positive.get('loadedClassOrigins') == cfg.get('classPins'),
                   'Numeric positive raw input/class origins differ from its actual invocation')
    inputs.require(artifacts.json(folder + '/positive-restoration/config.json') == cfg, 'Restoration used different positive inputs')
    for field, name, digest in [
        ('originalFixture', 'tests/fixtures/original-methods.dex', pins['fixture']['sha256']),
        ('rebuiltApk', 'dist/MacroDroid-5.67.8-v9-hybrid.apk', apk),
        ('targetDex', folder + '/positive-pipeline/numeric-target.dex', pins['numeric_positive_pipeline']['target_dex_sha256'])]:
        inputs.require(cfg.get(field) == {'path': str(project / name), 'sha256': digest}, 'Numeric positive input role differs: ' + field)
    getter = inputs.regular(project, 'build/hybrid/classes3.dex')
    getter_hash = inputs.identity(getter)['sha256']
    inputs.require(cfg.get('rebuiltGetterDex') == {'path': str(getter), 'sha256': getter_hash, 'apk_member': 'classes3.dex'}, 'Getter DEX role differs')
    with zipfile.ZipFile(inputs.regular(project, 'dist/MacroDroid-5.67.8-v9-hybrid.apk')) as archive:
        inputs.require(archive.namelist().count('classes3.dex') == 1, 'Signed APK getter partition is not unique')
        with archive.open('classes3.dex') as stream:
            signed_getter_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    inputs.require(getter_hash == signed_getter_hash, 'The three getter bodies were not read from the actual signed APK partition')
    current_pins = numeric.class_pins(project / 'build/java/hostclasses', project / 'tools/classes')
    inputs.require(cfg.get('classPins') == current_pins and len(current_pins) == 23, 'Actual 23-class numeric runtime inventory differs')
    for value in current_pins.values():
        name = Path(value['path']).relative_to(project).as_posix()
        inputs.require(inputs.identity(inputs.regular(project, name))['sha256'] == value['sha256'], 'Loaded numeric class bytes differ')
        retain_class(project, name, output, retained)
    faults = report.get('actual_dex_faults')
    inputs.require(isinstance(faults, list) and [row.get('name') for row in faults] == ['integer-zero', 'decimal-zero'], 'Actual numeric DEX fault inventory differs')
    jobs = {row['name'].removeprefix('day-numeric-'): row for row in catalog.load_day_mutations(project)}
    for row in faults:
        name = row['name']
        flags(row, {'passed': True}, 'An actual numeric DEX fault was not rejected')
        count(row.get('mismatches'), numeric.JAVA_FAILURE_COUNTS[name], 'Numeric DEX fault failure count differs')
        inputs.require(row.get('required_cases') == jobs[name]['required_cases'], 'Numeric DEX fault required cases differ')
        bad = artifacts.json(folder + '/' + name + '-dex-fault/result.json')
        numeric.validate_fault(positive, bad, jobs[name]['required_cases'], numeric.JAVA_FAILURE_COUNTS[name], 'rebuilt')
        bad_cfg = artifacts.json(folder + '/' + name + '-dex-fault/config.json')
        inputs.require(bad.get('inputIdentities') == bad_cfg and bad.get('loadedClassOrigins') == cfg['classPins'], 'Numeric DEX fault origins differ')
        wanted = dict(cfg)
        wanted['targetDex'] = {'path': str(project / folder / (name + '-pipeline/numeric-target.dex')), 'sha256': row['pipeline']['target_dex_sha256']}
        inputs.require(bad_cfg == wanted and row['pipeline'] == artifacts.json(folder + '/' + name + '-pipeline/method-body-binding.json'), 'Numeric fault changed another input or its production binding')
        artifacts.hash(folder + '/' + name + '-pipeline/numeric-target.dex', row['pipeline']['target_dex_sha256'])
    for name, expected_error in [('original-as-rebuilt-rejected', 'Original fixture cannot masquerade as rebuilt target'),
                                  ('wrong-helper-class-rejected', 'Wrong input identity: class recovered.ui.DayTriggerValueMethods')]:
        verify_provenance_config(artifacts.json(folder + '/' + name + '/config.json'), cfg, name)
        inputs.require(not (project / folder / name / 'result.json').exists()
                       and expected_error in artifacts.raw(folder + '/' + name + '/execute.stderr.log').decode(),
                       'Numeric provenance control did not reject for the required reason')
    _, bindings = numeric.validate_java_controls(project, controls['controls'])
    inputs.require(report.get('java_fault_bindings') == bindings and len(bindings) == 13, 'Numeric Java-control source/class binding differs')
    for key, wanted in [('dayNumericRecoveredMethods', 1), ('dayNumericOriginalDependencyMethods', 3)]:
        count(ui.get(key), wanted, 'UI numeric method/dependency credit differs')
    inputs.require(ui.get('dayNumericOriginalDependencyKeys') == sorted(numeric.GETTERS)
                   and ui.get('dayNumericInputInventorySha256') == catalog.DAY_INPUT_INVENTORY_SHA256
                   and ui.get('dayNumericInstructionAndConditionalCoverage') is True, 'UI numeric original coverage is incomplete')
    numeric.validate_positive_coverage(ui['dayNumericOriginalCoverage'], 32)
    numeric.validate_positive_coverage(ui['dayNumericRebuiltCoverage'], 25)
    return {'cases': 1291, 'paths': 3, 'original_instructions': 32, 'rebuilt_instructions': 25,
            'conditional_edges_per_path': 4, 'java_faults': 13, 'actual_dex_faults': 2,
            'uncredited_original_getters': 3, 'actual_command_streams_checked': 34,
            'signed_positive_instruction_bytes_equal': True, 'exact_positive_restoration': True,
            'loaded_runtime_classes': 23}


LOOKUP_METHOD = ('Lcom/arlosoft/macrodroid/triggers/DayTrigger;->p0('
                 'Lcom/arlosoft/macrodroid/variables/VariableValue$Dictionary;Ljava/lang/String;)'
                 'Lcom/arlosoft/macrodroid/variables/VariableValue$DictionaryEntry;')
LOOKUP_HELPER = 'recovered.ui.DayTriggerLookupMethods'


def verify_combined_registry(project, pins):
    registry = inputs.read_json(inputs.regular(project, 'source/java-method-map.json'))
    keys = [row['target'] + '->' + row['method'] for row in registry]
    inputs.require(len(keys) == len(set(keys)) == pins['registered_methods'], 'Combined registry is incomplete or duplicated')
    selected = [row for row in registry if row['target'] == 'Lcom/arlosoft/macrodroid/triggers/DayTrigger;']
    inputs.require(selected == pins['day_trigger_class_mappings'], 'DayTrigger constant and two ordinary-method mappings differ')
    source = inputs.checked_identity(project, 'tests/fixtures/original-dependencies.json', pins['dependency_declaration'])
    declaration = inputs.read_json(source)
    count(declaration.get('schema'), 1, 'Combined dependency schema differs')
    inputs.require(declaration.get('dependencies') == pins['combined_dependencies'], 'Exact combined consumer/getter rows differ')
    dependencies = [row['target'] + '->' + row['method'] for row in declaration['dependencies']]
    inputs.require(len(dependencies) == len(set(dependencies)) == 5 and not set(dependencies) & set(keys),
                   'A getter was omitted, duplicated or credited as recovered')
    consumers = {method: [row for row in declaration['dependencies'] if row['consumer'] == method]
                 for method in (NUMERIC_METHOD, LOOKUP_METHOD)}
    inputs.require(len(consumers[NUMERIC_METHOD]) == 3 and len(consumers[LOOKUP_METHOD]) == 2,
                   'Numeric and lookup getter partitions differ')
    provenance = inputs.read_json(inputs.regular(project, 'tests/fixtures/provenance.json'))
    inputs.require(provenance.get('dependency_keys') == sorted(dependencies)
                   and provenance.get('dependency_declaration_sha256') == pins['dependency_declaration']['sha256'],
                   'Fixture dependency provenance differs')
    return {'registered_class_mappings': selected, 'uncredited_dependency_keys': sorted(dependencies)}


def verify_method_producer_cwd(project, pins, execution):
    """Bind cwd through exact source and the outer receipt; no child cwd field exists."""
    import ast
    project = Path(project)
    inputs.require(project.is_absolute() and project == project.resolve()
                   and execution['execution'].get('cwd') == str(project), 'Outer resolved project cwd differs')
    rows = {}
    for name, expected in pins['method_producer_sources'].items():
        path = inputs.checked_identity(project, name, expected)
        source = path.read_text(); tree = ast.parse(source)
        if name in ('day_numeric_dex_controls.py', 'day_lookup_dex_controls.py'):
            owner = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'run_controls')
            function = next(node for node in owner.body if isinstance(node, ast.FunctionDef) and node.name == 'run')
            calls = [node for node in ast.walk(function) if isinstance(node, ast.Call) and ast.unparse(node.func) == 'subprocess.run']
            inputs.require(len(calls) == 1 and [ast.unparse(k.value) for k in calls[0].keywords if k.arg == 'cwd'] == ['root'],
                           'Method subprocess cwd expression differs')
            roots = [node for node in owner.body if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == 'root' for target in node.targets)]
            inputs.require(len(roots) == 1 and ast.unparse(roots[0].value) == 'root.resolve()', 'Method root resolution differs')
            rows[name] = {'source': expected, 'cwd_expression': 'root', 'resolved_root_expression': 'root.resolve()',
                          'individual_child_cwd_recorded': False}
        elif name == 'ui_negative_control.py':
            calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                     and ast.unparse(node.func) in ('day_numeric_dex_controls.run_controls', 'day_lookup_dex_controls.run_controls')]
            inputs.require(len(calls) == 2 and all(ast.unparse(node.args[0]) == 'build.ROOT' for node in calls),
                           'UI method runner project binding differs')
            rows[name] = {'source': expected, 'calls': [ast.unparse(node) for node in calls]}
        else:
            roots = [node for node in tree.body if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == 'ROOT' for target in node.targets)]
            inputs.require(len(roots) == 1 and ast.unparse(roots[0].value) == 'Path(__file__).resolve().parent',
                           'Build project root binding differs')
            rows[name] = {'source': expected, 'root_expression': 'Path(__file__).resolve().parent'}
    return {'scope': 'Exact producer/caller AST and explicit outer acceptance cwd; individual method rows do not independently record cwd',
            'resolved_project': str(project), 'sources': rows}


def expected_lookup_commands(project, folder, java):
    project, output = Path(project), Path(project) / inputs.relative(folder)
    jar = str(project / 'tools/lib/jadx-r2721.4574686-all.jar')
    cp = ':'.join([jar, str(project / 'build/java/hostclasses'), str(project / 'tools/classes')])
    expected = []
    def pipeline(name):
        path = output / name
        commands = [
            ('d8-helper', [java, '-Xmx512m', '-cp', jar, 'com.android.tools.r8.D8', '--release',
                           '--no-desugaring', '--min-api', '23', '--output', path / 'd8', path / 'inputs.jar']),
            ('disassemble-helper', [java, '-Xmx512m', '-cp', jar, 'com.android.tools.smali.baksmali.Main',
                                    'd', '--api', '23', '--use-locals', '-o', path / 'helper-smali', path / 'd8/classes.dex']),
            ('assemble-target', [java, '-Xmx512m', '-cp', jar, 'com.android.tools.smali.smali.Main',
                                 'a', '--api', '23', '-j', '2', '-o', path / 'lookup-target.dex', path / 'target-smali'])]
        expected.extend((name, label, 0, list(map(str, argv))) for label, argv in commands)
    def inspect(name, dex, method):
        expected.append(('', name, 0, [java, '-Xmx512m', '-cp', cp, 'InspectMethod', str(dex), method,
                                      str(output / (name + '.json'))]))
    def execute(name, code):
        expected.append((name, 'execute', code, [java, *JVM_FLAGS, '-Xmx512m', '-cp', cp,
                        'DayLookupControlHarness', str(output / name / 'config.json'), str(output / name / 'result.json')]))
    pipeline('positive-pipeline')
    inspect('numeric-before-instructions', project / 'build/hybrid/classes3.dex', NUMERIC_METHOD)
    inspect('signed-apk-instructions', project / 'build/hybrid/classes3.dex', LOOKUP_METHOD)
    inspect('positive-transplant-instructions', output / 'positive-pipeline/lookup-target.dex', LOOKUP_METHOD)
    execute('positive', 0)
    for name in ('case-sensitive', 'last-match'):
        pipeline(name + '-pipeline'); execute(name + '-dex-fault', 3)
    for name, code in [('original-as-rebuilt-rejected', 1), ('wrong-helper-class-rejected', 1), ('positive-restoration', 0)]:
        execute(name, code)
    inspect('numeric-after-instructions', project / 'build/hybrid/classes3.dex', NUMERIC_METHOD)
    return expected


def verify_lookup_commands(report, folder, artifacts, java):
    expected = expected_lookup_commands(artifacts.root, folder, java)
    count(report.get('schema'), 2, 'Lookup command schema differs')
    count(report.get('command_stream_evidence_schema'), 2, 'Lookup command creation-evidence schema differs')
    inputs.require(report.get('command_stream_evidence_provider') == 'day_numeric_dex_controls.CommandStreamEvidence',
                   'Lookup command evidence provider differs')
    commands = report.get('commands')
    inputs.require(isinstance(commands, list) and len(commands) == len(expected) == 19, 'Lookup actual command inventory differs')
    previous = row_clock(report, 'started', 'lookup-report-start')
    completion = row_clock(report, 'finished', 'lookup-report-finish')
    clocks_ordered(previous, completion, 'lookup report', strict=True)
    inputs.require(artifacts.started_ns <= previous['unix_ns'] and completion['unix_ns'] <= artifacts.ended_ns,
                   'Lookup report is outside acceptance')
    for row, (subdir, label, code, argv) in zip(commands, expected):
        inputs.require(row.get('name') == label and row.get('argv') == argv, 'Lookup command order or exact argv differs: ' + label)
        count(row.get('expected_returncode'), code, 'Lookup expected subprocess outcome differs')
        count(row.get('returncode'), code, 'Lookup actual subprocess outcome differs')
        count(row.get('timeout_seconds'), 120, 'Lookup child timeout differs')
        flags(row, {'stream_context_entered': True, 'timed_out': False}, 'Lookup command did not complete its stream context')
        inputs.require('error' in row and row['error'] is None and 'error_type' in row and row['error_type'] is None,
                       'Partial or failed lookup command cannot be accepted as a success')
        prefix = folder + ('/' + subdir if subdir else '')
        start, end = verify_command_stream_evidence(row, prefix, label, artifacts)
        finalization = checked_clock(row.get('recording_finalized'), label + ':recording-finalized')
        clocks_ordered(previous, start, 'lookup child:' + label)
        clocks_ordered(row['stream_evidence']['invocation_finished'], end, 'lookup stream completion:' + label)
        clocks_ordered(end, finalization, 'lookup row finalization:' + label)
        clocks_ordered(finalization, completion, 'lookup report completion:' + label)
        previous = finalization


def verify_lookup_summary(report, pins, apk):
    flags(report, {'passed': True, 'androidRuntime': False, 'positive_signed_apk_instruction_match': True,
                   'positive_restoration_byte_exact': True, 'source_class_fixture_and_apk_unchanged': True,
                   'signed_numeric_method_unchanged': True}, 'Lookup signed-D8 acceptance is incomplete')
    inputs.require(report.get('status') == 'TWO_ACTUAL_LOOKUP_DEX_FAULTS_DETECTED_SIGNED_POSITIVE_RESTORED'
                   and report.get('signed_apk_sha256') == apk and report.get('original_fixture_sha256') == pins['fixture']['sha256']
                   and report.get('input_inventory_sha256') == pins['lookup_input_inventory_sha256'], 'Lookup acceptance identity differs')
    for key, expected in [('schema', 2), ('primary_recovered_methods', 1), ('original_dependency_methods', 2),
                          ('expected_java_faults', 10), ('expected_actual_dex_faults', 2), ('provenance_controls_rejected', 2),
                          ('cases', 371), ('execution_paths', 3), ('original_instruction_count', 26),
                          ('rebuilt_instruction_count', 23), ('conditional_edges_per_path', 4)]:
        count(report.get(key), expected, 'Lookup acceptance count differs: ' + key)
    inputs.require(report.get('signed_class_registered_methods') == sorted(row['method'] for row in pins['day_trigger_class_mappings'])
                   and report.get('micro_dex_preservation_scope') == 'Only p0 changed in each micro-DEX. Other original methods stay original there; signed class has its complete three registered mappings.',
                   'Lookup signed-class or one-method micro-DEX preservation scope differs')


def expected_lookup_provenance_config(positive, name):
    result = copy.deepcopy(positive)
    if name == 'original-as-rebuilt-rejected':
        result['targetDex'] = copy.deepcopy(positive['originalFixture'])
    elif name == 'wrong-helper-class-rejected':
        result['classPins'][LOOKUP_HELPER]['sha256'] = '0' * 64
    else:
        raise ValueError('Unknown lookup provenance control')
    return result


def verify_lookup_provenance_config(actual, positive, name):
    inputs.require(actual == expected_lookup_provenance_config(positive, name), 'Lookup provenance control changed another input or did not inject its fault')


def verify_lookup_byte_equalities(artifacts, folder):
    inputs.require(artifacts.raw(folder + '/signed-apk-instructions.json') == artifacts.raw(folder + '/positive-transplant-instructions.json'),
                   'Actual signed lookup instructions differ from the positive transplant')
    inputs.require(artifacts.raw(folder + '/numeric-before-instructions.json') == artifacts.raw(folder + '/numeric-after-instructions.json'),
                   'Signed numeric instructions changed during lookup controls')
    positive = artifacts.json(folder + '/positive/result.json')
    restored = artifacts.json(folder + '/positive-restoration/result.json')
    inputs.require(positive == restored and artifacts.raw(folder + '/positive/result.json') == artifacts.raw(folder + '/positive-restoration/result.json'),
                   'Lookup raw positive restoration is not byte-exact')
    return positive, restored


def verify_lookup(project, pins, apk, ui, controls, report, artifacts, output, retained):
    # Called only after the complete final source scan; imported validators are
    # part of the exact final twenty-one-path delta, not arbitrary report content.
    sys.path.insert(0, str(project))
    import day_lookup_dex_controls as lookup
    import ui_mutation_catalog as catalog
    inputs.require(Path(lookup.__file__).resolve() == project / 'day_lookup_dex_controls.py', 'Lookup validator loaded from another source root')
    verify_lookup_summary(report, pins, apk)
    artifacts.hash('reports/day-lookup-dex-controls.json', controls['dayLookupDexControlsSha256'])
    folder = report.get('evidence_directory')
    inputs.require(isinstance(folder, str) and re.fullmatch(r'reports/day-lookup-dex-[A-Za-z0-9_]+', folder), 'Lookup evidence directory differs')
    verify_lookup_commands(report, folder, artifacts, verify_java_policy(artifacts))
    inputs.require(report.get('positive_pipeline') == pins['lookup_positive_pipeline']
                   and artifacts.json(folder + '/positive-pipeline/method-body-binding.json') == pins['lookup_positive_pipeline'],
                   'Fresh lookup production transplant differs from its reviewed method-body binding')
    artifacts.hash(folder + '/positive-pipeline/lookup-target.dex', pins['lookup_positive_pipeline']['target_dex_sha256'])
    positive, restoration = verify_lookup_byte_equalities(artifacts, folder)
    lookup.validate_positive(positive); lookup.validate_positive(restoration)
    cfg = artifacts.json(folder + '/positive/config.json')
    count(cfg.get('schema'), 1, 'Lookup positive configuration schema differs')
    inputs.require(set(cfg) == {'schema', 'originalFixture', 'rebuiltApk', 'rebuiltGetterDex', 'targetDex', 'classPins'},
                   'Lookup positive configuration inventory differs')
    lookup.validate_execution_binding(positive, cfg); lookup.validate_execution_binding(restoration, cfg)
    inputs.require(artifacts.json(folder + '/positive-restoration/config.json') == cfg, 'Lookup restoration used different positive inputs')
    for field, name, digest in [
        ('originalFixture', 'tests/fixtures/original-methods.dex', pins['fixture']['sha256']),
        ('rebuiltApk', 'dist/MacroDroid-5.67.8-v9-hybrid.apk', apk),
        ('targetDex', folder + '/positive-pipeline/lookup-target.dex', pins['lookup_positive_pipeline']['target_dex_sha256'])]:
        inputs.require(cfg.get(field) == {'path': str(project / name), 'sha256': digest}, 'Lookup positive input role differs: ' + field)
    getter = inputs.regular(project, 'build/hybrid/classes3.dex')
    getter_hash = inputs.identity(getter)['sha256']
    inputs.require(cfg.get('rebuiltGetterDex') == {'path': str(getter), 'sha256': getter_hash, 'apk_member': 'classes3.dex'}, 'Lookup getter DEX role differs')
    with zipfile.ZipFile(inputs.regular(project, 'dist/MacroDroid-5.67.8-v9-hybrid.apk')) as archive:
        inputs.require(archive.namelist().count('classes3.dex') == 1, 'Signed lookup/getter partition is not unique')
        with archive.open('classes3.dex') as stream: signed_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    inputs.require(getter_hash == signed_hash, 'Lookup and its two getter bodies were not read from the actual signed APK partition')
    current = lookup.class_pins(project / 'build/java/hostclasses', project / 'tools/classes')
    inputs.require(cfg.get('classPins') == current and sorted(current) == pins['lookup_class_names'] and len(current) == 26,
                   'Actual lookup runtime class inventory differs')
    for value in current.values():
        name = Path(value['path']).relative_to(project).as_posix()
        inputs.require(inputs.identity(inputs.regular(project, name))['sha256'] == value['sha256'], 'Loaded lookup class bytes differ')
        retain_class(project, name, output, retained)
    faults = report.get('actual_dex_faults')
    inputs.require(isinstance(faults, list) and [row.get('name') for row in faults] == ['case-sensitive', 'last-match'], 'Actual lookup DEX fault inventory differs')
    jobs = {row['name'].removeprefix('day-lookup-'): row for row in catalog.load_lookup_mutations(project)}
    for row in faults:
        name = row['name']; flags(row, {'passed': True}, 'An actual lookup DEX fault was not rejected')
        count(row.get('mismatches'), pins['lookup_java_failure_counts'][name], 'Lookup DEX fault failure count differs')
        inputs.require(row.get('required_cases') == jobs[name]['required_cases'], 'Lookup DEX fault required cases differ')
        bad = artifacts.json(folder + '/' + name + '-dex-fault/result.json')
        lookup.validate_fault(positive, bad, jobs[name]['required_cases'], pins['lookup_java_failure_counts'][name], 'rebuilt')
        bad_cfg = artifacts.json(folder + '/' + name + '-dex-fault/config.json')
        lookup.validate_execution_binding(bad, bad_cfg)
        wanted = copy.deepcopy(cfg)
        wanted['targetDex'] = {'path': str(project / folder / (name + '-pipeline/lookup-target.dex')), 'sha256': row['pipeline']['target_dex_sha256']}
        inputs.require(bad_cfg == wanted and row['pipeline'] == artifacts.json(folder + '/' + name + '-pipeline/method-body-binding.json'),
                       'Lookup DEX fault changed another input or production binding')
        artifacts.hash(folder + '/' + name + '-pipeline/lookup-target.dex', row['pipeline']['target_dex_sha256'])
    for name, error in [('original-as-rebuilt-rejected', 'Original fixture cannot masquerade as rebuilt target'),
                        ('wrong-helper-class-rejected', 'Wrong input identity: class ' + LOOKUP_HELPER)]:
        verify_lookup_provenance_config(artifacts.json(folder + '/' + name + '/config.json'), cfg, name)
        inputs.require(not (project / folder / name / 'result.json').exists()
                       and error in artifacts.raw(folder + '/' + name + '/execute.stderr.log').decode(),
                       'Lookup provenance control did not reject for the required reason')
    _, bindings = lookup.validate_java_controls(project, controls['controls'])
    inputs.require(report.get('java_fault_bindings') == bindings and len(bindings) == 10, 'Lookup Java-control source/class binding differs')
    for key, value in [('dayLookupRecoveredMethods', 1), ('dayLookupOriginalDependencyMethods', 2)]:
        count(ui.get(key), value, 'UI lookup method/dependency credit differs')
    inputs.require(ui.get('dayLookupOriginalDependencyKeys') == sorted(lookup.GETTERS)
                   and ui.get('dayLookupInputInventorySha256') == pins['lookup_input_inventory_sha256']
                   and ui.get('dayLookupInstructionAndConditionalCoverage') is True
                   and ui.get('dayLookupGeneratedNullMessageCases') == pins['lookup_vm_null_cases']
                   and ui.get('dayLookupObserverRecordControls') == positive['observerRecordControls'],
                   'UI lookup coverage, exact exception scope or observer controls differ')
    lookup.validate_positive_coverage(ui['dayLookupOriginalCoverage'], 26)
    lookup.validate_positive_coverage(ui['dayLookupRebuiltCoverage'], 23)
    return {'cases': 371, 'paths': 3, 'original_instructions': 26, 'rebuilt_instructions': 23,
            'conditional_edges_per_path': 4, 'java_faults': 10, 'actual_dex_faults': 2, 'provenance_rejections': 2,
            'uncredited_original_getters': 2, 'actual_command_streams_checked': 38,
            'signed_positive_instruction_bytes_equal': True, 'exact_positive_restoration': True,
            'signed_numeric_instructions_unchanged': True, 'loaded_runtime_classes': 26}


def verify_other_gates(reports, apk):
    for name in ('baseline-resource-parity.json', 'hybrid-resource-parity.json'):
        row = reports[name]
        for field in ('changed_files', 'missing_files', 'extra_files', 'changed_resource_ids', 'missing_resource_names',
                      'extra_resource_names', 'missing_apk_entries', 'extra_apk_entries', 'changed_zip_compression_methods',
                      'public_resource_visibility_changes'):
            inputs.require(row.get(field) == [], 'Resource parity has unexplained differences: ' + field)
        for field, expected in [('files_expected', 7212), ('files_actual', 7212), ('byte_identical', 7211),
                                 ('resource_ids_expected', 23854), ('resource_ids_actual', 23854)]:
            count(row.get(field), expected, 'Resource inventory count differs')
        inputs.require(row.get('equivalent_enum_order_only') == ['res/values/attrs.xml']
                       and len(row.get('native_libraries', [])) == 22
                       and all(value.get('pass') is True and value.get('original_bytes_preserved') is True for value in row['native_libraries']),
                       'Declared resource/native equivalence scope differs')
    for name, field in [('migration-static-proof.json', 'methods_registered'), ('migration-linkage-check.json', 'registered_methods')]:
        row = reports[name]
        flags(row, {'pass': True}, 'Migration static/linkage gate did not pass')
        count(row.get(field), 1244, 'Static/linkage gate omitted a recovered DayTrigger method')
        inputs.require(row.get('errors') == [], 'Static/linkage gate contains errors')
    for name, key, cases in [('oracle-semantics.json', 'pass', 2458), ('engine-oracle-semantics.json', 'pass', 4145),
                             ('ui-oracle-semantics.json', 'passed', 6270), ('constructor-oracle-conformance.json', 'passed', 16),
                             ('widget-bitwise-oracle-conformance.json', 'passed', 4546)]:
        row = reports[name]
        flags(row, {key: True, 'androidRuntime': False}, 'An independent host oracle conformance failed')
        count(row.get('cases'), cases, 'Host oracle conformance inventory differs')
    for name, count_wanted in [('engine-negative-controls.json', 4), ('core-negative-controls.json', 2), ('environment-negative-controls.json', 3)]:
        row = reports[name]
        flags(row, {'pass': True, 'positiveRestorationPassed': True, 'androidRuntime': False}, 'An existing fault/restoration gate failed')
        inputs.require(isinstance(row.get('controls'), list) and len(row['controls']) == count_wanted
                       and all(value.get('pass') is True and type(value.get('failedCases')) is int and value['failedCases'] > 0
                               and value.get('unsupportedExecutions') == 0 for value in row['controls']), 'Existing fault inventory is incomplete')
    legacy = reports['negative-control.json']
    flags(legacy, {'pass': True, 'source_and_apk_mutated': False}, 'Legacy negative control failed')
    count(legacy.get('exit_code'), 2, 'Legacy negative control had another outcome')
    count(legacy.get('failed_vectors'), 1110, 'Legacy negative case inventory differs')
    edited = reports['full-apk-edit-probe.json']
    flags(edited, {'pass': True, 'experimental_apk_not_distributed': True, 'release_inputs_and_apk_unchanged': True,
                   'required_pause_case_rejected': True, 'android_runtime_executed': False}, 'Actual signed source-edit probe did not pass')
    inputs.require(edited.get('original_release_apk_sha256') == apk
                   and edited.get('changed_non_signature_entries') == ['classes3.dex']
                   and edited.get('changed_classes') == ['Lcom/arlosoft/macrodroid/macro/Macro;']
                   and edited.get('changed_methods') == ['invokeActions(Ljava/util/List;ILcom/arlosoft/macrodroid/triggers/TriggerContextInfo;ZLjava/util/Stack;Lcom/arlosoft/macrodroid/data/ResumeMacroInfo;)V'], 'Signed source-edit probe changed another scope')
    count(edited.get('negative_exit_code'), 1, 'Signed source-edit negative process outcome differs')
    count(edited.get('negative_failed_cases'), 113, 'Signed source-edit negative cases differ')
    count(edited.get('unsupported_executions'), 0, 'Signed source-edit used unsupported execution')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-repository', type=Path, required=True)
    parser.add_argument('--overlay-repository', type=Path, required=True)
    parser.add_argument('--lookup-repository', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--runtime-manifest-sha256', required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    inputs.require(not output.is_symlink() and not any(output.is_relative_to(path.resolve()) for path in
                   (args.baseline_repository, args.overlay_repository, args.lookup_repository, Path(__file__).resolve().parents[2])), 'Invalid proof output directory')
    output.mkdir(parents=True, exist_ok=True)
    result = {'schema': 1, 'status': 'WIP_FULL_HOST_ACCEPTANCE_NOT_ESTABLISHED', 'passed': False,
              'started_utc': datetime.now(timezone.utc).isoformat(), 'active_promoted': False,
              'android_runtime_executed': False, 'full_runtime_1_to_1_established': False,
              'complete_high_level_java_kotlin_source': False,
              'file_metadata_verification_scope': 'Live host filesystem; archived recorded inode/ctime values are historical observations, not extracted-file metadata'}
    artifacts = None
    retained = {}
    try:
        runtime = inputs.verify_runtime_manifest(args.runtime_manifest_sha256)
        pins, _, future, context = inputs.contract(args.baseline_repository, args.overlay_repository, args.lookup_repository)
        inputs.verify_git_commit(args.baseline_repository, pins['baseline_commit'])
        inputs.verify_git_commit(args.overlay_repository, pins['overlay_commit'])
        inputs.verify_git_commit(args.lookup_repository, pins['lookup_commit'])
        prepared_path = inputs.regular(output, 'preparation.json')
        prepared = inputs.read_json(prepared_path)
        inputs.require(prepared.get('passed') is True and prepared.get('status') == 'EXACT_NUMERIC19_THEN_LOOKUP21_WIP_PREPARED'
                       and prepared.get('output') == str(output) and prepared.get('runtime_source') == runtime,
                       'The exact preparation proof is absent')
        inputs.verify_prepared_boundaries(pins, prepared, output, context)
        project = Path(prepared['project'])
        execution_path = inputs.regular(output, 'execution.json')
        execution = inputs.read_json(execution_path)
        inputs.require(execution.get('preparation_sha256') == inputs.identity(prepared_path)['sha256'], 'Preparation changed after execution began')
        start, end = verify_execution(execution, prepared, pins)
        result['actual_acceptance_execution'] = execution['execution']
        result['verified_wrapper_streams'] = verify_wrapper_streams(execution, prepared, output)
        inputs.compare_inputs(inputs.scan_inputs(project), future)
        inputs.checked_identity(project, 'reports/release-input-snapshot.json', pins['future_manifest'])
        inputs.require(inputs.read_json(project / 'reports/release-input-snapshot.json') == future, 'Acceptance manifest differs from independent complete derivation')
        artifacts = Artifacts(project, start, end)
        latest = artifacts.json('reports/acceptance-latest.json')
        reports = verify_gates(latest, execution, pins, artifacts)
        apks = verify_apks(latest, pins, artifacts, reports)
        suites = verify_registry_and_partition(project, pins, apks['hybrid']['sha256'], reports, artifacts)
        python = verify_python(artifacts.raw('reports/python-unit-tests.log'), pins['python_tests'])
        combined_registry = verify_combined_registry(project, pins)
        cwd_binding = verify_method_producer_cwd(project, pins, execution)
        ui_checks = verify_ui_controls(project, pins, reports['ui-negative-controls.json'], suites['ui'], artifacts, output, retained)
        numeric = verify_numeric(project, pins, apks['hybrid']['sha256'], suites['ui'], reports['ui-negative-controls.json'],
                                 reports['day-numeric-dex-controls.json'], artifacts, output, retained)
        lookup = verify_lookup(project, pins, apks['hybrid']['sha256'], suites['ui'], reports['ui-negative-controls.json'],
                               reports['day-lookup-dex-controls.json'], artifacts, output, retained)
        verify_other_gates(reports, apks['hybrid']['sha256'])
        staging = artifacts.json('reports/java-staging.json')
        flags(staging, {'published_after_all_compiler_commands': True}, 'Fresh Java/D8 generation was not published atomically')
        inputs.require(staging.get('published_directory') == 'build/java', 'Unexpected Java generation destination')
        # The complete actual reports/dist inventory is retained, even beyond the
        # required gate subset. No stale file, symlink or alias is accepted here.
        for directory in ('reports', 'dist'):
            for path in sorted((project / directory).rglob('*')):
                inputs.require(not path.is_symlink(), 'Symlink in produced evidence')
                if path.is_file() and path != project / 'reports/release-input-snapshot.json':
                    artifacts.path(path.relative_to(project).as_posix())
        inputs.compare_inputs(inputs.scan_inputs(project), future)
        result.update(status='ISOLATED_DAY_TRIGGER_NUMERIC_LOOKUP_ALL_16_HOST_GATES_VERIFIED', passed=True,
                      source_snapshot=pins['future_snapshot'], future_manifest=pins['future_manifest'],
                      baseline_commit=pins['baseline_commit'], source_overlay_commit=pins['overlay_commit'],
                      overlay_checkpoint=pins['overlay_checkpoint'], lookup_source_commit=pins['lookup_commit'],
                      lookup_checkpoints=pins['lookup_capsules'], source_stages=prepared['source_stages'],
                      gates_verified=16, fresh_reports_verified=24, actual_cases=pins['all_cases'],
                      registered_methods=pins['registered_methods'], target_classes=pins['target_classes'],
                      fixture_methods=pins['fixture_methods'], fixture_classes=pins['fixture_classes'],
                      uncredited_original_dependencies=pins['original_dependency_methods'],
                      suite_cases=pins['suite_cases'], python=python, actual_ui_java_controls=101,
                      all_ui_mutant_checks=ui_checks, numeric=numeric, lookup=lookup, apks=apks,
                      combined_registry=combined_registry, method_cwd_source_binding=cwd_binding,
                      source_edit_signed_apk_probe_verified=True,
                      candidate_is_wip_only=True, android_probe_status=latest.get('android_status'))
        return 0
    except Exception as error:
        result['error'] = repr(error)
        print('WIP VERIFICATION FAILED:', error, file=sys.stderr)
        return 2
    finally:
        result['retained_runtime_classes'] = sorted(retained.values(), key=lambda row: row['source_path'])
        result['verified_output_artifacts'] = sorted(artifacts.rows.values(), key=lambda row: row['path']) if artifacts else []
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        inputs.write_json(output / 'verification.json', result)
        print(result['status'], flush=True)


if __name__ == '__main__':
    sys.exit(main())
