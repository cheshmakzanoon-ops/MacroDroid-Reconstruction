import sys; print("exact stdout"); print("exact stderr", file=sys.stderr)
