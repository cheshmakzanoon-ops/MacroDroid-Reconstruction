from pathlib import Path; Path("child-ran").write_text("bad")
