from pathlib import Path; import os,time; Path("child.pid").write_text(str(os.getpid())); time.sleep(10)
