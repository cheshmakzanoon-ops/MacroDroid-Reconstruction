from pathlib import Path; import os,sys; p=Path(sys.argv[1]); os.link(p,p.with_name("extra-hardlink.txt")); print("two links", flush=True)
