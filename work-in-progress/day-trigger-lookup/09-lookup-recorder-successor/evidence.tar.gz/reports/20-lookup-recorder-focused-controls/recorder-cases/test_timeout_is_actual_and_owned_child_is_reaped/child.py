from pathlib import Path; import os,time; Path("child.pid").write_text(str(os.getpid())); print("before timeout", flush=True); time.sleep(10)
