import sys; print("unexpected seven", file=sys.stderr, flush=True); sys.exit(7)
