from pathlib import Path; import os,sys; p=Path(sys.argv[1]); q=p.with_name("replacement.txt"); q.write_bytes(b"replacement contents\n"); os.replace(q,p)
