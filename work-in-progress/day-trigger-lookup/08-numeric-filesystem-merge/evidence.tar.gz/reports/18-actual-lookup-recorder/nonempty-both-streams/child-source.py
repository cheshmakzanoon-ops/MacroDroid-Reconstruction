import sys; print("bounded stdout", flush=True); print("bounded stderr", file=sys.stderr, flush=True)
