import sys; print("intentional seven", file=sys.stderr, flush=True); sys.exit(7)
