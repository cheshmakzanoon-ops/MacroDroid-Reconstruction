from pathlib import Path; Path("would-have-run").write_text("incorrect")
