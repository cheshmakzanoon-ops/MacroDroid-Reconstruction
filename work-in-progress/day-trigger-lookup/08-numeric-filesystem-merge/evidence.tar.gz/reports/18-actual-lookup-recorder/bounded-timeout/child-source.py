from pathlib import Path; import os,time; Path("child.pid").write_text(str(os.getpid())); print("before bounded timeout", flush=True); time.sleep(10)
