from pathlib import Path
import datetime, json, sys, time, unittest
root = Path(sys.argv[1])
sys.path[:0] = [str(root / 'repository/tools/parity_journeys'), str(root / 'repository/project')]
scope = sys.argv[2]
suite = (unittest.defaultTestLoader.loadTestsFromNames([
    'test_exact_alarm_enable_return', 'test_exact_alarm_enable_return_readiness']) if scope == 'focused' else
    unittest.defaultTestLoader.discover(str(root / 'repository/tools/parity_journeys'), pattern='test_*.py'))
def flatten(test):
    if isinstance(test, unittest.TestSuite):
        for value in test: yield from flatten(value)
    else: yield test.id()
ids = list(flatten(suite))
assert len(ids) == len(set(ids)), 'Duplicate discovered test identity'
(root / 'discovered-tests.json').write_text(json.dumps(ids, indent=2) + '\n')
start = time.monotonic()
result = unittest.TextTestRunner(verbosity=2).run(suite)
value = {'schema': 1, 'scope': scope, 'tests_discovered': len(ids), 'tests_run': result.testsRun,
         'failures': [{'test': item.id(), 'traceback': trace} for item, trace in result.failures],
         'errors': [{'test': item.id(), 'traceback': trace} for item, trace in result.errors],
         'skipped': result.skipped, 'unexpected_successes': [item.id() for item in result.unexpectedSuccesses],
         'seconds': time.monotonic() - start, 'passed': result.wasSuccessful(),
         'android_executed': False, 'application_build_executed': False,
         'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root / 'tests-result.json').write_text(json.dumps(value, indent=2) + '\n')
raise SystemExit(0 if value['passed'] else 1)
