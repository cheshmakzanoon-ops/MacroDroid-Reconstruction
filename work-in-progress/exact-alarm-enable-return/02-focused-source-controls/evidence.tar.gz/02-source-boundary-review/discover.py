from pathlib import Path
import json, sys, unittest
root=Path(sys.argv[1]); sys.path[:0]=[str(root/'tools/parity_journeys'),str(root/'project')]
suite=unittest.defaultTestLoader.discover(str(root/'tools/parity_journeys'),pattern='test_*.py')
def flat(s):
 if isinstance(s,unittest.TestSuite):
  for v in s: yield from flat(v)
 else: yield s.id()
ids=list(flat(suite));assert len(ids)==len(set(ids));print(json.dumps(ids,indent=2))
