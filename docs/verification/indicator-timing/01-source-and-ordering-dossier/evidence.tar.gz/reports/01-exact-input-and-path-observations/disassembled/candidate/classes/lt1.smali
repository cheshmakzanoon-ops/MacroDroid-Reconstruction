.class public final Llt1;
.super Ljava/lang/Object;
.source "r8-map-id-43b0b16dc0073b4b53e316177ca478d827b877826459072a6fdbad625fa2dd5f"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final b:I

.field public final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(ILh6h;)V
    .locals 2

    .line 1
    const/4 v0, 0x6

    .line 2
    iput v0, p0, Llt1;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput p1, p0, Llt1;->b:I

    .line 8
    .line 9
    iput-object p2, p0, Llt1;->c:Ljava/lang/Object;

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;II)V
    .locals 1

    .line 12
    iput p3, p0, Llt1;->a:I

    iput-object p1, p0, Llt1;->c:Ljava/lang/Object;

    iput p2, p0, Llt1;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Llt1;->a:I

    .line 2
    .line 3
    iget v1, p0, Llt1;->b:I

    .line 4
    .line 5
    iget-object p0, p0, Llt1;->c:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 v3, 0x6

    packed-switch v0, :pswitch_data_98

    .line 8
    .line 9
    .line 10
    check-cast p0, Landroidx/recyclerview/widget/RecyclerView;

    .line 11
    .line 12
    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->s0(I)V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_13
    const/4 v3, 0x5

    check-cast p0, Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;

    .line 17
    .line 18
    sget v0, Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;->b:I

    .line 19
    .line 20
    invoke-virtual {p0}, Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;->N()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_22

    .line 25
    .line 26
    const/4 v3, 0x5

    add-int/lit8 v0, v1, 0x1

    .line 27
    .line 28
    goto :goto_23

    .line 29
    :cond_22
    move v0, v1

    .line 30
    :goto_23
    invoke-static {p0, v0}, Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;->G(Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;I)V

    .line 31
    .line 32
    .line 33
    invoke-static {p0}, Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;->z(Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;)Li0e;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iput v1, v0, Li0e;->w:I

    .line 38
    .line 39
    invoke-virtual {p0, v1}, Lcom/arlosoft/macrodroid/smartmaterialspinner/SmartMaterialSpinner;->H(I)V

    .line 40
    .line 41
    .line 42
    const/4 v3, 0x1

    return-void

    .line 43
    :pswitch_31
    check-cast p0, Lty9;

    .line 44
    .line 45
    iget-object p0, p0, Lty9;->b:Ljava/lang/Object;

    .line 46
    .line 47
    const/4 v3, 0x2

    check-cast p0, Lagency/tango/materialintroscreen/MaterialIntroActivity;

    .line 48
    .line 49
    const/4 v3, 0x5

    iget-object v0, p0, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 50
    .line 51
    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcre;->m(I)Lxpe;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    iget-object v2, v0, Lxpe;->h:[Ljava/lang/String;

    .line 56
    .line 57
    invoke-virtual {v0, v2}, Lxpe;->q([Ljava/lang/String;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-nez v0, :cond_53

    .line 62
    .line 63
    iget-object p0, p0, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 64
    .line 65
    invoke-virtual {p0, v1}, Lcre;->m(I)Lxpe;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    goto :goto_67

    .line 73
    :cond_53
    iget-object v0, p0, Lagency/tango/materialintroscreen/MaterialIntroActivity;->j:Lagency/tango/materialintroscreen/widgets/SwipeableViewPager;

    .line 74
    .line 75
    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    .line 76
    .line 77
    .line 78
    const/4 v3, 0x6

    iget-object p0, p0, Lagency/tango/materialintroscreen/MaterialIntroActivity;->k:Lagency/tango/materialintroscreen/widgets/InkPageIndicator;

    .line 79
    .line 80
    iget-object v0, p0, Lagency/tango/materialintroscreen/widgets/InkPageIndicator;->z:[F

    .line 81
    .line 82
    const/4 v1, 0x0

    .line 83
    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([FF)V

    .line 84
    .line 85
    .line 86
    sget-object v0, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 87
    .line 88
    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 89
    .line 90
    .line 91
    :goto_67
    return-void

    .line 92
    :pswitch_68
    check-cast p0, Lid;

    .line 93
    .line 94
    iget-object p0, p0, Lid;->b:Ljava/lang/Object;

    .line 95
    .line 96
    check-cast p0, Lky9;

    .line 97
    .line 98
    iget-object v0, p0, Lky9;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 99
    .line 100
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 101
    .line 102
    .line 103
    iget-object p0, p0, Lky9;->c:Lgy9;

    .line 104
    .line 105
    const/4 v3, 0x3

    iget-object p0, p0, Lgy9;->J:Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 106
    .line 107
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->scrollToPosition(I)V

    .line 108
    .line 109
    .line 110
    return-void

    .line 111
    :pswitch_7c
    check-cast p0, Landroid/widget/ListView;

    .line 112
    .line 113
    invoke-virtual {p0, v1}, Landroid/widget/ListView;->setSelection(I)V

    .line 114
    .line 115
    .line 116
    return-void

    .line 117
    :pswitch_82
    check-cast p0, Lcom/jaredrummler/android/colorpicker/ColorPanelView;

    .line 118
    .line 119
    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/jaredrummler/android/colorpicker/ColorPanelView;->setColor(I)V

    .line 120
    .line 121
    .line 122
    const/4 v3, 0x6

    return-void

    .line 123
    :pswitch_8a
    check-cast p0, Lx3e;

    .line 124
    .line 125
    iget-object p0, p0, Lx3e;->b:Ljava/lang/Object;

    .line 126
    .line 127
    const/4 v3, 0x0

    check-cast p0, Lhae;

    .line 128
    .line 129
    if-eqz p0, :cond_96

    .line 130
    .line 131
    invoke-virtual {p0, v1}, Lhae;->E(I)V

    .line 132
    .line 133
    .line 134
    :cond_96
    return-void

    nop

    .line 135
    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_8a
        :pswitch_82
        :pswitch_7c
        :pswitch_68
        :pswitch_31
        :pswitch_13
    .end packed-switch
.end method
