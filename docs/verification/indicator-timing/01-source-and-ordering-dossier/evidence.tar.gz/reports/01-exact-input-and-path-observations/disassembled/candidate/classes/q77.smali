.class public abstract synthetic Lq77;
.super Ljava/lang/Object;
.source "r8-map-id-43b0b16dc0073b4b53e316177ca478d827b877826459072a6fdbad625fa2dd5f"


# direct methods
.method public static A(Ljava/lang/String;IC)Ljava/lang/String;
    .locals 2

    .line 1
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method

.method public static B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;
    .locals 0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static C(Ljava/lang/Throwable;Ljava/lang/StringBuilder;)Ljava/lang/String;
    .locals 1

    .line 1
    const/4 v0, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public static D(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;
    .locals 2

    .line 1
    const/4 v1, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const/4 v1, 0x1

    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    return-object v0
.end method

.method public static E(IIIII)V
    .locals 1

    .line 1
    invoke-static {p0}, Ljla;->a(I)J

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x4

    invoke-static {p1}, Ljla;->a(I)J

    .line 5
    .line 6
    .line 7
    invoke-static {p2}, Ljla;->a(I)J

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x2

    invoke-static {p3}, Ljla;->a(I)J

    .line 11
    .line 12
    .line 13
    invoke-static {p4}, Ljla;->a(I)J

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public static F(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 1

    .line 1
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const/4 v0, 0x5

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    const/4 v0, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public static G(Ljava/lang/String;Ljava/lang/String;Lcom/inmobi/media/y9;Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const/4 v1, 0x1

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {p2, p3, p0}, Lcom/inmobi/media/y9;->b(Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public static H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    return-void
.end method

.method public static I(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .locals 2

    .line 1
    new-instance v0, Ljavax/mail/internet/InternetHeaders$InternetHeader;

    .line 2
    .line 3
    invoke-direct {v0, p0, p1}, Ljavax/mail/internet/InternetHeaders$InternetHeader;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public static J(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static K(Ljava/lang/StringBuilder;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static synthetic L(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-eqz p0, :cond_5

    .line 2
    .line 3
    const/4 p0, 0x1

    .line 4
    const/4 v0, 0x5

    return p0

    .line 5
    :cond_5
    const/4 p0, 0x0

    .line 6
    return p0
.end method

.method public static synthetic M(Ljava/util/List;)Z
    .locals 1

    .line 1
    if-eqz p0, :cond_5

    .line 2
    .line 3
    const/4 v0, 0x0

    const/4 p0, 0x1

    .line 4
    return p0

    .line 5
    :cond_5
    const/4 p0, 0x0

    move v0, p0

    .line 6
    return p0
.end method

.method public static N(Lmm3;I)Ll29;
    .locals 11

    .line 1
    const/4 v10, 0x2

    iget-object p0, p0, Lmm3;->b:Ljava/lang/Object;

    .line 2
    .line 3
    const/4 v10, 0x2

    check-cast p0, Lz39;

    .line 4
    .line 5
    const/4 v10, 0x4

    invoke-static {}, Lf54;->r()Lvte;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v10, 0x5

    if-eqz v1, :cond_14

    .line 10
    .line 11
    invoke-virtual {v1}, Lvte;->e()Lwm6;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    :goto_12
    move-object v2, v0

    .line 16
    goto :goto_16

    .line 17
    :cond_14
    const/4 v0, 0x0

    .line 18
    goto :goto_12

    .line 19
    :goto_16
    invoke-static {v1}, Lf54;->C(Lvte;)Lvte;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    :try_start_1a
    const/4 v10, 0x6

    iget-object v0, p0, Lz39;->f:Leia;

    .line 24
    .line 25
    check-cast v0, Lnue;

    .line 26
    .line 27
    invoke-virtual {v0}, Lnue;->getValue()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    const/4 v10, 0x4

    check-cast v0, Lp39;
    :try_end_26
    .catchall {:try_start_1a .. :try_end_26} :catchall_3b

    .line 32
    .line 33
    invoke-static {v1, v3, v2}, Lf54;->K(Lvte;Lvte;Lwm6;)V

    .line 34
    .line 35
    .line 36
    iget-object v4, p0, Lz39;->q:Lm29;

    .line 37
    .line 38
    iget-wide v6, v0, Lp39;->j:J

    .line 39
    .line 40
    iget-boolean v8, p0, Lz39;->d:Z

    .line 41
    .line 42
    new-instance v9, Llg7;

    .line 43
    .line 44
    invoke-direct {v9, p1, v0}, Llg7;-><init>(ILp39;)V

    .line 45
    .line 46
    .line 47
    move v5, p1

    .line 48
    invoke-virtual/range {v4 .. v9}, Lm29;->a(IJZLwm6;)Ll29;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    const/4 v10, 0x3

    return-object p0

    .line 53
    :catchall_3b
    move-exception v0

    .line 54
    move-object p0, v0

    .line 55
    const/4 v10, 0x6

    invoke-static {v1, v3, v2}, Lf54;->K(Lvte;Lvte;Lwm6;)V

    .line 56
    .line 57
    .line 58
    throw p0
.end method

.method public static O(Lft7;)V
    .locals 3

    .line 1
    invoke-interface {p0}, Lft7;->z()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-interface {p0}, Lft7;->v()Landroid/util/Size;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x1

    if-eqz v1, :cond_d

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    goto :goto_e

    .line 13
    :cond_d
    const/4 v1, 0x0

    .line 14
    :goto_e
    if-eqz v0, :cond_1a

    .line 15
    .line 16
    if-nez v1, :cond_13

    .line 17
    .line 18
    goto :goto_1a

    .line 19
    :cond_13
    const-string p0, "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."

    .line 20
    .line 21
    const/4 v2, 0x7

    invoke-static {p0}, Lbb1;->o(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_1a
    :goto_1a
    const/4 v2, 0x7

    invoke-interface {p0}, Lft7;->q()Lx0d;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    if-eqz p0, :cond_2c

    .line 30
    .line 31
    if-nez v0, :cond_26

    .line 32
    .line 33
    if-nez v1, :cond_26

    .line 34
    .line 35
    goto :goto_2c

    .line 36
    :cond_26
    const-string p0, "Cannot use setTargetResolution or setTargetAspectRatio with setResolutionSelector on the same config."

    .line 37
    .line 38
    const/4 v2, 0x4

    invoke-static {p0}, Lbb1;->o(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :cond_2c
    :goto_2c
    return-void
.end method

.method public static a(Lft7;)I
    .locals 3

    .line 1
    sget-object v0, Lft7;->b2:Lwv0;

    .line 2
    .line 3
    const/4 v2, 0x7

    const/4 v1, -0x1

    .line 4
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-interface {p0, v0, v1}, Lfx2;->k(Lwv0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Ljava/lang/Integer;

    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    const/4 v2, 0x0

    return p0
.end method

.method public static b(Lft7;)Ljava/util/ArrayList;
    .locals 3

    .line 1
    const/4 v2, 0x6

    sget-object v0, Lft7;->j2:Lwv0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x3

    invoke-interface {p0, v0, v1}, Lfx2;->k(Lwv0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Ljava/util/List;

    .line 9
    .line 10
    if-eqz p0, :cond_15

    .line 11
    .line 12
    new-instance v0, Ljava/util/ArrayList;

    .line 13
    .line 14
    const/4 v2, 0x0

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x1

    return-object v0

    .line 18
    :cond_15
    return-object v1
.end method

.method public static c(Lyog;)Ll25;
    .locals 3

    .line 1
    sget-object v0, Ljs7;->Y1:Lwv0;

    .line 2
    .line 3
    const/4 v2, 0x4

    sget-object v1, Ll25;->c:Ll25;

    .line 4
    .line 5
    invoke-interface {p0, v0, v1}, Lfx2;->k(Lwv0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Ll25;

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const/4 v2, 0x5

    return-object p0
.end method

.method public static d(Lft7;)I
    .locals 3

    .line 1
    sget-object v0, Lft7;->c2:Lwv0;

    .line 2
    .line 3
    const/4 v2, 0x4

    const/4 v1, -0x1

    .line 4
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const/4 v2, 0x5

    invoke-interface {p0, v0, v1}, Lfx2;->k(Lwv0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Ljava/lang/Integer;

    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    const/4 v2, 0x7

    return p0
.end method

.method public static e(Lft7;I)I
    .locals 2

    .line 1
    sget-object v0, Lft7;->a2:Lwv0;

    .line 2
    .line 3
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {p0, v0, p1}, Lfx2;->k(Lwv0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    const/4 v1, 0x0

    check-cast p0, Ljava/lang/Integer;

    .line 12
    .line 13
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    return p0
.end method

.method public static f(Lei9;Lv59;)Z
    .locals 3

    .line 1
    invoke-virtual {p1}, Lv59;->toInt()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v2, 0x3

    if-eqz v0, :cond_3b

    .line 6
    .line 7
    const/16 v1, 0xa

    .line 8
    .line 9
    if-eq v0, v1, :cond_36

    .line 10
    .line 11
    const/4 v2, 0x5

    const/16 v1, 0x14

    .line 12
    .line 13
    if-eq v0, v1, :cond_30

    .line 14
    .line 15
    const/16 v1, 0x1e

    .line 16
    .line 17
    if-eq v0, v1, :cond_2a

    .line 18
    .line 19
    const/4 v2, 0x0

    const/16 v1, 0x28

    .line 20
    .line 21
    if-ne v0, v1, :cond_1e

    .line 22
    .line 23
    invoke-interface {p0}, Lei9;->isErrorEnabled()Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    return p0

    .line 28
    :cond_1e
    const/4 v2, 0x6

    const-string p0, "Level ["

    .line 29
    .line 30
    const-string v0, "] not recognized."

    .line 31
    .line 32
    const/4 v2, 0x2

    invoke-static {p1, v0, p0}, Lir8;->k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const/4 p0, 0x0

    .line 36
    const/4 v2, 0x3

    return p0

    .line 37
    :cond_2a
    invoke-interface {p0}, Lei9;->isWarnEnabled()Z

    .line 38
    .line 39
    .line 40
    move-result p0

    .line 41
    const/4 v2, 0x1

    return p0

    .line 42
    :cond_30
    invoke-interface {p0}, Lei9;->isInfoEnabled()Z

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    const/4 v2, 0x3

    return p0

    .line 47
    :cond_36
    invoke-interface {p0}, Lei9;->isDebugEnabled()Z

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    return p0

    .line 52
    :cond_3b
    const/4 v2, 0x0

    invoke-interface {p0}, Lei9;->isTraceEnabled()Z

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    return p0
.end method

.method public static g(Lov8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lm0a;->Max:Lm0a;

    .line 4
    .line 5
    sget-object v2, Ln0a;->Height:Ln0a;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x0

    .line 12
    const/16 v1, 0xd

    .line 13
    .line 14
    invoke-static {p2, p3, p2, p2, v1}, Li23;->b(IIIII)J

    .line 15
    .line 16
    .line 17
    move-result-wide p2

    .line 18
    new-instance v1, Lp68;

    .line 19
    .line 20
    const/4 v4, 0x5

    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 25
    .line 26
    .line 27
    invoke-interface {p0, v1, v0, p2, p3}, Lov8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-interface {p0}, Lvz9;->getHeight()I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    const/4 v4, 0x0

    return p0
.end method

.method public static h(Lqv8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lzsa;->Max:Lzsa;

    .line 4
    .line 5
    sget-object v2, Lata;->Height:Lata;

    .line 6
    .line 7
    const/4 v4, 0x5

    const/4 v3, 0x2

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 v4, 0x5

    const/4 p2, 0x0

    .line 12
    const/16 v1, 0xd

    .line 13
    .line 14
    invoke-static {p2, p3, p2, p2, v1}, Li23;->b(IIIII)J

    .line 15
    .line 16
    .line 17
    move-result-wide p2

    .line 18
    new-instance v1, Lp68;

    .line 19
    .line 20
    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 25
    .line 26
    .line 27
    invoke-interface {p0, v1, v0, p2, p3}, Lqv8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    const/4 v4, 0x7

    invoke-interface {p0}, Lvz9;->getHeight()I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    const/4 v4, 0x4

    return p0
.end method

.method public static i(Lov8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    new-instance v0, Lua4;

    .line 2
    .line 3
    const/4 v4, 0x1

    sget-object v1, Lm0a;->Max:Lm0a;

    .line 4
    .line 5
    sget-object v2, Ln0a;->Width:Ln0a;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x3

    const/4 p2, 0x0

    .line 12
    const/4 v1, 0x7

    .line 13
    const/4 v4, 0x6

    invoke-static {p2, p2, p2, p3, v1}, Li23;->b(IIIII)J

    .line 14
    .line 15
    .line 16
    move-result-wide p2

    .line 17
    const/4 v4, 0x2

    new-instance v1, Lp68;

    .line 18
    .line 19
    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const/4 v4, 0x5

    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 24
    .line 25
    .line 26
    const/4 v4, 0x1

    invoke-interface {p0, v1, v0, p2, p3}, Lov8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    const/4 v4, 0x2

    invoke-interface {p0}, Lvz9;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    return p0
.end method

.method public static j(Lqv8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    const/4 v4, 0x6

    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lzsa;->Max:Lzsa;

    .line 4
    .line 5
    const/4 v4, 0x3

    sget-object v2, Lata;->Width:Lata;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x6

    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x0

    .line 12
    const/4 v1, 0x7

    move v4, v1

    .line 13
    invoke-static {p2, p2, p2, p3, v1}, Li23;->b(IIIII)J

    .line 14
    .line 15
    .line 16
    move-result-wide p2

    .line 17
    const/4 v4, 0x1

    new-instance v1, Lp68;

    .line 18
    .line 19
    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const/4 v4, 0x2

    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 24
    .line 25
    .line 26
    invoke-interface {p0, v1, v0, p2, p3}, Lqv8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    const/4 v4, 0x5

    invoke-interface {p0}, Lvz9;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    const/4 v4, 0x1

    return p0
.end method

.method public static k(Lov8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lm0a;->Min:Lm0a;

    .line 4
    .line 5
    sget-object v2, Ln0a;->Height:Ln0a;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x0

    .line 12
    const/16 v1, 0xd

    .line 13
    .line 14
    invoke-static {p2, p3, p2, p2, v1}, Li23;->b(IIIII)J

    .line 15
    .line 16
    .line 17
    move-result-wide p2

    .line 18
    const/4 v4, 0x2

    new-instance v1, Lp68;

    .line 19
    .line 20
    const/4 v4, 0x7

    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    const/4 v4, 0x6

    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 25
    .line 26
    .line 27
    const/4 v4, 0x4

    invoke-interface {p0, v1, v0, p2, p3}, Lov8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-interface {p0}, Lvz9;->getHeight()I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    return p0
.end method

.method public static l(Lqv8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lzsa;->Min:Lzsa;

    .line 4
    .line 5
    const/4 v4, 0x6

    sget-object v2, Lata;->Height:Lata;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x4

    const/4 p2, 0x0

    .line 12
    const/16 v1, 0xd

    .line 13
    .line 14
    invoke-static {p2, p3, p2, p2, v1}, Li23;->b(IIIII)J

    .line 15
    .line 16
    .line 17
    move-result-wide p2

    .line 18
    const/4 v4, 0x7

    new-instance v1, Lp68;

    .line 19
    .line 20
    const/4 v4, 0x3

    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    const/4 v4, 0x1

    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 25
    .line 26
    .line 27
    invoke-interface {p0, v1, v0, p2, p3}, Lqv8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    const/4 v4, 0x7

    invoke-interface {p0}, Lvz9;->getHeight()I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    const/4 v4, 0x4

    return p0
.end method

.method public static m(Lov8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    const/4 v4, 0x3

    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lm0a;->Min:Lm0a;

    .line 4
    .line 5
    sget-object v2, Ln0a;->Width:Ln0a;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x0

    .line 12
    const/4 v1, 0x7

    move v4, v1

    .line 13
    invoke-static {p2, p2, p2, p3, v1}, Li23;->b(IIIII)J

    .line 14
    .line 15
    .line 16
    move-result-wide p2

    .line 17
    const/4 v4, 0x0

    new-instance v1, Lp68;

    .line 18
    .line 19
    const/4 v4, 0x4

    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const/4 v4, 0x4

    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 24
    .line 25
    .line 26
    invoke-interface {p0, v1, v0, p2, p3}, Lov8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    invoke-interface {p0}, Lvz9;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    const/4 v4, 0x7

    return p0
.end method

.method public static n(Lqv8;Lc68;Lb68;I)I
    .locals 5

    .line 1
    const/4 v4, 0x0

    new-instance v0, Lua4;

    .line 2
    .line 3
    sget-object v1, Lzsa;->Min:Lzsa;

    .line 4
    .line 5
    sget-object v2, Lata;->Width:Lata;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    invoke-direct {v0, p2, v1, v2, v3}, Lua4;-><init>(Lb68;Ljava/lang/Enum;Ljava/lang/Enum;I)V

    .line 9
    .line 10
    .line 11
    const/4 p2, 0x0

    .line 12
    const/4 v4, 0x0

    const/4 v1, 0x7

    .line 13
    invoke-static {p2, p2, p2, p3, v1}, Li23;->b(IIIII)J

    .line 14
    .line 15
    .line 16
    move-result-wide p2

    .line 17
    new-instance v1, Lp68;

    .line 18
    .line 19
    invoke-interface {p1}, Lc68;->getLayoutDirection()Lgv8;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    const/4 v4, 0x6

    invoke-direct {v1, p1, v2}, Lp68;-><init>(Lc68;Lgv8;)V

    .line 24
    .line 25
    .line 26
    invoke-interface {p0, v1, v0, p2, p3}, Lqv8;->measure-3p2s80s(Lwz9;Llz9;J)Lvz9;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    const/4 v4, 0x5

    invoke-interface {p0}, Lvz9;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    const/4 v4, 0x5

    return p0
.end method

.method public static o(Ljava/io/InputStream;Ljava/lang/String;Ljava/nio/charset/Charset;)Lqrb;
    .locals 7

    .line 1
    const/4 v6, 0x2

    const/16 v0, 0x2e

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v6, 0x7

    const/4 v1, 0x1

    .line 8
    add-int/2addr v0, v1

    .line 9
    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    const/4 v6, 0x6

    const/4 v3, 0x0

    .line 29
    const/4 v4, -0x1

    .line 30
    const/4 v6, 0x3

    sparse-switch v2, :sswitch_data_ea

    .line 31
    .line 32
    .line 33
    :goto_26
    move v1, v4

    .line 34
    goto :goto_87

    .line 35
    :sswitch_28
    const/4 v6, 0x0

    const-string v1, "yaml-tmlanguage"

    .line 36
    .line 37
    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    const/4 v6, 0x0

    if-nez v0, :cond_34

    .line 42
    .line 43
    goto :goto_26

    .line 44
    :cond_34
    const/4 v6, 0x5

    const/4 v1, 0x6

    .line 45
    const/4 v6, 0x3

    goto :goto_87

    .line 46
    :sswitch_38
    const-string v1, "tmlanguage"

    .line 47
    .line 48
    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_42

    .line 53
    .line 54
    goto :goto_26

    .line 55
    :cond_42
    const/4 v6, 0x0

    const/4 v1, 0x5

    .line 56
    goto :goto_87

    .line 57
    :sswitch_45
    const/4 v6, 0x5

    const-string v1, "plist"

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_4f

    .line 64
    .line 65
    goto :goto_26

    .line 66
    :cond_4f
    const/4 v6, 0x5

    const/4 v1, 0x4

    .line 67
    goto :goto_87

    .line 68
    :sswitch_52
    const-string v1, "lmay"

    const-string v1, "yaml"

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    const/4 v6, 0x5

    if-nez v0, :cond_5e

    .line 75
    .line 76
    goto :goto_26

    .line 77
    :cond_5e
    const/4 v1, 0x3

    .line 78
    const/4 v6, 0x5

    goto :goto_87

    .line 79
    :sswitch_61
    const/4 v6, 0x6

    const-string v1, "json"

    .line 80
    .line 81
    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    const/4 v6, 0x6

    if-nez v0, :cond_6d

    .line 86
    .line 87
    goto :goto_26

    .line 88
    :cond_6d
    const/4 v6, 0x1

    const/4 v1, 0x2

    .line 89
    const/4 v6, 0x4

    goto :goto_87

    .line 90
    :sswitch_71
    const/4 v6, 0x2

    const-string v2, "yml"

    .line 91
    .line 92
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-nez v0, :cond_87

    .line 97
    .line 98
    goto :goto_26

    .line 99
    :sswitch_7b
    const-string v1, "xml"

    .line 100
    .line 101
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    const/4 v6, 0x2

    if-nez v0, :cond_85

    .line 106
    .line 107
    goto :goto_26

    .line 108
    :cond_85
    move v1, v3

    move v1, v3

    .line 109
    :cond_87
    :goto_87
    const/4 v6, 0x4

    const/4 v0, 0x0

    .line 110
    packed-switch v1, :pswitch_data_108

    .line 111
    .line 112
    .line 113
    const-string p0, "Unsupported file type: "

    .line 114
    .line 115
    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    const/4 v6, 0x7

    invoke-static {p0}, Lbb1;->o(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    const/4 v6, 0x1

    return-object v0

    .line 123
    :pswitch_98
    sget-object v1, Lfm7;->JSON:Lfm7;

    .line 124
    .line 125
    goto :goto_a1

    .line 126
    :pswitch_9b
    sget-object v1, Lfm7;->YAML:Lfm7;

    .line 127
    .line 128
    const/4 v6, 0x1

    goto :goto_a1

    .line 129
    :pswitch_9f
    sget-object v1, Lfm7;->XML:Lfm7;

    .line 130
    .line 131
    :goto_a1
    :try_start_a1
    const/4 v6, 0x7

    new-instance v2, Ljava/io/BufferedReader;

    .line 132
    .line 133
    new-instance v5, Ljava/io/InputStreamReader;

    .line 134
    .line 135
    if-nez p2, :cond_ae

    .line 136
    .line 137
    const/4 v6, 0x3

    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 138
    .line 139
    goto :goto_ae

    .line 140
    :catch_ac
    move-exception p0

    .line 141
    goto :goto_e5

    .line 142
    :cond_ae
    :goto_ae
    invoke-direct {v5, p0, p2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    .line 143
    .line 144
    .line 145
    invoke-direct {v2, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_b4
    .catch Ljava/lang/Exception; {:try_start_a1 .. :try_end_b4} :catch_ac

    .line 146
    .line 147
    .line 148
    :try_start_b4
    const/4 v6, 0x7

    new-instance p0, Ljava/lang/StringBuilder;

    .line 149
    .line 150
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 151
    .line 152
    .line 153
    const/16 p2, 0x4000

    .line 154
    .line 155
    new-array p2, p2, [C

    .line 156
    .line 157
    :cond_be
    :goto_be
    invoke-virtual {v2, p2}, Ljava/io/Reader;->read([C)I

    .line 158
    .line 159
    .line 160
    move-result v5

    .line 161
    if-eq v5, v4, :cond_cd

    .line 162
    .line 163
    if-lez v5, :cond_be

    .line 164
    .line 165
    invoke-virtual {p0, p2, v3, v5}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    const/4 v6, 0x7

    goto :goto_be

    .line 169
    :catchall_cb
    move-exception p0

    .line 170
    goto :goto_d9

    .line 171
    :cond_cd
    new-instance p2, Lqrb;

    .line 172
    .line 173
    const/16 v3, 0x18

    .line 174
    .line 175
    const/4 v6, 0x6

    invoke-direct {p2, p1, p0, v1, v3}, Lqrb;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    :try_end_d5
    .catchall {:try_start_b4 .. :try_end_d5} :catchall_cb

    .line 176
    .line 177
    .line 178
    :try_start_d5
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_d8
    .catch Ljava/lang/Exception; {:try_start_d5 .. :try_end_d8} :catch_ac

    .line 179
    .line 180
    .line 181
    return-object p2

    .line 182
    :goto_d9
    :try_start_d9
    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_dd
    .catchall {:try_start_d9 .. :try_end_dd} :catchall_de

    .line 183
    .line 184
    .line 185
    goto :goto_e3

    .line 186
    :catchall_de
    move-exception p1

    .line 187
    :try_start_df
    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 188
    .line 189
    .line 190
    :goto_e3
    const/4 v6, 0x1

    throw p0
    :try_end_e5
    .catch Ljava/lang/Exception; {:try_start_df .. :try_end_e5} :catch_ac

    .line 191
    :goto_e5
    invoke-static {p0}, Lx47;->q(Ljava/lang/Throwable;)V

    .line 192
    .line 193
    .line 194
    return-object v0

    nop

    .line 195
    :sswitch_data_ea
    .sparse-switch
        0x1d017 -> :sswitch_7b
        0x1d3d8 -> :sswitch_71
        0x31ece8 -> :sswitch_61
        0x387aa7 -> :sswitch_52
        0x65cf90e -> :sswitch_45
        0x723d18d1 -> :sswitch_38
        0x78eaabb7 -> :sswitch_28
    .end sparse-switch

    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    :pswitch_data_108
    .packed-switch 0x0
        :pswitch_9f
        :pswitch_9b
        :pswitch_98
        :pswitch_9b
        :pswitch_9f
        :pswitch_9f
        :pswitch_9b
    .end packed-switch
.end method

.method public static p(Ljava/io/InputStream;Ljava/lang/String;)Li0g;
    .locals 8

    .line 1
    const/16 v0, 0x2e

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v7, 0x3

    const/4 v1, 0x1

    .line 8
    add-int/2addr v0, v1

    .line 9
    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    const/4 v7, 0x5

    const/4 v3, 0x0

    .line 29
    const/4 v4, -0x1

    move v7, v4

    .line 30
    sparse-switch v2, :sswitch_data_e2

    .line 31
    .line 32
    .line 33
    :goto_25
    move v1, v4

    .line 34
    goto :goto_83

    .line 35
    :sswitch_27
    const-string v1, "plist"

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    if-nez v0, :cond_30

    .line 42
    .line 43
    goto :goto_25

    .line 44
    :cond_30
    const/4 v1, 0x6

    .line 45
    goto :goto_83

    .line 46
    :sswitch_32
    const-string v1, "yaml"

    .line 47
    .line 48
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    const/4 v7, 0x3

    if-nez v0, :cond_3c

    .line 53
    .line 54
    goto :goto_25

    .line 55
    :cond_3c
    const/4 v1, 0x5

    .line 56
    const/4 v7, 0x5

    goto :goto_83

    .line 57
    :sswitch_3f
    const-string v1, "ojns"

    const-string v1, "json"

    .line 58
    .line 59
    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_4b

    .line 64
    .line 65
    goto :goto_25

    .line 66
    :cond_4b
    const/4 v7, 0x7

    const/4 v1, 0x4

    .line 67
    const/4 v7, 0x6

    goto :goto_83

    .line 68
    :sswitch_4f
    const-string v1, "myl"

    const-string v1, "yml"

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-nez v0, :cond_5a

    .line 75
    .line 76
    goto :goto_25

    .line 77
    :cond_5a
    const/4 v1, 0x3

    .line 78
    goto :goto_83

    .line 79
    :sswitch_5c
    const/4 v7, 0x4

    const-string v1, "xml"

    .line 80
    .line 81
    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    const/4 v7, 0x3

    if-nez v0, :cond_68

    .line 86
    .line 87
    goto :goto_25

    .line 88
    :cond_68
    const/4 v1, 0x2

    .line 89
    const/4 v7, 0x6

    goto :goto_83

    .line 90
    :sswitch_6b
    const-string v2, "tmtheme"

    .line 91
    .line 92
    const/4 v7, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    const/4 v7, 0x4

    if-nez v0, :cond_83

    .line 97
    .line 98
    goto :goto_25

    .line 99
    :sswitch_76
    const-string v1, "yaml-tmtheme"

    .line 100
    .line 101
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    const/4 v7, 0x7

    if-nez v0, :cond_80

    .line 106
    .line 107
    goto :goto_25

    .line 108
    :cond_80
    const/4 v7, 0x2

    move v1, v3

    move v1, v3

    .line 109
    :cond_83
    :goto_83
    const/4 v7, 0x3

    const/4 v0, 0x0

    .line 110
    const/4 v7, 0x7

    packed-switch v1, :pswitch_data_100

    .line 111
    .line 112
    .line 113
    const/4 v7, 0x3

    const-string p0, "Unsupported file type: "

    .line 114
    .line 115
    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    invoke-static {p0}, Lbb1;->o(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    return-object v0

    .line 123
    :pswitch_94
    sget-object v1, Lxo7;->JSON:Lxo7;

    .line 124
    .line 125
    goto :goto_9c

    .line 126
    :pswitch_97
    sget-object v1, Lxo7;->XML:Lxo7;

    .line 127
    .line 128
    goto :goto_9c

    .line 129
    :pswitch_9a
    sget-object v1, Lxo7;->YAML:Lxo7;

    .line 130
    .line 131
    :goto_9c
    :try_start_9c
    new-instance v2, Ljava/io/BufferedReader;

    .line 132
    .line 133
    new-instance v5, Ljava/io/InputStreamReader;

    .line 134
    .line 135
    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 136
    .line 137
    invoke-direct {v5, p0, v6}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    .line 138
    .line 139
    .line 140
    invoke-direct {v2, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_a8
    .catch Ljava/lang/Exception; {:try_start_9c .. :try_end_a8} :catch_d0

    .line 141
    .line 142
    .line 143
    :try_start_a8
    new-instance p0, Ljava/lang/StringBuilder;

    .line 144
    .line 145
    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    .line 146
    .line 147
    .line 148
    const/4 v7, 0x1

    const/16 v5, 0x4000

    .line 149
    .line 150
    new-array v5, v5, [C

    .line 151
    .line 152
    :cond_b2
    :goto_b2
    invoke-virtual {v2, v5}, Ljava/io/Reader;->read([C)I

    .line 153
    .line 154
    .line 155
    move-result v6

    .line 156
    const/4 v7, 0x1

    if-eq v6, v4, :cond_c4

    .line 157
    .line 158
    const/4 v7, 0x3

    if-lez v6, :cond_b2

    .line 159
    .line 160
    invoke-virtual {p0, v5, v3, v6}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    const/4 v7, 0x7

    goto :goto_b2

    .line 164
    :catchall_c1
    move-exception p0

    .line 165
    const/4 v7, 0x3

    goto :goto_d2

    .line 166
    :cond_c4
    const/4 v7, 0x0

    new-instance v3, Li0g;

    .line 167
    .line 168
    const/16 v4, 0xd

    .line 169
    .line 170
    invoke-direct {v3, p0, p1, v1, v4}, Li0g;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    :try_end_cc
    .catchall {:try_start_a8 .. :try_end_cc} :catchall_c1

    .line 171
    .line 172
    .line 173
    :try_start_cc
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_cf
    .catch Ljava/lang/Exception; {:try_start_cc .. :try_end_cf} :catch_d0

    .line 174
    .line 175
    .line 176
    return-object v3

    .line 177
    :catch_d0
    move-exception p0

    .line 178
    goto :goto_dc

    .line 179
    :goto_d2
    :try_start_d2
    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_d5
    .catchall {:try_start_d2 .. :try_end_d5} :catchall_d6

    .line 180
    .line 181
    .line 182
    goto :goto_db

    .line 183
    :catchall_d6
    move-exception p1

    .line 184
    :try_start_d7
    const/4 v7, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 185
    .line 186
    .line 187
    :goto_db
    throw p0
    :try_end_dc
    .catch Ljava/lang/Exception; {:try_start_d7 .. :try_end_dc} :catch_d0

    .line 188
    :goto_dc
    const/4 v7, 0x1

    invoke-static {p0}, Lx47;->q(Ljava/lang/Throwable;)V

    .line 189
    .line 190
    .line 191
    return-object v0

    .line 192
    nop

    .line 193
    :sswitch_data_e2
    .sparse-switch
        -0x66c1ae36 -> :sswitch_76
        -0x47197510 -> :sswitch_6b
        0x1d017 -> :sswitch_5c
        0x1d3d8 -> :sswitch_4f
        0x31ece8 -> :sswitch_3f
        0x387aa7 -> :sswitch_32
        0x65cf90e -> :sswitch_27
    .end sparse-switch

    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    :pswitch_data_100
    .packed-switch 0x0
        :pswitch_9a
        :pswitch_97
        :pswitch_97
        :pswitch_9a
        :pswitch_94
        :pswitch_9a
        :pswitch_97
    .end packed-switch
.end method

.method public static synthetic q(Lht8;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Lrff;)Ljava/lang/Object;
    .locals 11

    .line 1
    const-wide/high16 v6, 0x3ff0000000000000L    # 1.0

    .line 2
    .line 3
    const/4 v8, 0x1

    .line 4
    move-object v0, p0

    .line 5
    move-object v1, p1

    .line 6
    move-object v2, p2

    .line 7
    move-object v3, p3

    .line 8
    move-object v4, p4

    .line 9
    move/from16 v5, p5

    move/from16 v5, p5

    .line 10
    .line 11
    move-object/from16 v9, p6

    .line 12
    .line 13
    move-object/from16 v10, p7

    .line 14
    .line 15
    invoke-interface/range {v0 .. v10}, Lht8;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IDZLjava/lang/String;Lo73;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public static r(Lr39;Ljava/lang/String;Lln6;I)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v4, 0x1

    and-int/2addr p3, v0

    .line 3
    const/4 v1, 0x0

    move v4, v1

    .line 4
    if-eqz p3, :cond_8

    .line 5
    .line 6
    move-object p1, v1

    .line 7
    :cond_8
    const/4 v4, 0x5

    check-cast p0, Le39;

    .line 8
    .line 9
    iget-object p0, p0, Le39;->a:Lrx;

    .line 10
    .line 11
    new-instance p3, Lc39;

    .line 12
    .line 13
    if-eqz p1, :cond_19

    .line 14
    .line 15
    new-instance v1, Lbb6;

    .line 16
    .line 17
    const/4 v4, 0x6

    const/16 v2, 0x11

    .line 18
    .line 19
    invoke-direct {v1, p1, v2}, Lbb6;-><init>(Ljava/lang/Object;I)V

    .line 20
    .line 21
    .line 22
    :cond_19
    const/4 v4, 0x4

    new-instance p1, Llg7;

    .line 23
    .line 24
    const/4 v4, 0x4

    const/16 v2, 0x13

    .line 25
    .line 26
    const/4 v4, 0x5

    invoke-direct {p1, v2}, Llg7;-><init>(I)V

    .line 27
    .line 28
    .line 29
    new-instance v2, Ld39;

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    const/4 v4, 0x0

    invoke-direct {v2, p2, v3}, Ld39;-><init>(Lln6;I)V

    .line 33
    .line 34
    .line 35
    new-instance p2, Lnr2;

    .line 36
    .line 37
    const v3, -0x331bf287

    .line 38
    .line 39
    .line 40
    invoke-direct {p2, v2, v0, v3}, Lnr2;-><init>(Ljava/lang/Object;ZI)V

    .line 41
    .line 42
    .line 43
    invoke-direct {p3, v1, p1, p2}, Lc39;-><init>(Lwm6;Lwm6;Lnr2;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, v0, p3}, Lrx;->g(ILg19;)V

    .line 47
    .line 48
    .line 49
    const/4 v4, 0x3

    return-void
.end method

.method public static synthetic s(Lr39;ILnr2;)V
    .locals 3

    .line 1
    sget-object v0, Lri8;->m:Lri8;

    .line 2
    .line 3
    check-cast p0, Le39;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {p0, p1, v1, v0, p2}, Le39;->d(ILwm6;Lwm6;Lnr2;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public static t(FFFF)F
    .locals 1

    .line 1
    sub-float/2addr p0, p1

    .line 2
    mul-float/2addr p0, p2

    .line 3
    add-float/2addr p0, p3

    .line 4
    return p0
.end method

.method public static u(IIII)I
    .locals 1

    .line 1
    sub-int/2addr p0, p1

    .line 2
    const/4 v0, 0x6

    mul-int/2addr p0, p2

    .line 3
    add-int/2addr p0, p3

    .line 4
    return p0
.end method

.method public static v(Landroid/content/Intent;Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2

    .line 1
    new-instance v0, Landroid/content/ComponentName;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, v0}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v1, 0x7

    return-object p0
.end method

.method public static w(Ljava/lang/String;)Lcom/bytedance/sdk/openadsdk/pmi/zb/ycx;
    .locals 2

    .line 1
    new-instance v0, Lcom/bytedance/sdk/openadsdk/pmi/zb/ycx;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/bytedance/sdk/openadsdk/pmi/zb/ycx;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, Lcom/bytedance/sdk/openadsdk/pmi/zb/ycx;->zb(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public static x(IILjava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x3

    sub-int/2addr v0, p0

    .line 6
    invoke-virtual {p2, p1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method

.method public static y(JLjava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public static z(Ljava/lang/Exception;Ljava/lang/StringBuilder;)Ljava/lang/String;
    .locals 1

    .line 1
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method
