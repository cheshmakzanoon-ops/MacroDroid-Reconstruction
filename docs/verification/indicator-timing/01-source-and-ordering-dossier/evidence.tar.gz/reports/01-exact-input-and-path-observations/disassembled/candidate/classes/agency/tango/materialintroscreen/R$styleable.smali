.class public final Lagency/tango/materialintroscreen/R$styleable;
.super Ljava/lang/Object;


# static fields
.field public static final InkPageIndicator:[I

.field public static final InkPageIndicator_animationDuration:I = 0x0

.field public static final InkPageIndicator_currentPageIndicatorColor:I = 0x1

.field public static final InkPageIndicator_dotDiameter:I = 0x2

.field public static final InkPageIndicator_dotGap:I = 0x3

.field public static final InkPageIndicator_pageIndicatorColor:I = 0x4

.field public static final ParallaxLayout_Layout:[I

.field public static final ParallaxLayout_Layout_layout_parallaxFactor:I


# direct methods
.method public static constructor <clinit>()V
    .locals 6

    .line 1
    const/4 v5, 0x0

    const v0, 0x7f040220

    .line 2
    .line 3
    .line 4
    const/4 v5, 0x1

    const v1, 0x7f0404e1

    .line 5
    .line 6
    .line 7
    const/4 v5, 0x7

    const v2, 0x7f040046

    .line 8
    .line 9
    .line 10
    const/4 v5, 0x2

    const v3, 0x7f0401e1

    .line 11
    .line 12
    .line 13
    const v4, 0x7f04021f

    .line 14
    .line 15
    .line 16
    filled-new-array {v2, v3, v4, v0, v1}, [I

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v5, 0x2

    sput-object v0, Lagency/tango/materialintroscreen/R$styleable;->InkPageIndicator:[I

    .line 21
    .line 22
    const v0, 0x7f0403c0

    .line 23
    .line 24
    .line 25
    filled-new-array {v0}, [I

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    const/4 v5, 0x1

    sput-object v0, Lagency/tango/materialintroscreen/R$styleable;->ParallaxLayout_Layout:[I

    .line 30
    .line 31
    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
