.class public Landroidx/viewpager/widget/ViewPager;
.super Landroid/view/ViewGroup;
.source "r8-map-id-43b0b16dc0073b4b53e316177ca478d827b877826459072a6fdbad625fa2dd5f"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/viewpager/widget/ViewPager$LayoutParams;,
        Landroidx/viewpager/widget/ViewPager$SavedState;
    }
.end annotation


# static fields
.field public static final e0:[I

.field public static final f0:Llf7;

.field public static final g0:Lc51;

.field public static final h0:Landroidx/viewpager/widget/b;


# instance fields
.field public A:I

.field public final B:I

.field public C:F

.field public D:F

.field public E:F

.field public F:F

.field public G:I

.field public H:Landroid/view/VelocityTracker;

.field public final I:I

.field public final J:I

.field public final K:I

.field public final L:I

.field public final M:Landroid/widget/EdgeEffect;

.field public final N:Landroid/widget/EdgeEffect;

.field public O:Z

.field public P:Z

.field public Q:I

.field public R:Ljava/util/ArrayList;

.field public S:Lz5h;

.field public T:Lz5h;

.field public U:Ljava/util/ArrayList;

.field public V:Lde3;

.field public W:I

.field public a:I

.field public a0:I

.field public final b:Ljava/util/ArrayList;

.field public b0:Ljava/util/ArrayList;

.field public final c:Lx5h;

.field public final c0:Lb1c;

.field public final d:Landroid/graphics/Rect;

.field public d0:I

.field public e:Lnfb;

.field public f:I

.field public g:I

.field public h:Landroid/os/Parcelable;

.field public i:Ljava/lang/ClassLoader;

.field public final j:Landroid/widget/Scroller;

.field public k:Z

.field public l:Loe3;

.field public m:I

.field public n:Landroid/graphics/drawable/Drawable;

.field public o:I

.field public p:I

.field public q:F

.field public r:F

.field public s:I

.field public t:Z

.field public u:Z

.field public v:Z

.field public w:I

.field public x:Z

.field public y:Z

.field public final z:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const v0, 0x10100b3

    .line 2
    .line 3
    .line 4
    filled-new-array {v0}, [I

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sput-object v0, Landroidx/viewpager/widget/ViewPager;->e0:[I

    .line 9
    .line 10
    const/4 v2, 0x5

    new-instance v0, Llf7;

    .line 11
    .line 12
    const/16 v1, 0x14

    .line 13
    .line 14
    invoke-direct {v0, v1}, Llf7;-><init>(I)V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x2

    sput-object v0, Landroidx/viewpager/widget/ViewPager;->f0:Llf7;

    .line 18
    .line 19
    new-instance v0, Lc51;

    .line 20
    .line 21
    const/4 v1, 0x4

    const/4 v1, 0x5

    .line 22
    invoke-direct {v0, v1}, Lc51;-><init>(I)V

    .line 23
    .line 24
    .line 25
    sput-object v0, Landroidx/viewpager/widget/ViewPager;->g0:Lc51;

    .line 26
    .line 27
    new-instance v0, Landroidx/viewpager/widget/b;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    const/4 v2, 0x7

    sput-object v0, Landroidx/viewpager/widget/ViewPager;->h0:Landroidx/viewpager/widget/b;

    .line 33
    .line 34
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4

    .line 1
    const/4 v3, 0x4

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    const/4 v3, 0x1

    new-instance p1, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 v3, 0x2

    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 10
    .line 11
    new-instance p1, Lx5h;

    .line 12
    .line 13
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 v3, 0x0

    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->c:Lx5h;

    .line 17
    .line 18
    const/4 v3, 0x2

    new-instance p1, Landroid/graphics/Rect;

    .line 19
    .line 20
    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/graphics/Rect;

    .line 24
    .line 25
    const/4 v3, 0x6

    const/4 p1, -0x1

    .line 26
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->g:I

    .line 27
    .line 28
    const/4 p2, 0x0

    .line 29
    iput-object p2, p0, Landroidx/viewpager/widget/ViewPager;->h:Landroid/os/Parcelable;

    .line 30
    .line 31
    const/4 v3, 0x0

    iput-object p2, p0, Landroidx/viewpager/widget/ViewPager;->i:Ljava/lang/ClassLoader;

    .line 32
    .line 33
    const/4 v3, 0x5

    const p2, -0x800001

    .line 34
    .line 35
    .line 36
    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 37
    .line 38
    const p2, 0x7f7fffff    # Float.MAX_VALUE

    .line 39
    .line 40
    .line 41
    const/4 v3, 0x2

    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 42
    .line 43
    const/4 v3, 0x3

    const/4 p2, 0x1

    .line 44
    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 45
    .line 46
    const/4 v3, 0x7

    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 47
    .line 48
    iput-boolean p2, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 49
    .line 50
    new-instance p1, Lb1c;

    .line 51
    .line 52
    const/4 v3, 0x2

    const/16 v0, 0x15

    .line 53
    .line 54
    invoke-direct {p1, p0, v0}, Lb1c;-><init>(Ljava/lang/Object;I)V

    .line 55
    .line 56
    .line 57
    const/4 v3, 0x0

    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->c0:Lb1c;

    .line 58
    .line 59
    const/4 v3, 0x3

    const/4 p1, 0x0

    .line 60
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->d0:I

    .line 61
    .line 62
    invoke-virtual {p0, p1}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 63
    .line 64
    .line 65
    const/high16 p1, 0x40000

    .line 66
    .line 67
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0, p2}, Landroid/view/View;->setFocusable(Z)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    new-instance v0, Landroid/widget/Scroller;

    .line 78
    .line 79
    sget-object v1, Landroidx/viewpager/widget/ViewPager;->g0:Lc51;

    .line 80
    .line 81
    invoke-direct {v0, p1, v1}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    .line 82
    .line 83
    .line 84
    const/4 v3, 0x0

    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 85
    .line 86
    const/4 v3, 0x5

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 99
    .line 100
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledPagingTouchSlop()I

    .line 101
    .line 102
    .line 103
    move-result v2

    .line 104
    iput v2, p0, Landroidx/viewpager/widget/ViewPager;->B:I

    .line 105
    .line 106
    const/high16 v2, 0x43c80000    # 400.0f

    .line 107
    .line 108
    mul-float/2addr v2, v1

    .line 109
    float-to-int v2, v2

    .line 110
    iput v2, p0, Landroidx/viewpager/widget/ViewPager;->I:I

    .line 111
    .line 112
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->J:I

    .line 117
    .line 118
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 119
    .line 120
    invoke-direct {v0, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 121
    .line 122
    .line 123
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/widget/EdgeEffect;

    .line 124
    .line 125
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 126
    .line 127
    invoke-direct {v0, p1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 128
    .line 129
    .line 130
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->N:Landroid/widget/EdgeEffect;

    .line 131
    .line 132
    const/high16 p1, 0x41c80000    # 25.0f

    .line 133
    .line 134
    mul-float/2addr p1, v1

    .line 135
    float-to-int p1, p1

    .line 136
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->K:I

    .line 137
    .line 138
    const/4 v3, 0x1

    const/high16 p1, 0x40000000    # 2.0f

    .line 139
    .line 140
    mul-float/2addr p1, v1

    .line 141
    float-to-int p1, p1

    .line 142
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 143
    .line 144
    const/high16 p1, 0x41800000    # 16.0f

    .line 145
    .line 146
    mul-float/2addr v1, p1

    .line 147
    float-to-int p1, v1

    .line 148
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->z:I

    .line 149
    .line 150
    new-instance p1, Loy4;

    .line 151
    .line 152
    const/4 v0, 0x5

    const/4 v0, 0x2

    .line 153
    invoke-direct {p1, p0, v0}, Loy4;-><init>(Ljava/lang/Object;I)V

    .line 154
    .line 155
    .line 156
    invoke-static {p0, p1}, Ln3h;->t(Landroid/view/View;Lf4;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {p0}, Landroid/view/View;->getImportantForAccessibility()I

    .line 160
    .line 161
    .line 162
    move-result p1

    .line 163
    const/4 v3, 0x5

    if-nez p1, :cond_bc

    .line 164
    .line 165
    const/4 v3, 0x0

    invoke-virtual {p0, p2}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 166
    .line 167
    .line 168
    :cond_bc
    new-instance p1, Ln7b;

    .line 169
    .line 170
    const/4 v3, 0x0

    invoke-direct {p1, p0}, Ln7b;-><init>(Landroidx/viewpager/widget/ViewPager;)V

    .line 171
    .line 172
    .line 173
    invoke-static {p0, p1}, Le3h;->c(Landroid/view/View;Li3b;)V

    .line 174
    .line 175
    .line 176
    const/4 v3, 0x5

    return-void
.end method

.method public static c(Landroid/view/View;ZIII)Z
    .locals 10

    .line 1
    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    instance-of v0, p0, Landroid/view/ViewGroup;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v9, 0x7

    if-eqz v0, :cond_5a

    .line 5
    .line 6
    move-object v0, p0

    move-object v0, p0

    .line 7
    const/4 v9, 0x6

    check-cast v0, Landroid/view/ViewGroup;

    .line 8
    .line 9
    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    const/4 v9, 0x2

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 18
    .line 19
    .line 20
    move-result v4

    .line 21
    const/4 v9, 0x5

    sub-int/2addr v4, v1

    .line 22
    :goto_1d
    if-ltz v4, :cond_5a

    .line 23
    .line 24
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    add-int v6, p3, v2

    .line 29
    .line 30
    invoke-virtual {v5}, Landroid/view/View;->getLeft()I

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    const/4 v9, 0x6

    if-lt v6, v7, :cond_57

    .line 35
    .line 36
    invoke-virtual {v5}, Landroid/view/View;->getRight()I

    .line 37
    .line 38
    .line 39
    move-result v7

    .line 40
    const/4 v9, 0x7

    if-ge v6, v7, :cond_57

    .line 41
    .line 42
    add-int v7, p4, v3

    .line 43
    .line 44
    const/4 v9, 0x0

    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 45
    .line 46
    .line 47
    move-result v8

    .line 48
    if-lt v7, v8, :cond_57

    .line 49
    .line 50
    const/4 v9, 0x0

    invoke-virtual {v5}, Landroid/view/View;->getBottom()I

    .line 51
    .line 52
    .line 53
    move-result v8

    .line 54
    const/4 v9, 0x5

    if-ge v7, v8, :cond_57

    .line 55
    .line 56
    invoke-virtual {v5}, Landroid/view/View;->getLeft()I

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    sub-int/2addr v6, v8

    .line 61
    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 62
    .line 63
    .line 64
    move-result v8

    .line 65
    const/4 v9, 0x6

    sub-int/2addr v7, v8

    .line 66
    invoke-static {v5, v1, p2, v6, v7}, Landroidx/viewpager/widget/ViewPager;->c(Landroid/view/View;ZIII)Z

    .line 67
    .line 68
    .line 69
    move-result v5

    .line 70
    const/4 v9, 0x3

    if-eqz v5, :cond_57

    .line 71
    .line 72
    goto :goto_63

    .line 73
    :cond_57
    add-int/lit8 v4, v4, -0x1

    .line 74
    .line 75
    goto :goto_1d

    .line 76
    :cond_5a
    if-eqz p1, :cond_65

    .line 77
    .line 78
    neg-int p1, p2

    .line 79
    invoke-virtual {p0, p1}, Landroid/view/View;->canScrollHorizontally(I)Z

    .line 80
    .line 81
    .line 82
    move-result p0

    .line 83
    if-eqz p0, :cond_65

    .line 84
    .line 85
    :goto_63
    const/4 v9, 0x3

    return v1

    .line 86
    :cond_65
    const/4 v9, 0x1

    const/4 p0, 0x0

    .line 87
    return p0
.end method

.method private getClientWidth()I
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x1

    sub-int/2addr v0, v1

    .line 10
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    sub-int/2addr v0, p0

    .line 15
    return v0
.end method

.method private setScrollingCacheEnabled(Z)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->u:Z

    .line 2
    .line 3
    if-eq v0, p1, :cond_6

    .line 4
    .line 5
    iput-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->u:Z

    .line 6
    .line 7
    :cond_6
    return-void
.end method


# virtual methods
.method public final a(II)Lx5h;
    .locals 3

    .line 1
    new-instance v0, Lx5h;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput p1, v0, Lx5h;->b:I

    .line 7
    .line 8
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 9
    .line 10
    invoke-virtual {v1, p0, p1}, Lnfb;->e(Landroidx/viewpager/widget/ViewPager;I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iput-object p1, v0, Lx5h;->a:Ljava/lang/Object;

    .line 15
    .line 16
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    const/4 v2, 0x5

    const/high16 p1, 0x3f800000    # 1.0f

    .line 22
    .line 23
    iput p1, v0, Lx5h;->d:F

    .line 24
    .line 25
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 26
    .line 27
    const/4 v2, 0x6

    if-ltz p2, :cond_29

    .line 28
    .line 29
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-lt p2, p1, :cond_25

    .line 34
    .line 35
    goto :goto_29

    .line 36
    :cond_25
    invoke-virtual {p0, p2, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    return-object v0

    .line 40
    :cond_29
    :goto_29
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    const/4 v2, 0x0

    return-object v0
.end method

.method public final addFocusables(Ljava/util/ArrayList;II)V
    .locals 7

    .line 1
    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getDescendantFocusability()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v6, 0x1

    const/high16 v2, 0x60000

    .line 10
    .line 11
    if-eq v1, v2, :cond_33

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    :goto_10
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    if-ge v2, v3, :cond_33

    .line 19
    .line 20
    const/4 v6, 0x2

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    if-nez v4, :cond_30

    .line 29
    .line 30
    invoke-virtual {p0, v3}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    if-eqz v4, :cond_30

    .line 35
    .line 36
    iget v4, v4, Lx5h;->b:I

    .line 37
    .line 38
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 39
    .line 40
    if-ne v4, v5, :cond_30

    .line 41
    .line 42
    invoke-virtual {v3, p1, p2, p3}, Landroid/view/View;->addFocusables(Ljava/util/ArrayList;II)V

    .line 43
    .line 44
    .line 45
    :cond_30
    add-int/lit8 v2, v2, 0x1

    .line 46
    .line 47
    goto :goto_10

    .line 48
    :cond_33
    const/high16 p2, 0x40000

    .line 49
    .line 50
    const/4 v6, 0x0

    if-ne v1, p2, :cond_3f

    .line 51
    .line 52
    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 53
    .line 54
    .line 55
    move-result p2

    .line 56
    if-ne v0, p2, :cond_57

    .line 57
    .line 58
    :cond_3f
    invoke-virtual {p0}, Landroid/view/View;->isFocusable()Z

    .line 59
    .line 60
    .line 61
    move-result p2

    .line 62
    if-nez p2, :cond_47

    .line 63
    .line 64
    const/4 v6, 0x3

    goto :goto_57

    .line 65
    :cond_47
    const/4 p2, 0x1

    .line 66
    and-int/2addr p3, p2

    .line 67
    if-ne p3, p2, :cond_59

    .line 68
    .line 69
    invoke-virtual {p0}, Landroid/view/View;->isInTouchMode()Z

    .line 70
    .line 71
    .line 72
    move-result p2

    .line 73
    if-eqz p2, :cond_59

    .line 74
    .line 75
    invoke-virtual {p0}, Landroid/view/View;->isFocusableInTouchMode()Z

    .line 76
    .line 77
    .line 78
    move-result p2

    .line 79
    if-nez p2, :cond_59

    .line 80
    .line 81
    :cond_57
    :goto_57
    const/4 v6, 0x5

    return-void

    .line 82
    :cond_59
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    return-void
.end method

.method public final addTouchables(Ljava/util/ArrayList;)V
    .locals 5

    .line 1
    const/4 v4, 0x5

    const/4 v0, 0x0

    .line 2
    :goto_2
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 3
    .line 4
    .line 5
    move-result v1

    .line 6
    const/4 v4, 0x0

    if-ge v0, v1, :cond_27

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/4 v4, 0x0

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-nez v2, :cond_24

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    if-eqz v2, :cond_24

    .line 23
    .line 24
    iget v2, v2, Lx5h;->b:I

    .line 25
    .line 26
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 27
    .line 28
    if-ne v2, v3, :cond_24

    .line 29
    .line 30
    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Landroid/view/View;->addTouchables(Ljava/util/ArrayList;)V

    .line 31
    .line 32
    .line 33
    :cond_24
    add-int/lit8 v0, v0, 0x1

    .line 34
    .line 35
    goto :goto_2

    .line 36
    :cond_27
    return-void
.end method

.method public final addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 5

    .line 1
    invoke-virtual {p0, p3}, Landroidx/viewpager/widget/ViewPager;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v4, 0x1

    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 8
    .line 9
    .line 10
    move-result-object p3

    .line 11
    :cond_b
    move-object v0, p3

    move-object v0, p3

    .line 12
    check-cast v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 13
    .line 14
    const/4 v4, 0x3

    iget-boolean v1, v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 15
    .line 16
    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    const-class v3, Lw5h;

    .line 21
    .line 22
    invoke-virtual {v2, v3}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    const/4 v4, 0x2

    const/4 v3, 0x1

    .line 27
    if-eqz v2, :cond_24

    .line 28
    .line 29
    const/4 v4, 0x0

    move v2, v3

    .line 30
    goto :goto_25

    .line 31
    :cond_24
    const/4 v2, 0x0

    .line 32
    :goto_25
    const/4 v4, 0x0

    or-int/2addr v1, v2

    .line 33
    const/4 v4, 0x0

    iput-boolean v1, v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 34
    .line 35
    const/4 v4, 0x0

    iget-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->t:Z

    .line 36
    .line 37
    const/4 v4, 0x1

    if-eqz v2, :cond_3f

    .line 38
    .line 39
    if-nez v1, :cond_39

    .line 40
    .line 41
    iput-boolean v3, v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;->d:Z

    .line 42
    .line 43
    const/4 v4, 0x3

    invoke-virtual {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)Z

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_39
    const-string p0, "Cannot add pager decor view during layout"

    .line 48
    .line 49
    invoke-static {p0}, Le6d;->r(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_3f
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 54
    .line 55
    .line 56
    return-void
.end method

.method public final b(I)Z
    .locals 8

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v7, 0x5

    if-ne v0, p0, :cond_b

    .line 7
    .line 8
    :goto_8
    move-object v0, v1

    .line 9
    const/4 v7, 0x2

    goto :goto_60

    .line 10
    :cond_b
    const/4 v7, 0x2

    if-eqz v0, :cond_60

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    :goto_12
    const/4 v7, 0x4

    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 17
    .line 18
    if-eqz v3, :cond_1f

    .line 19
    .line 20
    if-ne v2, p0, :cond_1a

    .line 21
    .line 22
    goto :goto_60

    .line 23
    :cond_1a
    invoke-interface {v2}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    goto :goto_12

    .line 28
    :cond_1f
    new-instance v2, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    :goto_31
    instance-of v3, v0, Landroid/view/ViewGroup;

    .line 46
    .line 47
    const/4 v7, 0x0

    if-eqz v3, :cond_4e

    .line 48
    .line 49
    const-string v3, "= > "

    const-string v3, " => "

    .line 50
    .line 51
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    goto :goto_31

    .line 70
    :cond_4e
    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    const-string v2, "arrowScroll tried to find focus based on non-child current focused view "

    .line 75
    .line 76
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    const-string v2, "ViewPager"

    .line 81
    .line 82
    invoke-static {v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 83
    .line 84
    .line 85
    const/4 v7, 0x2

    goto :goto_8

    .line 86
    :cond_60
    :goto_60
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-virtual {v1, p0, v0, p1}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    const/4 v2, 0x1

    .line 95
    const/4 v3, 0x0

    .line 96
    const/16 v4, 0x42

    .line 97
    .line 98
    const/4 v7, 0x7

    const/16 v5, 0x11

    .line 99
    .line 100
    if-eqz v1, :cond_bb

    .line 101
    .line 102
    if-eq v1, v0, :cond_bb

    .line 103
    .line 104
    iget-object v6, p0, Landroidx/viewpager/widget/ViewPager;->d:Landroid/graphics/Rect;

    .line 105
    .line 106
    if-ne p1, v5, :cond_9d

    .line 107
    .line 108
    invoke-virtual {p0, v6, v1}, Landroidx/viewpager/widget/ViewPager;->g(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    iget v4, v4, Landroid/graphics/Rect;->left:I

    .line 113
    .line 114
    invoke-virtual {p0, v6, v0}, Landroidx/viewpager/widget/ViewPager;->g(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 115
    .line 116
    .line 117
    move-result-object v5

    .line 118
    const/4 v7, 0x1

    iget v5, v5, Landroid/graphics/Rect;->left:I

    .line 119
    .line 120
    if-eqz v0, :cond_95

    .line 121
    .line 122
    const/4 v7, 0x7

    if-lt v4, v5, :cond_95

    .line 123
    .line 124
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 125
    .line 126
    if-lez v0, :cond_d8

    .line 127
    .line 128
    const/4 v7, 0x2

    sub-int/2addr v0, v2

    .line 129
    iput-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 130
    .line 131
    invoke-virtual {p0, v0, v3, v2, v3}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 132
    .line 133
    .line 134
    goto :goto_d9

    .line 135
    :cond_95
    invoke-virtual {v1}, Landroid/view/View;->requestFocus()Z

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    :goto_99
    const/4 v7, 0x6

    move v3, v0

    move v3, v0

    .line 140
    goto :goto_da

    .line 141
    :cond_9d
    if-ne p1, v4, :cond_da

    .line 142
    .line 143
    invoke-virtual {p0, v6, v1}, Landroidx/viewpager/widget/ViewPager;->g(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    const/4 v7, 0x2

    iget v2, v2, Landroid/graphics/Rect;->left:I

    .line 148
    .line 149
    invoke-virtual {p0, v6, v0}, Landroidx/viewpager/widget/ViewPager;->g(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    iget v3, v3, Landroid/graphics/Rect;->left:I

    .line 154
    .line 155
    if-eqz v0, :cond_b6

    .line 156
    .line 157
    const/4 v7, 0x3

    if-gt v2, v3, :cond_b6

    .line 158
    .line 159
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->m()Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    goto :goto_99

    .line 164
    :cond_b6
    invoke-virtual {v1}, Landroid/view/View;->requestFocus()Z

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    goto :goto_99

    .line 169
    :cond_bb
    if-eq p1, v5, :cond_cb

    .line 170
    .line 171
    if-ne p1, v2, :cond_c0

    .line 172
    .line 173
    goto :goto_cb

    .line 174
    :cond_c0
    if-eq p1, v4, :cond_c5

    .line 175
    .line 176
    const/4 v0, 0x2

    .line 177
    if-ne p1, v0, :cond_da

    .line 178
    .line 179
    :cond_c5
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->m()Z

    .line 180
    .line 181
    .line 182
    move-result v3

    .line 183
    const/4 v7, 0x6

    goto :goto_da

    .line 184
    :cond_cb
    :goto_cb
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 185
    .line 186
    if-lez v0, :cond_d8

    .line 187
    .line 188
    sub-int/2addr v0, v2

    .line 189
    iput-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 190
    .line 191
    const/4 v7, 0x0

    invoke-virtual {p0, v0, v3, v2, v3}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 192
    .line 193
    .line 194
    const/4 v7, 0x2

    goto :goto_d9

    .line 195
    :cond_d8
    move v2, v3

    .line 196
    :goto_d9
    move v3, v2

    .line 197
    :cond_da
    :goto_da
    if-eqz v3, :cond_e4

    .line 198
    .line 199
    invoke-static {p1}, Landroid/view/SoundEffectConstants;->getContantForFocusDirection(I)I

    .line 200
    .line 201
    .line 202
    move-result p1

    .line 203
    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Landroid/view/View;->playSoundEffect(I)V

    .line 204
    .line 205
    .line 206
    :cond_e4
    return v3
.end method

.method public final canScrollHorizontally(I)Z
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 2
    .line 3
    const/4 v4, 0x5

    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_7

    .line 5
    .line 6
    return v1

    .line 7
    :cond_7
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    const/4 v3, 0x1

    .line 16
    const/4 v4, 0x4

    if-gez p1, :cond_20

    .line 17
    .line 18
    int-to-float p1, v0

    .line 19
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 20
    .line 21
    mul-float/2addr p1, p0

    .line 22
    const/4 v4, 0x3

    float-to-int p0, p1

    .line 23
    if-le v2, p0, :cond_1f

    .line 24
    .line 25
    const/4 v4, 0x1

    return v3

    .line 26
    :cond_1f
    return v1

    .line 27
    :cond_20
    const/4 v4, 0x5

    if-lez p1, :cond_2b

    .line 28
    .line 29
    int-to-float p1, v0

    .line 30
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 31
    .line 32
    mul-float/2addr p1, p0

    .line 33
    float-to-int p0, p1

    .line 34
    if-ge v2, p0, :cond_2b

    .line 35
    .line 36
    return v3

    .line 37
    :cond_2b
    const/4 v4, 0x6

    return v1
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 2

    .line 1
    instance-of v0, p1, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 2
    .line 3
    const/4 v1, 0x4

    if-eqz v0, :cond_d

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_d

    .line 10
    .line 11
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :cond_d
    const/4 p0, 0x0

    .line 14
    const/4 v1, 0x1

    return p0
.end method

.method public final computeScroll()V
    .locals 6

    .line 1
    const/4 v5, 0x3

    const/4 v0, 0x1

    .line 2
    const/4 v5, 0x6

    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->k:Z

    .line 3
    .line 4
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 5
    .line 6
    const/4 v5, 0x4

    invoke-virtual {v1}, Landroid/widget/Scroller;->isFinished()Z

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    const/4 v5, 0x0

    if-nez v2, :cond_45

    .line 11
    .line 12
    invoke-virtual {v1}, Landroid/widget/Scroller;->computeScrollOffset()Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-eqz v2, :cond_45

    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/widget/Scroller;->getCurrX()I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    invoke-virtual {v1}, Landroid/widget/Scroller;->getCurrY()I

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-ne v0, v3, :cond_2a

    .line 35
    .line 36
    if-eq v2, v4, :cond_3d

    .line 37
    .line 38
    :cond_2a
    invoke-virtual {p0, v3, v4}, Landroid/view/View;->scrollTo(II)V

    .line 39
    .line 40
    .line 41
    const/4 v5, 0x7

    invoke-virtual {p0, v3}, Landroidx/viewpager/widget/ViewPager;->n(I)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    const/4 v5, 0x1

    if-nez v0, :cond_3d

    .line 46
    .line 47
    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/widget/Scroller;->abortAnimation()V

    .line 48
    .line 49
    .line 50
    const/4 v0, 0x0

    .line 51
    invoke-virtual {p0, v0, v4}, Landroid/view/View;->scrollTo(II)V

    .line 52
    .line 53
    .line 54
    :cond_3d
    const/4 v5, 0x1

    sget-object v0, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 55
    .line 56
    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_45
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->d(Z)V

    .line 61
    .line 62
    .line 63
    return-void
.end method

.method public final d(Z)V
    .locals 8

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->d0:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v7, 0x5

    if-ne v0, v1, :cond_a

    .line 7
    .line 8
    move v0, v2

    .line 9
    goto :goto_c

    .line 10
    :cond_a
    move v0, v3

    move v0, v3

    .line 11
    :goto_c
    if-eqz v0, :cond_3c

    .line 12
    .line 13
    invoke-direct {p0, v3}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 17
    .line 18
    const/4 v7, 0x0

    invoke-virtual {v1}, Landroid/widget/Scroller;->isFinished()Z

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    const/4 v7, 0x1

    if-nez v4, :cond_3c

    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/widget/Scroller;->abortAnimation()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    const/4 v7, 0x2

    invoke-virtual {v1}, Landroid/widget/Scroller;->getCurrX()I

    .line 36
    .line 37
    .line 38
    move-result v6

    .line 39
    invoke-virtual {v1}, Landroid/widget/Scroller;->getCurrY()I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-ne v4, v6, :cond_33

    .line 44
    .line 45
    if-eq v5, v1, :cond_3c

    .line 46
    .line 47
    :cond_33
    const/4 v7, 0x4

    invoke-virtual {p0, v6, v1}, Landroid/view/View;->scrollTo(II)V

    .line 48
    .line 49
    .line 50
    if-eq v6, v4, :cond_3c

    .line 51
    .line 52
    invoke-virtual {p0, v6}, Landroidx/viewpager/widget/ViewPager;->n(I)Z

    .line 53
    .line 54
    .line 55
    :cond_3c
    const/4 v7, 0x6

    iput-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 56
    .line 57
    move v1, v3

    .line 58
    :goto_40
    iget-object v4, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 59
    .line 60
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    const/4 v7, 0x7

    if-ge v1, v5, :cond_5a

    .line 65
    .line 66
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    check-cast v4, Lx5h;

    .line 71
    .line 72
    iget-boolean v5, v4, Lx5h;->c:Z

    .line 73
    .line 74
    const/4 v7, 0x3

    if-eqz v5, :cond_57

    .line 75
    .line 76
    iput-boolean v3, v4, Lx5h;->c:Z

    .line 77
    .line 78
    move v0, v2

    .line 79
    :cond_57
    add-int/lit8 v1, v1, 0x1

    .line 80
    .line 81
    goto :goto_40

    .line 82
    :cond_5a
    if-eqz v0, :cond_69

    .line 83
    .line 84
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->c0:Lb1c;

    .line 85
    .line 86
    if-eqz p1, :cond_66

    .line 87
    .line 88
    sget-object p1, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 89
    .line 90
    invoke-virtual {p0, v0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    :cond_66
    invoke-virtual {v0}, Lb1c;->run()V

    .line 95
    .line 96
    .line 97
    :cond_69
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 6

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v5, 0x5

    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_72

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v5, 0x0

    const/4 v2, 0x0

    .line 13
    if-nez v0, :cond_6b

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/16 v3, 0x15

    .line 20
    .line 21
    const/4 v5, 0x6

    const/4 v4, 0x2

    .line 22
    if-eq v0, v3, :cond_4f

    .line 23
    .line 24
    const/4 v5, 0x4

    const/16 v3, 0x16

    .line 25
    .line 26
    if-eq v0, v3, :cond_3b

    .line 27
    .line 28
    const/16 v3, 0x3d

    .line 29
    .line 30
    if-eq v0, v3, :cond_24

    .line 31
    .line 32
    goto :goto_6b

    .line 33
    :cond_24
    invoke-virtual {p1}, Landroid/view/KeyEvent;->hasNoModifiers()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2f

    .line 38
    .line 39
    invoke-virtual {p0, v4}, Landroidx/viewpager/widget/ViewPager;->b(I)Z

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    goto :goto_6d

    .line 44
    :cond_2f
    invoke-virtual {p1, v1}, Landroid/view/KeyEvent;->hasModifiers(I)Z

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    const/4 v5, 0x3

    if-eqz p1, :cond_6b

    .line 49
    .line 50
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->b(I)Z

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    goto :goto_6d

    .line 55
    :cond_3b
    invoke-virtual {p1, v4}, Landroid/view/KeyEvent;->hasModifiers(I)Z

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    if-eqz p1, :cond_47

    .line 60
    .line 61
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->m()Z

    .line 62
    .line 63
    .line 64
    move-result p0

    .line 65
    const/4 v5, 0x0

    goto :goto_6d

    .line 66
    :cond_47
    const/16 p1, 0x42

    .line 67
    .line 68
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->b(I)Z

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    const/4 v5, 0x1

    goto :goto_6d

    .line 73
    :cond_4f
    invoke-virtual {p1, v4}, Landroid/view/KeyEvent;->hasModifiers(I)Z

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    if-eqz p1, :cond_63

    .line 78
    .line 79
    iget p1, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 80
    .line 81
    if-lez p1, :cond_6b

    .line 82
    .line 83
    const/4 v5, 0x6

    sub-int/2addr p1, v1

    .line 84
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 85
    .line 86
    invoke-virtual {p0, p1, v2, v1, v2}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 87
    .line 88
    .line 89
    const/4 v5, 0x4

    move p0, v1

    .line 90
    goto :goto_6d

    .line 91
    :cond_63
    const/16 p1, 0x11

    .line 92
    .line 93
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->b(I)Z

    .line 94
    .line 95
    .line 96
    move-result p0

    .line 97
    const/4 v5, 0x3

    goto :goto_6d

    .line 98
    :cond_6b
    :goto_6b
    move p0, v2

    move p0, v2

    .line 99
    :goto_6d
    if-eqz p0, :cond_71

    .line 100
    .line 101
    const/4 v5, 0x4

    goto :goto_72

    .line 102
    :cond_71
    return v2

    .line 103
    :cond_72
    :goto_72
    const/4 v5, 0x7

    return v1
.end method

.method public final dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 7

    .line 1
    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/16 v1, 0x1000

    .line 6
    .line 7
    if-ne v0, v1, :cond_f

    .line 8
    .line 9
    const/4 v6, 0x5

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0

    .line 14
    :cond_f
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v1, 0x0

    .line 19
    move v2, v1

    .line 20
    :goto_15
    const/4 v6, 0x3

    if-ge v2, v0, :cond_3f

    .line 21
    .line 22
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    const/4 v6, 0x3

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-nez v4, :cond_3b

    .line 31
    .line 32
    const/4 v6, 0x6

    invoke-virtual {p0, v3}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    const/4 v6, 0x1

    if-eqz v4, :cond_3b

    .line 37
    .line 38
    iget v4, v4, Lx5h;->b:I

    .line 39
    .line 40
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 41
    .line 42
    if-ne v4, v5, :cond_3b

    .line 43
    .line 44
    invoke-virtual {v3, p1}, Landroid/view/View;->dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    const/4 v6, 0x7

    if-eqz v3, :cond_3b

    .line 49
    .line 50
    const/4 p0, 0x1

    .line 51
    const/4 v6, 0x7

    return p0

    .line 52
    :cond_3b
    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    .line 53
    .line 54
    goto :goto_15

    .line 55
    :cond_3f
    return v1
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .locals 9

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->draw(Landroid/graphics/Canvas;)V

    .line 2
    .line 3
    .line 4
    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getOverScrollMode()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v8, 0x6

    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->N:Landroid/widget/EdgeEffect;

    .line 9
    .line 10
    const/4 v8, 0x5

    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/widget/EdgeEffect;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    const/4 v8, 0x1

    if-eqz v0, :cond_29

    .line 14
    .line 15
    const/4 v4, 0x1

    .line 16
    if-ne v0, v4, :cond_21

    .line 17
    .line 18
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 19
    .line 20
    if-eqz v0, :cond_21

    .line 21
    .line 22
    const/4 v8, 0x5

    invoke-virtual {v0}, Lnfb;->c()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-le v0, v4, :cond_21

    .line 27
    .line 28
    goto :goto_29

    .line 29
    :cond_21
    invoke-virtual {v2}, Landroid/widget/EdgeEffect;->finish()V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->finish()V

    .line 33
    .line 34
    .line 35
    goto/16 :goto_aa

    .line 36
    :cond_29
    :goto_29
    invoke-virtual {v2}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_66

    .line 41
    .line 42
    const/4 v8, 0x5

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    sub-int/2addr v3, v4

    .line 55
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 56
    .line 57
    .line 58
    move-result v4

    .line 59
    sub-int/2addr v3, v4

    .line 60
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 61
    .line 62
    .line 63
    move-result v4

    .line 64
    const/high16 v5, 0x43870000    # 270.0f

    .line 65
    .line 66
    const/4 v8, 0x7

    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->rotate(F)V

    .line 67
    .line 68
    .line 69
    neg-int v5, v3

    .line 70
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 71
    .line 72
    .line 73
    move-result v6

    .line 74
    add-int/2addr v6, v5

    .line 75
    const/4 v8, 0x5

    int-to-float v5, v6

    .line 76
    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 77
    .line 78
    int-to-float v7, v4

    .line 79
    mul-float/2addr v6, v7

    .line 80
    invoke-virtual {p1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2, v3, v4}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 84
    .line 85
    .line 86
    const/4 v8, 0x4

    invoke-virtual {v2, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 87
    .line 88
    .line 89
    move-result v3

    .line 90
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 91
    .line 92
    .line 93
    :cond_66
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    const/4 v8, 0x0

    if-nez v0, :cond_aa

    .line 98
    .line 99
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 104
    .line 105
    .line 106
    move-result v2

    .line 107
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 112
    .line 113
    .line 114
    move-result v5

    .line 115
    sub-int/2addr v4, v5

    .line 116
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 117
    .line 118
    .line 119
    move-result v5

    .line 120
    const/4 v8, 0x5

    sub-int/2addr v4, v5

    .line 121
    const/high16 v5, 0x42b40000    # 90.0f

    .line 122
    .line 123
    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->rotate(F)V

    .line 124
    .line 125
    .line 126
    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 127
    .line 128
    .line 129
    move-result v5

    .line 130
    neg-int v5, v5

    .line 131
    const/4 v8, 0x3

    int-to-float v5, v5

    .line 132
    const/4 v8, 0x1

    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 133
    .line 134
    const/high16 v7, 0x3f800000    # 1.0f

    .line 135
    .line 136
    add-float/2addr v6, v7

    .line 137
    neg-float v6, v6

    .line 138
    int-to-float v7, v2

    .line 139
    mul-float/2addr v6, v7

    .line 140
    invoke-virtual {p1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    .line 141
    .line 142
    .line 143
    const/4 v8, 0x0

    invoke-virtual {v1, v4, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v1, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    or-int/2addr v3, v1

    .line 151
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 152
    .line 153
    .line 154
    :cond_aa
    :goto_aa
    if-eqz v3, :cond_b3

    .line 155
    .line 156
    const/4 v8, 0x3

    sget-object p1, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 157
    .line 158
    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 159
    .line 160
    .line 161
    :cond_b3
    return-void
.end method

.method public final drawableStateChanged()V
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->drawableStateChanged()V

    .line 2
    .line 3
    .line 4
    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->n:Landroid/graphics/drawable/Drawable;

    .line 5
    .line 6
    if-eqz v0, :cond_16

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v2, 0x6

    if-eqz v1, :cond_16

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 19
    .line 20
    .line 21
    :cond_16
    return-void
.end method

.method public final e()V
    .locals 9

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 2
    .line 3
    const/4 v8, 0x1

    invoke-virtual {v0}, Lnfb;->c()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->a:I

    .line 8
    .line 9
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v8, 0x6

    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 16
    .line 17
    const/4 v8, 0x5

    mul-int/lit8 v3, v3, 0x2

    .line 18
    .line 19
    const/4 v4, 0x1

    .line 20
    add-int/2addr v3, v4

    .line 21
    const/4 v5, 0x0

    .line 22
    if-ge v2, v3, :cond_24

    .line 23
    .line 24
    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    const/4 v8, 0x4

    if-ge v2, v0, :cond_24

    .line 29
    .line 30
    move v0, v4

    .line 31
    goto :goto_25

    .line 32
    :cond_24
    move v0, v5

    .line 33
    :goto_25
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 34
    .line 35
    move v3, v5

    .line 36
    :goto_28
    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    if-ge v3, v6, :cond_43

    .line 41
    .line 42
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v6

    .line 46
    check-cast v6, Lx5h;

    .line 47
    .line 48
    const/4 v8, 0x0

    iget-object v7, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 49
    .line 50
    const/4 v8, 0x6

    iget-object v6, v6, Lx5h;->a:Ljava/lang/Object;

    .line 51
    .line 52
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    .line 56
    .line 57
    const/4 v8, 0x1

    goto :goto_28

    .line 58
    :cond_43
    sget-object v3, Landroidx/viewpager/widget/ViewPager;->f0:Llf7;

    .line 59
    .line 60
    const/4 v8, 0x7

    invoke-static {v1, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 61
    .line 62
    .line 63
    const/4 v8, 0x1

    if-eqz v0, :cond_71

    .line 64
    .line 65
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    const/4 v8, 0x6

    move v1, v5

    .line 70
    :goto_52
    if-ge v1, v0, :cond_6b

    .line 71
    .line 72
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    const/4 v8, 0x5

    check-cast v3, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 81
    .line 82
    const/4 v8, 0x5

    iget-boolean v6, v3, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 83
    .line 84
    if-nez v6, :cond_68

    .line 85
    .line 86
    const/4 v6, 0x0

    move v8, v6

    .line 87
    iput v6, v3, Landroidx/viewpager/widget/ViewPager$LayoutParams;->c:F

    .line 88
    .line 89
    :cond_68
    add-int/lit8 v1, v1, 0x1

    .line 90
    .line 91
    goto :goto_52

    .line 92
    :cond_6b
    invoke-virtual {p0, v2, v5, v5, v4}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 96
    .line 97
    .line 98
    :cond_71
    const/4 v8, 0x4

    return-void
.end method

.method public final f(I)V
    .locals 4

    .line 1
    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->S:Lz5h;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lz5h;->d(I)V

    .line 6
    .line 7
    .line 8
    :cond_9
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->R:Ljava/util/ArrayList;

    .line 9
    .line 10
    if-eqz v0, :cond_27

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x0

    .line 17
    :goto_12
    const/4 v3, 0x7

    if-ge v1, v0, :cond_27

    .line 18
    .line 19
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->R:Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    const/4 v3, 0x4

    check-cast v2, Lz5h;

    .line 26
    .line 27
    const/4 v3, 0x0

    if-eqz v2, :cond_24

    .line 28
    .line 29
    invoke-interface {v2, p1}, Lz5h;->d(I)V

    .line 30
    .line 31
    .line 32
    :cond_24
    add-int/lit8 v1, v1, 0x1

    .line 33
    .line 34
    goto :goto_12

    .line 35
    :cond_27
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->T:Lz5h;

    .line 36
    .line 37
    if-eqz p0, :cond_2f

    .line 38
    .line 39
    const/4 v3, 0x4

    invoke-interface {p0, p1}, Lz5h;->d(I)V

    .line 40
    .line 41
    .line 42
    :cond_2f
    const/4 v3, 0x3

    return-void
.end method

.method public final g(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    .locals 3

    .line 1
    const/4 v2, 0x6

    if-nez p1, :cond_8

    .line 2
    .line 3
    new-instance p1, Landroid/graphics/Rect;

    .line 4
    .line 5
    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    .line 6
    .line 7
    .line 8
    :cond_8
    if-nez p2, :cond_11

    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    const/4 v2, 0x2

    invoke-virtual {p1, p0, p0, p0, p0}, Landroid/graphics/Rect;->set(IIII)V

    .line 12
    .line 13
    .line 14
    const/4 v2, 0x1

    return-object p1

    .line 15
    :cond_11
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/4 v2, 0x5

    iput v0, p1, Landroid/graphics/Rect;->left:I

    .line 20
    .line 21
    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    const/4 v2, 0x1

    iput v0, p1, Landroid/graphics/Rect;->right:I

    .line 26
    .line 27
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    const/4 v2, 0x3

    iput v0, p1, Landroid/graphics/Rect;->top:I

    .line 32
    .line 33
    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    iput v0, p1, Landroid/graphics/Rect;->bottom:I

    .line 38
    .line 39
    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    :goto_30
    instance-of v0, p2, Landroid/view/ViewGroup;

    .line 44
    .line 45
    if-eqz v0, :cond_68

    .line 46
    .line 47
    if-eq p2, p0, :cond_68

    .line 48
    .line 49
    check-cast p2, Landroid/view/ViewGroup;

    .line 50
    .line 51
    iget v0, p1, Landroid/graphics/Rect;->left:I

    .line 52
    .line 53
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    const/4 v2, 0x4

    add-int/2addr v1, v0

    .line 58
    iput v1, p1, Landroid/graphics/Rect;->left:I

    .line 59
    .line 60
    iget v0, p1, Landroid/graphics/Rect;->right:I

    .line 61
    .line 62
    const/4 v2, 0x1

    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    add-int/2addr v1, v0

    .line 67
    iput v1, p1, Landroid/graphics/Rect;->right:I

    .line 68
    .line 69
    const/4 v2, 0x4

    iget v0, p1, Landroid/graphics/Rect;->top:I

    .line 70
    .line 71
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    add-int/2addr v1, v0

    .line 76
    iput v1, p1, Landroid/graphics/Rect;->top:I

    .line 77
    .line 78
    const/4 v2, 0x0

    iget v0, p1, Landroid/graphics/Rect;->bottom:I

    .line 79
    .line 80
    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    const/4 v2, 0x0

    add-int/2addr v1, v0

    .line 85
    const/4 v2, 0x5

    iput v1, p1, Landroid/graphics/Rect;->bottom:I

    .line 86
    .line 87
    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 88
    .line 89
    .line 90
    move-result-object p2

    .line 91
    goto :goto_30

    .line 92
    :cond_68
    const/4 v2, 0x4

    return-object p1
.end method

.method public final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    const/4 v1, 0x4

    new-instance p0, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 2
    .line 3
    const/4 v1, 0x0

    const/4 v0, -0x1

    .line 4
    invoke-direct {p0, v0, v0}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 5
    .line 6
    .line 7
    const/4 v1, 0x6

    const/4 v0, 0x0

    .line 8
    iput v0, p0, Landroidx/viewpager/widget/ViewPager$LayoutParams;->c:F

    .line 9
    .line 10
    return-object p0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    .line 1
    const/4 v1, 0x3

    new-instance v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 2
    .line 3
    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const/4 v1, 0x1

    invoke-direct {v0, p0, p1}, Landroidx/viewpager/widget/ViewPager$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 8
    .line 9
    .line 10
    const/4 v1, 0x7

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    .line 11
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    const/4 v0, 0x1

    return-object p0
.end method

.method public getAdapter()Lnfb;
    .locals 1

    .line 1
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 2
    .line 3
    const/4 v0, 0x0

    return-object p0
.end method

.method public final getChildDrawingOrder(II)I
    .locals 3

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->a0:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    if-ne v0, v1, :cond_9

    .line 5
    .line 6
    add-int/lit8 p1, p1, -0x1

    .line 7
    .line 8
    sub-int p2, p1, p2

    .line 9
    .line 10
    :cond_9
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->b0:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    const/4 v2, 0x1

    check-cast p0, Landroid/view/View;

    .line 17
    .line 18
    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    const/4 v2, 0x0

    check-cast p0, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 23
    .line 24
    iget p0, p0, Landroidx/viewpager/widget/ViewPager$LayoutParams;->f:I

    .line 25
    .line 26
    const/4 v2, 0x1

    return p0
.end method

.method public getCurrentItem()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 2
    .line 3
    return p0
.end method

.method public getOffscreenPageLimit()I
    .locals 1

    .line 1
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 2
    .line 3
    return p0
.end method

.method public getPageMargin()I
    .locals 1

    .line 1
    iget p0, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 2
    .line 3
    return p0
.end method

.method public final h(Landroid/view/View;)Lx5h;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_1
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 3
    .line 4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    if-ge v0, v2, :cond_1e

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Lx5h;

    .line 15
    .line 16
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 17
    .line 18
    iget-object v3, v1, Lx5h;->a:Ljava/lang/Object;

    .line 19
    .line 20
    invoke-virtual {v2, p1, v3}, Lnfb;->f(Landroid/view/View;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-eqz v2, :cond_1b

    .line 25
    .line 26
    const/4 v4, 0x2

    return-object v1

    .line 27
    :cond_1b
    add-int/lit8 v0, v0, 0x1

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_1e
    const/4 v4, 0x7

    const/4 p0, 0x0

    .line 31
    return-object p0
.end method

.method public final i()Lx5h;
    .locals 14

    .line 1
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v13, 0x6

    const/4 v1, 0x0

    .line 6
    if-lez v0, :cond_10

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    int-to-float v2, v2

    .line 13
    int-to-float v3, v0

    .line 14
    div-float/2addr v2, v3

    .line 15
    goto :goto_12

    .line 16
    :cond_10
    move v2, v1

    move v2, v1

    .line 17
    :goto_12
    if-lez v0, :cond_1b

    .line 18
    .line 19
    const/4 v13, 0x7

    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 20
    .line 21
    int-to-float v3, v3

    .line 22
    int-to-float v0, v0

    .line 23
    div-float/2addr v3, v0

    .line 24
    goto :goto_1d

    .line 25
    :cond_1b
    const/4 v13, 0x3

    move v3, v1

    .line 26
    :goto_1d
    const/4 v0, 0x0

    .line 27
    const/4 v4, -0x1

    .line 28
    const/4 v13, 0x1

    const/4 v5, 0x1

    .line 29
    const/4 v6, 0x0

    .line 30
    const/4 v13, 0x2

    move v8, v0

    .line 31
    move v9, v5

    move v9, v5

    .line 32
    move-object v7, v6

    .line 33
    move v6, v4

    .line 34
    move v4, v1

    .line 35
    :goto_29
    const/4 v13, 0x6

    iget-object v10, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 38
    .line 39
    .line 40
    move-result v11

    .line 41
    if-ge v8, v11, :cond_85

    .line 42
    .line 43
    invoke-virtual {v10, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v11

    .line 47
    const/4 v13, 0x2

    check-cast v11, Lx5h;

    .line 48
    .line 49
    if-nez v9, :cond_57

    .line 50
    .line 51
    iget v12, v11, Lx5h;->b:I

    .line 52
    .line 53
    add-int/2addr v6, v5

    .line 54
    if-eq v12, v6, :cond_57

    .line 55
    .line 56
    add-float/2addr v1, v4

    .line 57
    add-float/2addr v1, v3

    .line 58
    iget-object v4, p0, Landroidx/viewpager/widget/ViewPager;->c:Lx5h;

    .line 59
    .line 60
    iput v1, v4, Lx5h;->e:F

    .line 61
    .line 62
    const/4 v13, 0x2

    iput v6, v4, Lx5h;->b:I

    .line 63
    .line 64
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 65
    .line 66
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    const/4 v13, 0x5

    const/high16 v1, 0x3f800000    # 1.0f

    .line 70
    .line 71
    iput v1, v4, Lx5h;->d:F

    .line 72
    .line 73
    add-int/lit8 v8, v8, -0x1

    .line 74
    .line 75
    move-object v6, v4

    .line 76
    goto :goto_58

    .line 77
    :cond_57
    move-object v6, v11

    .line 78
    :goto_58
    iget v1, v6, Lx5h;->e:F

    .line 79
    .line 80
    const/4 v13, 0x3

    iget v4, v6, Lx5h;->d:F

    .line 81
    .line 82
    add-float/2addr v4, v1

    .line 83
    add-float/2addr v4, v3

    .line 84
    if-nez v9, :cond_65

    .line 85
    .line 86
    cmpl-float v9, v2, v1

    .line 87
    .line 88
    if-ltz v9, :cond_85

    .line 89
    .line 90
    :cond_65
    const/4 v13, 0x6

    cmpg-float v4, v2, v4

    .line 91
    .line 92
    const/4 v13, 0x5

    if-ltz v4, :cond_84

    .line 93
    .line 94
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    sub-int/2addr v4, v5

    .line 99
    if-ne v8, v4, :cond_73

    .line 100
    .line 101
    goto :goto_84

    .line 102
    :cond_73
    const/4 v13, 0x5

    iget v4, v6, Lx5h;->b:I

    .line 103
    .line 104
    const/4 v13, 0x2

    iget v7, v6, Lx5h;->d:F

    .line 105
    .line 106
    add-int/lit8 v8, v8, 0x1

    .line 107
    .line 108
    move-object v9, v6

    .line 109
    move v6, v4

    .line 110
    const/4 v13, 0x2

    move v4, v7

    .line 111
    move-object v7, v9

    .line 112
    const/4 v13, 0x3

    move v9, v0

    .line 113
    const/4 v13, 0x2

    goto :goto_29

    .line 114
    :cond_84
    :goto_84
    return-object v6

    .line 115
    :cond_85
    const/4 v13, 0x5

    return-object v7
.end method

.method public final j(I)Lx5h;
    .locals 4

    .line 1
    const/4 v3, 0x3

    const/4 v0, 0x0

    .line 2
    :goto_2
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 3
    .line 4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 5
    .line 6
    .line 7
    move-result v2

    .line 8
    const/4 v3, 0x4

    if-ge v0, v2, :cond_1b

    .line 9
    .line 10
    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Lx5h;

    .line 15
    .line 16
    iget v2, v1, Lx5h;->b:I

    .line 17
    .line 18
    if-ne v2, p1, :cond_17

    .line 19
    .line 20
    return-object v1

    .line 21
    :cond_17
    const/4 v3, 0x6

    add-int/lit8 v0, v0, 0x1

    .line 22
    .line 23
    goto :goto_2

    .line 24
    :cond_1b
    const/4 v3, 0x0

    const/4 p0, 0x0

    .line 25
    const/4 v3, 0x4

    return-object p0
.end method

.method public final k(IFI)V
    .locals 12

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->Q:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-lez v0, :cond_6e

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 16
    .line 17
    .line 18
    move-result v4

    .line 19
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 24
    .line 25
    .line 26
    move-result v6

    .line 27
    move v7, v1

    .line 28
    :goto_1b
    if-ge v7, v6, :cond_6e

    .line 29
    .line 30
    invoke-virtual {p0, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 31
    .line 32
    .line 33
    move-result-object v8

    .line 34
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 35
    .line 36
    .line 37
    move-result-object v9

    .line 38
    check-cast v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 39
    .line 40
    iget-boolean v10, v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 41
    .line 42
    if-nez v10, :cond_2c

    .line 43
    .line 44
    goto :goto_6b

    .line 45
    :cond_2c
    iget v9, v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;->b:I

    .line 46
    .line 47
    and-int/lit8 v9, v9, 0x7

    .line 48
    .line 49
    if-eq v9, v2, :cond_52

    .line 50
    .line 51
    const/4 v10, 0x3

    .line 52
    if-eq v9, v10, :cond_4c

    .line 53
    .line 54
    const/4 v10, 0x5

    .line 55
    if-eq v9, v10, :cond_3a

    .line 56
    .line 57
    move v9, v3

    .line 58
    goto :goto_5f

    .line 59
    :cond_3a
    sub-int v9, v5, v4

    .line 60
    .line 61
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 62
    .line 63
    .line 64
    move-result v10

    .line 65
    sub-int/2addr v9, v10

    .line 66
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 67
    .line 68
    .line 69
    move-result v10

    .line 70
    add-int/2addr v4, v10

    .line 71
    :goto_46
    move v11, v9

    .line 72
    move v9, v3

    move v9, v3

    .line 73
    move v3, v11

    move v3, v11

    .line 74
    goto :goto_5f

    .line 75
    :cond_4c
    invoke-virtual {v8}, Landroid/view/View;->getWidth()I

    .line 76
    .line 77
    .line 78
    move-result v9

    .line 79
    add-int/2addr v9, v3

    .line 80
    goto :goto_5f

    .line 81
    :cond_52
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 82
    .line 83
    .line 84
    move-result v9

    .line 85
    sub-int v9, v5, v9

    .line 86
    .line 87
    div-int/lit8 v9, v9, 0x2

    .line 88
    .line 89
    invoke-static {v9, v3}, Ljava/lang/Math;->max(II)I

    .line 90
    .line 91
    .line 92
    move-result v9

    .line 93
    goto :goto_46

    .line 94
    :goto_5f
    add-int/2addr v3, v0

    .line 95
    invoke-virtual {v8}, Landroid/view/View;->getLeft()I

    .line 96
    .line 97
    .line 98
    move-result v10

    .line 99
    sub-int/2addr v3, v10

    .line 100
    if-eqz v3, :cond_6a

    .line 101
    .line 102
    invoke-virtual {v8, v3}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 103
    .line 104
    .line 105
    :cond_6a
    move v3, v9

    .line 106
    :goto_6b
    add-int/lit8 v7, v7, 0x1

    .line 107
    .line 108
    goto :goto_1b

    .line 109
    :cond_6e
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->S:Lz5h;

    .line 110
    .line 111
    if-eqz v0, :cond_75

    .line 112
    .line 113
    invoke-interface {v0, p1, p2, p3}, Lz5h;->b(IFI)V

    .line 114
    .line 115
    .line 116
    :cond_75
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->R:Ljava/util/ArrayList;

    .line 117
    .line 118
    if-eqz v0, :cond_91

    .line 119
    .line 120
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    move v3, v1

    move v3, v1

    .line 125
    :goto_7f
    if-ge v3, v0, :cond_91

    .line 126
    .line 127
    iget-object v4, p0, Landroidx/viewpager/widget/ViewPager;->R:Ljava/util/ArrayList;

    .line 128
    .line 129
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v4

    .line 133
    check-cast v4, Lz5h;

    .line 134
    .line 135
    if-eqz v4, :cond_8e

    .line 136
    .line 137
    invoke-interface {v4, p1, p2, p3}, Lz5h;->b(IFI)V

    .line 138
    .line 139
    .line 140
    :cond_8e
    add-int/lit8 v3, v3, 0x1

    .line 141
    .line 142
    goto :goto_7f

    .line 143
    :cond_91
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->T:Lz5h;

    .line 144
    .line 145
    if-eqz v0, :cond_98

    .line 146
    .line 147
    invoke-interface {v0, p1, p2, p3}, Lz5h;->b(IFI)V

    .line 148
    .line 149
    .line 150
    :cond_98
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->V:Lde3;

    .line 151
    .line 152
    if-eqz p1, :cond_101

    .line 153
    .line 154
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 155
    .line 156
    .line 157
    move-result p1

    .line 158
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 159
    .line 160
    .line 161
    move-result p2

    .line 162
    :goto_a4
    if-ge v1, p2, :cond_101

    .line 163
    .line 164
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 165
    .line 166
    .line 167
    move-result-object p3

    .line 168
    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    check-cast v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 173
    .line 174
    iget-boolean v0, v0, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 175
    .line 176
    if-eqz v0, :cond_b5

    .line 177
    .line 178
    goto :goto_fe

    .line 179
    :cond_b5
    invoke-virtual {p3}, Landroid/view/View;->getLeft()I

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    sub-int/2addr v0, p1

    .line 184
    int-to-float v0, v0

    .line 185
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    int-to-float v3, v3

    .line 190
    div-float/2addr v0, v3

    .line 191
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->V:Lde3;

    .line 192
    .line 193
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    const/high16 v3, -0x40800000    # -1.0f

    .line 197
    .line 198
    cmpg-float v3, v0, v3

    .line 199
    .line 200
    const/4 v4, 0x0

    .line 201
    if-gez v3, :cond_d1

    .line 202
    .line 203
    invoke-virtual {p3, v4}, Landroid/view/View;->setAlpha(F)V

    .line 204
    .line 205
    .line 206
    goto :goto_fe

    .line 207
    :cond_d1
    const/high16 v3, 0x3f800000    # 1.0f

    .line 208
    .line 209
    cmpg-float v5, v0, v3

    .line 210
    .line 211
    if-gtz v5, :cond_fb

    .line 212
    .line 213
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 214
    .line 215
    .line 216
    move-result v4

    .line 217
    sub-float v4, v3, v4

    .line 218
    .line 219
    const v5, 0x3dccccd0    # 0.100000024f

    .line 220
    .line 221
    .line 222
    mul-float/2addr v4, v5

    .line 223
    const v5, 0x3f666666    # 0.9f

    .line 224
    .line 225
    .line 226
    add-float/2addr v4, v5

    .line 227
    invoke-virtual {p3, v4}, Landroid/view/View;->setScaleX(F)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {p3, v4}, Landroid/view/View;->setScaleY(F)V

    .line 231
    .line 232
    .line 233
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 234
    .line 235
    .line 236
    move-result v0

    .line 237
    sub-float/2addr v3, v0

    .line 238
    const v0, 0x3f7ae148    # 0.98f

    .line 239
    .line 240
    .line 241
    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    .line 242
    .line 243
    .line 244
    move-result v0

    .line 245
    invoke-virtual {p3, v0}, Landroid/view/View;->setAlpha(F)V

    .line 246
    .line 247
    .line 248
    goto :goto_fe

    .line 249
    :cond_fb
    invoke-virtual {p3, v4}, Landroid/view/View;->setAlpha(F)V

    .line 250
    .line 251
    .line 252
    :goto_fe
    add-int/lit8 v1, v1, 0x1

    .line 253
    .line 254
    goto :goto_a4

    .line 255
    :cond_101
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->P:Z

    .line 256
    .line 257
    return-void
.end method

.method public final l(Landroid/view/MotionEvent;)V
    .locals 4

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v3, 0x6

    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 10
    .line 11
    if-ne v1, v2, :cond_29

    .line 12
    .line 13
    if-nez v0, :cond_13

    .line 14
    .line 15
    const/4 v0, 0x5

    const/4 v0, 0x1

    .line 16
    goto :goto_15

    .line 17
    :cond_13
    const/4 v3, 0x5

    const/4 v0, 0x0

    .line 18
    :goto_15
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 23
    .line 24
    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 29
    .line 30
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 31
    .line 32
    if-eqz p0, :cond_29

    .line 33
    .line 34
    invoke-virtual {p0}, Landroid/view/VelocityTracker;->clear()V

    .line 35
    .line 36
    .line 37
    :cond_29
    return-void
.end method

.method public final m()Z
    .locals 5

    .line 1
    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1b

    .line 5
    .line 6
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 7
    .line 8
    invoke-virtual {v0}, Lnfb;->c()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v3, 0x1

    move v4, v3

    .line 13
    sub-int/2addr v0, v3

    .line 14
    if-ge v2, v0, :cond_1b

    .line 15
    .line 16
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 17
    .line 18
    add-int/2addr v0, v3

    .line 19
    const/4 v4, 0x2

    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 20
    .line 21
    invoke-virtual {p0, v0, v1, v3, v1}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 22
    .line 23
    .line 24
    return v3

    .line 25
    :cond_1b
    return v1
.end method

.method public final n(I)Z
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 2
    .line 3
    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const-string v1, "onPageScrolled did not call superclass implementation"

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v7, 0x2

    if-nez v0, :cond_23

    .line 11
    .line 12
    iget-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 13
    .line 14
    if-eqz p1, :cond_12

    .line 15
    .line 16
    goto :goto_1d

    .line 17
    :cond_12
    const/4 v7, 0x6

    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->P:Z

    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    invoke-virtual {p0, v2, p1, v2}, Landroidx/viewpager/widget/ViewPager;->k(IFI)V

    .line 21
    .line 22
    .line 23
    iget-boolean p0, p0, Landroidx/viewpager/widget/ViewPager;->P:Z

    .line 24
    .line 25
    if-eqz p0, :cond_1e

    .line 26
    .line 27
    :goto_1d
    return v2

    .line 28
    :cond_1e
    invoke-static {v1}, Le6d;->r(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const/4 v7, 0x3

    return v2

    .line 32
    :cond_23
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->i()Lx5h;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    const/4 v7, 0x0

    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 41
    .line 42
    add-int v5, v3, v4

    .line 43
    .line 44
    int-to-float v4, v4

    .line 45
    int-to-float v3, v3

    .line 46
    div-float/2addr v4, v3

    .line 47
    iget v6, v0, Lx5h;->b:I

    .line 48
    .line 49
    int-to-float p1, p1

    .line 50
    div-float/2addr p1, v3

    .line 51
    const/4 v7, 0x6

    iget v3, v0, Lx5h;->e:F

    .line 52
    .line 53
    const/4 v7, 0x0

    sub-float/2addr p1, v3

    .line 54
    const/4 v7, 0x3

    iget v0, v0, Lx5h;->d:F

    .line 55
    .line 56
    add-float/2addr v0, v4

    .line 57
    const/4 v7, 0x4

    div-float/2addr p1, v0

    .line 58
    int-to-float v0, v5

    .line 59
    mul-float/2addr v0, p1

    .line 60
    float-to-int v0, v0

    .line 61
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->P:Z

    .line 62
    .line 63
    invoke-virtual {p0, v6, p1, v0}, Landroidx/viewpager/widget/ViewPager;->k(IFI)V

    .line 64
    .line 65
    .line 66
    iget-boolean p0, p0, Landroidx/viewpager/widget/ViewPager;->P:Z

    .line 67
    .line 68
    const/4 v7, 0x0

    if-eqz p0, :cond_51

    .line 69
    .line 70
    const/4 p0, 0x1

    .line 71
    return p0

    .line 72
    :cond_51
    invoke-static {v1}, Le6d;->r(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    const/4 v7, 0x6

    return v2
.end method

.method public final o(F)Z
    .locals 10

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 2
    .line 3
    const/4 v9, 0x6

    sub-float/2addr v0, p1

    .line 4
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    const/4 v9, 0x3

    int-to-float p1, p1

    .line 11
    add-float/2addr p1, v0

    .line 12
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    int-to-float v0, v0

    .line 17
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 18
    .line 19
    mul-float/2addr v1, v0

    .line 20
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 21
    .line 22
    const/4 v9, 0x2

    mul-float/2addr v2, v0

    .line 23
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 24
    .line 25
    const/4 v4, 0x0

    .line 26
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    check-cast v5, Lx5h;

    .line 31
    .line 32
    const/4 v6, 0x1

    move v9, v6

    .line 33
    invoke-static {v3, v6}, Lhvb;->t(Ljava/util/ArrayList;I)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    check-cast v3, Lx5h;

    .line 38
    .line 39
    const/4 v9, 0x7

    iget v7, v5, Lx5h;->b:I

    .line 40
    .line 41
    if-eqz v7, :cond_36

    .line 42
    .line 43
    const/4 v9, 0x5

    iget v1, v5, Lx5h;->e:F

    .line 44
    .line 45
    mul-float/2addr v1, v0

    .line 46
    const/4 v9, 0x2

    move v5, v4

    .line 47
    goto :goto_38

    .line 48
    :cond_36
    const/4 v9, 0x6

    move v5, v6

    .line 49
    :goto_38
    const/4 v9, 0x6

    iget v7, v3, Lx5h;->b:I

    .line 50
    .line 51
    iget-object v8, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 52
    .line 53
    invoke-virtual {v8}, Lnfb;->c()I

    .line 54
    .line 55
    .line 56
    move-result v8

    .line 57
    sub-int/2addr v8, v6

    .line 58
    if-eq v7, v8, :cond_4a

    .line 59
    .line 60
    const/4 v9, 0x3

    iget v2, v3, Lx5h;->e:F

    .line 61
    .line 62
    mul-float/2addr v2, v0

    .line 63
    move v3, v4

    .line 64
    goto :goto_4b

    .line 65
    :cond_4a
    move v3, v6

    .line 66
    :goto_4b
    const/4 v9, 0x6

    cmpg-float v7, p1, v1

    .line 67
    .line 68
    if-gez v7, :cond_67

    .line 69
    .line 70
    if-eqz v5, :cond_64

    .line 71
    .line 72
    const/4 v9, 0x0

    sub-float p1, v1, p1

    .line 73
    .line 74
    const/4 v9, 0x4

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    const/4 v9, 0x1

    div-float/2addr p1, v0

    .line 79
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/widget/EdgeEffect;

    .line 80
    .line 81
    const/4 v9, 0x1

    invoke-virtual {v0, p1}, Landroid/widget/EdgeEffect;->onPull(F)V

    .line 82
    .line 83
    .line 84
    const/4 v9, 0x1

    move v4, v6

    .line 85
    :cond_64
    move p1, v1

    move p1, v1

    .line 86
    goto :goto_7d

    .line 87
    :cond_67
    cmpl-float v1, p1, v2

    .line 88
    .line 89
    const/4 v9, 0x1

    if-lez v1, :cond_7d

    .line 90
    .line 91
    if-eqz v3, :cond_7c

    .line 92
    .line 93
    sub-float/2addr p1, v2

    .line 94
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    const/4 v9, 0x6

    div-float/2addr p1, v0

    .line 99
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->N:Landroid/widget/EdgeEffect;

    .line 100
    .line 101
    const/4 v9, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/EdgeEffect;->onPull(F)V

    .line 102
    .line 103
    .line 104
    move v4, v6

    .line 105
    :cond_7c
    move p1, v2

    .line 106
    :cond_7d
    :goto_7d
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 107
    .line 108
    float-to-int v1, p1

    .line 109
    int-to-float v2, v1

    .line 110
    const/4 v9, 0x1

    sub-float/2addr p1, v2

    .line 111
    add-float/2addr p1, v0

    .line 112
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 113
    .line 114
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    invoke-virtual {p0, v1, p1}, Landroid/view/View;->scrollTo(II)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->n(I)Z

    .line 122
    .line 123
    .line 124
    return v4
.end method

.method public final onAttachedToWindow()V
    .locals 2

    .line 1
    const/4 v1, 0x1

    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    const/4 v1, 0x6

    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 6
    .line 7
    const/4 v1, 0x2

    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->c0:Lb1c;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 7
    .line 8
    if-eqz v0, :cond_14

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x5

    if-nez v1, :cond_14

    .line 15
    .line 16
    invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V

    .line 17
    .line 18
    .line 19
    :cond_14
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 20
    .line 21
    .line 22
    const/4 v2, 0x6

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V

    .line 4
    .line 5
    .line 6
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 7
    .line 8
    if-lez v1, :cond_aa

    .line 9
    .line 10
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->n:Landroid/graphics/drawable/Drawable;

    .line 11
    .line 12
    if-eqz v1, :cond_aa

    .line 13
    .line 14
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-lez v2, :cond_aa

    .line 21
    .line 22
    iget-object v2, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 23
    .line 24
    if-eqz v2, :cond_aa

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/view/View;->getScrollX()I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    iget v4, v0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 35
    .line 36
    int-to-float v4, v4

    .line 37
    int-to-float v5, v3

    .line 38
    div-float/2addr v4, v5

    .line 39
    const/4 v6, 0x0

    .line 40
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    check-cast v7, Lx5h;

    .line 45
    .line 46
    iget v8, v7, Lx5h;->e:F

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 49
    .line 50
    .line 51
    move-result v9

    .line 52
    iget v10, v7, Lx5h;->b:I

    .line 53
    .line 54
    add-int/lit8 v11, v9, -0x1

    .line 55
    .line 56
    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v11

    .line 60
    check-cast v11, Lx5h;

    .line 61
    .line 62
    iget v11, v11, Lx5h;->b:I

    .line 63
    .line 64
    :goto_3f
    if-ge v10, v11, :cond_aa

    .line 65
    .line 66
    :goto_41
    iget v12, v7, Lx5h;->b:I

    .line 67
    .line 68
    if-le v10, v12, :cond_50

    .line 69
    .line 70
    if-ge v6, v9, :cond_50

    .line 71
    .line 72
    add-int/lit8 v6, v6, 0x1

    .line 73
    .line 74
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v7

    .line 78
    check-cast v7, Lx5h;

    .line 79
    .line 80
    goto :goto_41

    .line 81
    :cond_50
    if-ne v10, v12, :cond_5c

    .line 82
    .line 83
    iget v8, v7, Lx5h;->e:F

    .line 84
    .line 85
    iget v12, v7, Lx5h;->d:F

    .line 86
    .line 87
    add-float v13, v8, v12

    .line 88
    .line 89
    mul-float/2addr v13, v5

    .line 90
    add-float/2addr v8, v12

    .line 91
    add-float/2addr v8, v4

    .line 92
    goto :goto_69

    .line 93
    :cond_5c
    iget-object v12, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 94
    .line 95
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 96
    .line 97
    .line 98
    const/high16 v12, 0x3f800000    # 1.0f

    .line 99
    .line 100
    add-float v13, v8, v12

    .line 101
    .line 102
    mul-float/2addr v13, v5

    .line 103
    add-float/2addr v12, v4

    .line 104
    add-float/2addr v12, v8

    .line 105
    move v8, v12

    .line 106
    :goto_69
    iget v12, v0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 107
    .line 108
    int-to-float v12, v12

    .line 109
    add-float/2addr v12, v13

    .line 110
    int-to-float v14, v2

    .line 111
    cmpl-float v12, v12, v14

    .line 112
    .line 113
    if-lez v12, :cond_93

    .line 114
    .line 115
    iget-object v12, v0, Landroidx/viewpager/widget/ViewPager;->n:Landroid/graphics/drawable/Drawable;

    .line 116
    .line 117
    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    .line 118
    .line 119
    .line 120
    move-result v14

    .line 121
    iget v15, v0, Landroidx/viewpager/widget/ViewPager;->o:I

    .line 122
    .line 123
    move-object/from16 v16, v1

    .line 124
    .line 125
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 126
    .line 127
    int-to-float v1, v1

    .line 128
    add-float/2addr v1, v13

    .line 129
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 130
    .line 131
    .line 132
    move-result v1

    .line 133
    move/from16 v17, v2

    .line 134
    .line 135
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->p:I

    .line 136
    .line 137
    invoke-virtual {v12, v14, v15, v1, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 138
    .line 139
    .line 140
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->n:Landroid/graphics/drawable/Drawable;

    .line 141
    .line 142
    move-object/from16 v2, p1

    .line 143
    .line 144
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 145
    .line 146
    .line 147
    goto :goto_9b

    .line 148
    :cond_93
    move-object/from16 v16, v1

    .line 149
    .line 150
    move/from16 v17, v2

    .line 151
    .line 152
    move-object/from16 v2, p1

    move-object/from16 v2, p1

    .line 153
    .line 154
    :goto_9b
    add-int v1, v17, v3

    .line 155
    .line 156
    int-to-float v1, v1

    .line 157
    cmpl-float v1, v13, v1

    .line 158
    .line 159
    if-lez v1, :cond_a3

    .line 160
    .line 161
    goto :goto_aa

    .line 162
    :cond_a3
    add-int/lit8 v10, v10, 0x1

    .line 163
    .line 164
    move-object/from16 v1, v16

    .line 165
    .line 166
    move/from16 v2, v17

    .line 167
    .line 168
    goto :goto_3f

    .line 169
    :cond_aa
    :goto_aa
    return-void
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 13

    .line 1
    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    and-int/lit16 v0, v0, 0xff

    .line 6
    .line 7
    const/4 v1, 0x3

    .line 8
    const/4 v12, 0x7

    const/4 v2, 0x0

    .line 9
    if-eq v0, v1, :cond_14d

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    if-ne v0, v1, :cond_11

    .line 13
    .line 14
    goto/16 :goto_14d

    .line 15
    .line 16
    :cond_11
    if-eqz v0, :cond_20

    .line 17
    .line 18
    const/4 v12, 0x4

    iget-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 19
    .line 20
    const/4 v12, 0x0

    if-eqz v3, :cond_1b

    .line 21
    .line 22
    const/4 v12, 0x5

    return v1

    .line 23
    :cond_1b
    iget-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 24
    .line 25
    if-eqz v3, :cond_20

    .line 26
    .line 27
    return v2

    .line 28
    :cond_20
    const/4 v3, 0x2

    .line 29
    if-eqz v0, :cond_e1

    .line 30
    .line 31
    if-eq v0, v3, :cond_30

    .line 32
    .line 33
    const/4 v12, 0x2

    const/4 v1, 0x6

    .line 34
    if-eq v0, v1, :cond_2b

    .line 35
    .line 36
    goto/16 :goto_13a

    .line 37
    .line 38
    :cond_2b
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->l(Landroid/view/MotionEvent;)V

    .line 39
    .line 40
    .line 41
    goto/16 :goto_13a

    .line 42
    .line 43
    :cond_30
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 44
    .line 45
    const/4 v3, -0x1

    .line 46
    if-ne v0, v3, :cond_37

    .line 47
    .line 48
    goto/16 :goto_13a

    .line 49
    .line 50
    :cond_37
    const/4 v12, 0x3

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    const/4 v12, 0x2

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 59
    .line 60
    const/4 v12, 0x4

    sub-float v4, v3, v4

    .line 61
    .line 62
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    const/4 v12, 0x5

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    const/4 v12, 0x3

    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->F:F

    .line 71
    .line 72
    sub-float v6, v0, v6

    .line 73
    .line 74
    const/4 v12, 0x1

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    .line 75
    .line 76
    .line 77
    move-result v6

    .line 78
    const/4 v12, 0x4

    const/4 v7, 0x0

    .line 79
    const/4 v12, 0x7

    cmpl-float v8, v4, v7

    .line 80
    .line 81
    if-eqz v8, :cond_95

    .line 82
    .line 83
    const/4 v12, 0x5

    iget v9, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 84
    .line 85
    iget v10, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 86
    .line 87
    const/4 v12, 0x2

    int-to-float v10, v10

    .line 88
    cmpg-float v10, v9, v10

    .line 89
    .line 90
    if-gez v10, :cond_6e

    .line 91
    .line 92
    const/4 v12, 0x7

    if-gtz v8, :cond_95

    .line 93
    .line 94
    :cond_6e
    const/4 v12, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 95
    .line 96
    .line 97
    move-result v10

    .line 98
    iget v11, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 99
    .line 100
    sub-int/2addr v10, v11

    .line 101
    int-to-float v10, v10

    .line 102
    const/4 v12, 0x1

    cmpl-float v9, v9, v10

    .line 103
    .line 104
    const/4 v12, 0x7

    if-lez v9, :cond_82

    .line 105
    .line 106
    cmpg-float v7, v4, v7

    .line 107
    .line 108
    if-gez v7, :cond_82

    .line 109
    .line 110
    goto :goto_95

    .line 111
    :cond_82
    const/4 v12, 0x7

    float-to-int v4, v4

    .line 112
    float-to-int v7, v3

    .line 113
    float-to-int v9, v0

    .line 114
    const/4 v12, 0x4

    invoke-static {p0, v2, v4, v7, v9}, Landroidx/viewpager/widget/ViewPager;->c(Landroid/view/View;ZIII)Z

    .line 115
    .line 116
    .line 117
    move-result v4

    .line 118
    if-eqz v4, :cond_95

    .line 119
    .line 120
    iput v3, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 121
    .line 122
    const/4 v12, 0x4

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->D:F

    .line 123
    .line 124
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 125
    .line 126
    return v2

    .line 127
    :cond_95
    :goto_95
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->B:I

    .line 128
    .line 129
    int-to-float v4, v2

    .line 130
    const/4 v12, 0x3

    cmpl-float v7, v5, v4

    .line 131
    .line 132
    if-lez v7, :cond_c8

    .line 133
    .line 134
    const/4 v12, 0x7

    const/high16 v7, 0x3f000000    # 0.5f

    .line 135
    .line 136
    const/4 v12, 0x6

    mul-float/2addr v5, v7

    .line 137
    cmpl-float v5, v5, v6

    .line 138
    .line 139
    if-lez v5, :cond_c8

    .line 140
    .line 141
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 142
    .line 143
    const/4 v12, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    if-eqz v4, :cond_b2

    .line 148
    .line 149
    invoke-interface {v4, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 150
    .line 151
    .line 152
    :cond_b2
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollState(I)V

    .line 153
    .line 154
    .line 155
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->E:F

    .line 156
    .line 157
    int-to-float v2, v2

    .line 158
    const/4 v12, 0x1

    if-lez v8, :cond_bd

    .line 159
    .line 160
    add-float/2addr v4, v2

    .line 161
    goto :goto_be

    .line 162
    :cond_bd
    sub-float/2addr v4, v2

    .line 163
    :goto_be
    const/4 v12, 0x5

    iput v4, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 164
    .line 165
    const/4 v12, 0x2

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->D:F

    .line 166
    .line 167
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 168
    .line 169
    .line 170
    goto :goto_cf

    .line 171
    :cond_c8
    cmpl-float v0, v6, v4

    .line 172
    .line 173
    if-lez v0, :cond_cf

    .line 174
    .line 175
    const/4 v12, 0x3

    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 176
    .line 177
    :cond_cf
    :goto_cf
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 178
    .line 179
    if-eqz v0, :cond_13a

    .line 180
    .line 181
    invoke-virtual {p0, v3}, Landroidx/viewpager/widget/ViewPager;->o(F)Z

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    if-eqz v0, :cond_13a

    .line 186
    .line 187
    sget-object v0, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 188
    .line 189
    const/4 v12, 0x3

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 190
    .line 191
    .line 192
    const/4 v12, 0x2

    goto :goto_13a

    .line 193
    :cond_e1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->E:F

    .line 198
    .line 199
    const/4 v12, 0x4

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 200
    .line 201
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 202
    .line 203
    .line 204
    move-result v0

    .line 205
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->F:F

    .line 206
    .line 207
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->D:F

    .line 208
    .line 209
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 214
    .line 215
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 216
    .line 217
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->k:Z

    .line 218
    .line 219
    const/4 v12, 0x5

    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 220
    .line 221
    invoke-virtual {v0}, Landroid/widget/Scroller;->computeScrollOffset()Z

    .line 222
    .line 223
    .line 224
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->d0:I

    .line 225
    .line 226
    const/4 v12, 0x3

    if-ne v4, v3, :cond_134

    .line 227
    .line 228
    invoke-virtual {v0}, Landroid/widget/Scroller;->getFinalX()I

    .line 229
    .line 230
    .line 231
    move-result v3

    .line 232
    invoke-virtual {v0}, Landroid/widget/Scroller;->getCurrX()I

    .line 233
    .line 234
    .line 235
    move-result v4

    .line 236
    sub-int/2addr v3, v4

    .line 237
    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    .line 238
    .line 239
    .line 240
    move-result v3

    .line 241
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->L:I

    .line 242
    .line 243
    if-le v3, v4, :cond_134

    .line 244
    .line 245
    invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V

    .line 246
    .line 247
    .line 248
    const/4 v12, 0x1

    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 249
    .line 250
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 251
    .line 252
    .line 253
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 254
    .line 255
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    const/4 v12, 0x7

    if-eqz v0, :cond_12e

    .line 260
    .line 261
    const/4 v12, 0x1

    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 262
    .line 263
    .line 264
    :cond_12e
    const/4 v12, 0x0

    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollState(I)V

    .line 265
    .line 266
    .line 267
    const/4 v12, 0x4

    goto :goto_13a

    .line 268
    :cond_134
    invoke-virtual {p0, v2}, Landroidx/viewpager/widget/ViewPager;->d(Z)V

    .line 269
    .line 270
    .line 271
    const/4 v12, 0x3

    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 272
    .line 273
    :cond_13a
    :goto_13a
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 274
    .line 275
    if-nez v0, :cond_145

    .line 276
    .line 277
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    const/4 v12, 0x1

    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 282
    .line 283
    :cond_145
    const/4 v12, 0x3

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 284
    .line 285
    .line 286
    const/4 v12, 0x0

    iget-boolean p0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 287
    .line 288
    return p0

    .line 289
    :cond_14d
    :goto_14d
    const/4 v12, 0x1

    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->s()Z

    .line 290
    .line 291
    .line 292
    return v2
.end method

.method public final onLayout(ZIIII)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    sub-int v2, p4, p2

    .line 8
    .line 9
    sub-int v3, p5, p3

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    .line 12
    .line 13
    .line 14
    move-result v4

    .line 15
    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    .line 16
    .line 17
    .line 18
    move-result v5

    .line 19
    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    .line 20
    .line 21
    .line 22
    move-result v6

    .line 23
    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    invoke-virtual {v0}, Landroid/view/View;->getScrollX()I

    .line 28
    .line 29
    .line 30
    move-result v8

    .line 31
    const/4 v10, 0x0

    .line 32
    const/4 v11, 0x0

    .line 33
    :goto_20
    const/16 v12, 0x8

    .line 34
    .line 35
    if-ge v10, v1, :cond_ba

    .line 36
    .line 37
    invoke-virtual {v0, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 38
    .line 39
    .line 40
    move-result-object v13

    .line 41
    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    .line 42
    .line 43
    .line 44
    move-result v14

    .line 45
    if-eq v14, v12, :cond_b6

    .line 46
    .line 47
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 48
    .line 49
    .line 50
    move-result-object v12

    .line 51
    check-cast v12, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 52
    .line 53
    iget-boolean v14, v12, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 54
    .line 55
    if-eqz v14, :cond_b6

    .line 56
    .line 57
    iget v12, v12, Landroidx/viewpager/widget/ViewPager$LayoutParams;->b:I

    .line 58
    .line 59
    and-int/lit8 v14, v12, 0x7

    .line 60
    .line 61
    and-int/lit8 v12, v12, 0x70

    .line 62
    .line 63
    const/4 v15, 0x1

    .line 64
    if-eq v14, v15, :cond_62

    .line 65
    .line 66
    const/4 v15, 0x3

    .line 67
    if-eq v14, v15, :cond_5c

    .line 68
    .line 69
    const/4 v15, 0x5

    .line 70
    if-eq v14, v15, :cond_49

    .line 71
    .line 72
    move v14, v4

    .line 73
    goto :goto_6f

    .line 74
    :cond_49
    sub-int v14, v2, v6

    .line 75
    .line 76
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 77
    .line 78
    .line 79
    move-result v15

    .line 80
    sub-int/2addr v14, v15

    .line 81
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 82
    .line 83
    .line 84
    move-result v15

    .line 85
    add-int/2addr v6, v15

    .line 86
    :goto_55
    move/from16 v17, v14

    .line 87
    .line 88
    move v14, v4

    move v14, v4

    .line 89
    move/from16 v4, v17

    .line 90
    .line 91
    goto :goto_6f

    .line 92
    :cond_5c
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 93
    .line 94
    .line 95
    move-result v14

    .line 96
    add-int/2addr v14, v4

    .line 97
    goto :goto_6f

    .line 98
    :cond_62
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 99
    .line 100
    .line 101
    move-result v14

    .line 102
    sub-int v14, v2, v14

    .line 103
    .line 104
    div-int/lit8 v14, v14, 0x2

    .line 105
    .line 106
    invoke-static {v14, v4}, Ljava/lang/Math;->max(II)I

    .line 107
    .line 108
    .line 109
    move-result v14

    .line 110
    goto :goto_55

    .line 111
    :goto_6f
    const/16 v15, 0x10

    .line 112
    .line 113
    if-eq v12, v15, :cond_96

    .line 114
    .line 115
    const/16 v15, 0x30

    .line 116
    .line 117
    if-eq v12, v15, :cond_90

    .line 118
    .line 119
    const/16 v15, 0x50

    .line 120
    .line 121
    if-eq v12, v15, :cond_7e

    .line 122
    .line 123
    move v12, v5

    move v12, v5

    .line 124
    goto :goto_a3

    .line 125
    :cond_7e
    sub-int v12, v3, v7

    .line 126
    .line 127
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 128
    .line 129
    .line 130
    move-result v15

    .line 131
    sub-int/2addr v12, v15

    .line 132
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 133
    .line 134
    .line 135
    move-result v15

    .line 136
    add-int/2addr v7, v15

    .line 137
    :goto_8a
    move/from16 v17, v12

    .line 138
    .line 139
    move v12, v5

    .line 140
    move/from16 v5, v17

    .line 141
    .line 142
    goto :goto_a3

    .line 143
    :cond_90
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 144
    .line 145
    .line 146
    move-result v12

    .line 147
    add-int/2addr v12, v5

    .line 148
    goto :goto_a3

    .line 149
    :cond_96
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 150
    .line 151
    .line 152
    move-result v12

    .line 153
    sub-int v12, v3, v12

    .line 154
    .line 155
    div-int/lit8 v12, v12, 0x2

    .line 156
    .line 157
    invoke-static {v12, v5}, Ljava/lang/Math;->max(II)I

    .line 158
    .line 159
    .line 160
    move-result v12

    .line 161
    goto :goto_8a

    .line 162
    :goto_a3
    add-int/2addr v4, v8

    .line 163
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    .line 164
    .line 165
    .line 166
    move-result v15

    .line 167
    add-int/2addr v15, v4

    .line 168
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    .line 169
    .line 170
    .line 171
    move-result v16

    .line 172
    add-int v9, v16, v5

    .line 173
    .line 174
    invoke-virtual {v13, v4, v5, v15, v9}, Landroid/view/View;->layout(IIII)V

    .line 175
    .line 176
    .line 177
    add-int/lit8 v11, v11, 0x1

    .line 178
    .line 179
    move v5, v12

    .line 180
    move v4, v14

    .line 181
    :cond_b6
    add-int/lit8 v10, v10, 0x1

    .line 182
    .line 183
    goto/16 :goto_20

    .line 184
    .line 185
    :cond_ba
    sub-int/2addr v2, v4

    .line 186
    sub-int/2addr v2, v6

    .line 187
    const/4 v6, 0x0

    .line 188
    :goto_bd
    if-ge v6, v1, :cond_10a

    .line 189
    .line 190
    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 191
    .line 192
    .line 193
    move-result-object v8

    .line 194
    invoke-virtual {v8}, Landroid/view/View;->getVisibility()I

    .line 195
    .line 196
    .line 197
    move-result v9

    .line 198
    if-eq v9, v12, :cond_107

    .line 199
    .line 200
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 201
    .line 202
    .line 203
    move-result-object v9

    .line 204
    check-cast v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 205
    .line 206
    iget-boolean v10, v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 207
    .line 208
    if-nez v10, :cond_107

    .line 209
    .line 210
    invoke-virtual {v0, v8}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 211
    .line 212
    .line 213
    move-result-object v10

    .line 214
    if-eqz v10, :cond_107

    .line 215
    .line 216
    int-to-float v13, v2

    .line 217
    iget v10, v10, Lx5h;->e:F

    .line 218
    .line 219
    mul-float/2addr v10, v13

    .line 220
    float-to-int v10, v10

    .line 221
    add-int/2addr v10, v4

    .line 222
    iget-boolean v14, v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;->d:Z

    .line 223
    .line 224
    if-eqz v14, :cond_fa

    .line 225
    .line 226
    const/4 v14, 0x0

    .line 227
    iput-boolean v14, v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;->d:Z

    .line 228
    .line 229
    iget v9, v9, Landroidx/viewpager/widget/ViewPager$LayoutParams;->c:F

    .line 230
    .line 231
    mul-float/2addr v13, v9

    .line 232
    float-to-int v9, v13

    .line 233
    const/high16 v13, 0x40000000    # 2.0f

    .line 234
    .line 235
    invoke-static {v9, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 236
    .line 237
    .line 238
    move-result v9

    .line 239
    sub-int v14, v3, v5

    .line 240
    .line 241
    sub-int/2addr v14, v7

    .line 242
    invoke-static {v14, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 243
    .line 244
    .line 245
    move-result v13

    .line 246
    invoke-virtual {v8, v9, v13}, Landroid/view/View;->measure(II)V

    .line 247
    .line 248
    .line 249
    :cond_fa
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    .line 250
    .line 251
    .line 252
    move-result v9

    .line 253
    add-int/2addr v9, v10

    .line 254
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredHeight()I

    .line 255
    .line 256
    .line 257
    move-result v13

    .line 258
    add-int/2addr v13, v5

    .line 259
    invoke-virtual {v8, v10, v5, v9, v13}, Landroid/view/View;->layout(IIII)V

    .line 260
    .line 261
    .line 262
    :cond_107
    add-int/lit8 v6, v6, 0x1

    .line 263
    .line 264
    goto :goto_bd

    .line 265
    :cond_10a
    iput v5, v0, Landroidx/viewpager/widget/ViewPager;->o:I

    .line 266
    .line 267
    sub-int/2addr v3, v7

    .line 268
    iput v3, v0, Landroidx/viewpager/widget/ViewPager;->p:I

    .line 269
    .line 270
    iput v11, v0, Landroidx/viewpager/widget/ViewPager;->Q:I

    .line 271
    .line 272
    iget-boolean v1, v0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 273
    .line 274
    if-eqz v1, :cond_11c

    .line 275
    .line 276
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 277
    .line 278
    const/4 v14, 0x0

    .line 279
    invoke-virtual {v0, v1, v14, v14, v14}, Landroidx/viewpager/widget/ViewPager;->t(IIZZ)V

    .line 280
    .line 281
    .line 282
    goto :goto_11d

    .line 283
    :cond_11c
    const/4 v14, 0x0

    .line 284
    :goto_11d
    iput-boolean v14, v0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 285
    .line 286
    return-void
.end method

.method public final onMeasure(II)V
    .locals 13

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0, p1}, Landroid/view/View;->getDefaultSize(II)I

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    invoke-static {v0, p2}, Landroid/view/View;->getDefaultSize(II)I

    .line 7
    .line 8
    .line 9
    move-result p2

    .line 10
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    div-int/lit8 p2, p1, 0xa

    .line 18
    .line 19
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->z:I

    .line 20
    .line 21
    invoke-static {p2, v1}, Ljava/lang/Math;->min(II)I

    .line 22
    .line 23
    .line 24
    move-result p2

    .line 25
    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->A:I

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    sub-int/2addr p1, p2

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    sub-int/2addr p1, p2

    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 38
    .line 39
    .line 40
    move-result p2

    .line 41
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    sub-int/2addr p2, v1

    .line 46
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    sub-int/2addr p2, v1

    .line 51
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    move v2, v0

    .line 56
    :goto_37
    const/16 v3, 0x8

    .line 57
    .line 58
    const/4 v4, 0x1

    .line 59
    const/high16 v5, 0x40000000    # 2.0f

    .line 60
    .line 61
    if-ge v2, v1, :cond_b3

    .line 62
    .line 63
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    .line 68
    .line 69
    .line 70
    move-result v7

    .line 71
    if-eq v7, v3, :cond_b0

    .line 72
    .line 73
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    check-cast v3, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 78
    .line 79
    if-eqz v3, :cond_b0

    .line 80
    .line 81
    iget-boolean v7, v3, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 82
    .line 83
    if-eqz v7, :cond_b0

    .line 84
    .line 85
    iget v7, v3, Landroidx/viewpager/widget/ViewPager$LayoutParams;->b:I

    .line 86
    .line 87
    and-int/lit8 v8, v7, 0x7

    .line 88
    .line 89
    and-int/lit8 v7, v7, 0x70

    .line 90
    .line 91
    const/16 v9, 0x30

    .line 92
    .line 93
    if-eq v7, v9, :cond_66

    .line 94
    .line 95
    const/16 v9, 0x50

    .line 96
    .line 97
    if-ne v7, v9, :cond_63

    .line 98
    .line 99
    goto :goto_66

    .line 100
    :cond_63
    move v7, v0

    move v7, v0

    .line 101
    goto :goto_67

    .line 102
    :cond_66
    :goto_66
    move v7, v4

    .line 103
    :goto_67
    const/4 v9, 0x3

    .line 104
    if-eq v8, v9, :cond_70

    .line 105
    .line 106
    const/4 v9, 0x5

    .line 107
    if-ne v8, v9, :cond_6e

    .line 108
    .line 109
    goto :goto_70

    .line 110
    :cond_6e
    move v4, v0

    move v4, v0

    .line 111
    :cond_70
    :goto_70
    const/high16 v8, -0x80000000

    .line 112
    .line 113
    if-eqz v7, :cond_78

    .line 114
    .line 115
    move v9, v8

    .line 116
    move v8, v5

    move v8, v5

    .line 117
    goto :goto_7d

    .line 118
    :cond_78
    if-eqz v4, :cond_7c

    .line 119
    .line 120
    move v9, v5

    .line 121
    goto :goto_7d

    .line 122
    :cond_7c
    move v9, v8

    .line 123
    :goto_7d
    iget v10, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 124
    .line 125
    const/4 v11, -0x1

    .line 126
    const/4 v12, -0x2

    .line 127
    if-eq v10, v12, :cond_89

    .line 128
    .line 129
    if-eq v10, v11, :cond_87

    .line 130
    .line 131
    :goto_85
    move v8, v5

    .line 132
    goto :goto_8a

    .line 133
    :cond_87
    move v10, p1

    .line 134
    goto :goto_85

    .line 135
    :cond_89
    move v10, p1

    .line 136
    :goto_8a
    iget v3, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 137
    .line 138
    if-eq v3, v12, :cond_93

    .line 139
    .line 140
    if-eq v3, v11, :cond_91

    .line 141
    .line 142
    goto :goto_96

    .line 143
    :cond_91
    move v3, p2

    .line 144
    goto :goto_96

    .line 145
    :cond_93
    move v3, p2

    move v3, p2

    .line 146
    move v5, v9

    .line 147
    :goto_96
    invoke-static {v10, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 148
    .line 149
    .line 150
    move-result v8

    .line 151
    invoke-static {v3, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 152
    .line 153
    .line 154
    move-result v3

    .line 155
    invoke-virtual {v6, v8, v3}, Landroid/view/View;->measure(II)V

    .line 156
    .line 157
    .line 158
    if-eqz v7, :cond_a9

    .line 159
    .line 160
    invoke-virtual {v6}, Landroid/view/View;->getMeasuredHeight()I

    .line 161
    .line 162
    .line 163
    move-result v3

    .line 164
    sub-int/2addr p2, v3

    .line 165
    goto :goto_b0

    .line 166
    :cond_a9
    if-eqz v4, :cond_b0

    .line 167
    .line 168
    invoke-virtual {v6}, Landroid/view/View;->getMeasuredWidth()I

    .line 169
    .line 170
    .line 171
    move-result v3

    .line 172
    sub-int/2addr p1, v3

    .line 173
    :cond_b0
    :goto_b0
    add-int/lit8 v2, v2, 0x1

    .line 174
    .line 175
    goto :goto_37

    .line 176
    :cond_b3
    invoke-static {p1, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 177
    .line 178
    .line 179
    invoke-static {p2, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 180
    .line 181
    .line 182
    move-result p2

    .line 183
    iput p2, p0, Landroidx/viewpager/widget/ViewPager;->s:I

    .line 184
    .line 185
    iput-boolean v4, p0, Landroidx/viewpager/widget/ViewPager;->t:Z

    .line 186
    .line 187
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 188
    .line 189
    .line 190
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->t:Z

    .line 191
    .line 192
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 193
    .line 194
    .line 195
    move-result p2

    .line 196
    :goto_c7
    if-ge v0, p2, :cond_f0

    .line 197
    .line 198
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    if-eq v2, v3, :cond_ed

    .line 207
    .line 208
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 209
    .line 210
    .line 211
    move-result-object v2

    .line 212
    check-cast v2, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 213
    .line 214
    if-eqz v2, :cond_df

    .line 215
    .line 216
    iget-boolean v4, v2, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 217
    .line 218
    if-nez v4, :cond_ed

    .line 219
    .line 220
    :cond_df
    int-to-float v4, p1

    .line 221
    iget v2, v2, Landroidx/viewpager/widget/ViewPager$LayoutParams;->c:F

    .line 222
    .line 223
    mul-float/2addr v4, v2

    .line 224
    float-to-int v2, v4

    .line 225
    invoke-static {v2, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->s:I

    .line 230
    .line 231
    invoke-virtual {v1, v2, v4}, Landroid/view/View;->measure(II)V

    .line 232
    .line 233
    .line 234
    :cond_ed
    add-int/lit8 v0, v0, 0x1

    .line 235
    .line 236
    goto :goto_c7

    .line 237
    :cond_f0
    return-void
.end method

.method public final onRequestFocusInDescendants(ILandroid/graphics/Rect;)Z
    .locals 9

    .line 1
    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    and-int/lit8 v1, p1, 0x2

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    if-eqz v1, :cond_12

    .line 10
    .line 11
    const/4 v8, 0x6

    move v1, v0

    .line 12
    move v0, v2

    move v0, v2

    .line 13
    move v4, v3

    .line 14
    const/4 v8, 0x7

    goto :goto_17

    .line 15
    :cond_12
    add-int/lit8 v0, v0, -0x1

    .line 16
    .line 17
    const/4 v1, -0x1

    .line 18
    const/4 v8, 0x0

    move v4, v1

    .line 19
    :goto_17
    const/4 v8, 0x7

    if-eq v0, v1, :cond_3b

    .line 20
    .line 21
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    const/4 v8, 0x4

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    if-nez v6, :cond_39

    .line 30
    .line 31
    invoke-virtual {p0, v5}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 32
    .line 33
    .line 34
    move-result-object v6

    .line 35
    if-eqz v6, :cond_39

    .line 36
    .line 37
    const/4 v8, 0x2

    iget v6, v6, Lx5h;->b:I

    .line 38
    .line 39
    iget v7, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 40
    .line 41
    if-ne v6, v7, :cond_39

    .line 42
    .line 43
    invoke-virtual {v5, p1, p2}, Landroid/view/View;->requestFocus(ILandroid/graphics/Rect;)Z

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    if-eqz v5, :cond_39

    .line 48
    .line 49
    return v3

    .line 50
    :cond_39
    add-int/2addr v0, v4

    .line 51
    goto :goto_17

    .line 52
    :cond_3b
    return v2
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 4

    .line 1
    instance-of v0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;

    .line 2
    .line 3
    if-nez v0, :cond_9

    .line 4
    .line 5
    const/4 v3, 0x1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_9
    check-cast p1, Landroidx/viewpager/widget/ViewPager$SavedState;

    .line 10
    .line 11
    iget-object v0, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->e:Ljava/lang/ClassLoader;

    .line 12
    .line 13
    iget-object v1, p1, Landroidx/customview/view/AbsSavedState;->a:Landroid/os/Parcelable;

    .line 14
    .line 15
    invoke-super {p0, v1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 19
    .line 20
    if-eqz v1, :cond_25

    .line 21
    .line 22
    iget-object v2, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->d:Landroid/os/Parcelable;

    .line 23
    .line 24
    const/4 v3, 0x4

    invoke-virtual {v1, v2, v0}, Lnfb;->g(Landroid/os/Parcelable;Ljava/lang/ClassLoader;)V

    .line 25
    .line 26
    .line 27
    iget p1, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->c:I

    .line 28
    .line 29
    const/4 v3, 0x4

    const/4 v0, 0x1

    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-virtual {p0, p1, v1, v1, v0}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_25
    iget v1, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->c:I

    .line 36
    .line 37
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->g:I

    .line 38
    .line 39
    iget-object p1, p1, Landroidx/viewpager/widget/ViewPager$SavedState;->d:Landroid/os/Parcelable;

    .line 40
    .line 41
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->h:Landroid/os/Parcelable;

    .line 42
    .line 43
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->i:Ljava/lang/ClassLoader;

    .line 44
    .line 45
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 3

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v2, 0x7

    new-instance v1, Landroidx/viewpager/widget/ViewPager$SavedState;

    .line 6
    .line 7
    const/4 v2, 0x3

    invoke-direct {v1, v0}, Landroidx/customview/view/AbsSavedState;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x5

    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 11
    .line 12
    iput v0, v1, Landroidx/viewpager/widget/ViewPager$SavedState;->c:I

    .line 13
    .line 14
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 15
    .line 16
    const/4 v2, 0x2

    if-eqz p0, :cond_1d

    .line 17
    .line 18
    const/4 v2, 0x0

    invoke-virtual {p0}, Lnfb;->h()Landroid/os/Parcelable;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    const/4 v2, 0x7

    iput-object p0, v1, Landroidx/viewpager/widget/ViewPager$SavedState;->d:Landroid/os/Parcelable;

    .line 23
    .line 24
    :cond_1d
    return-object v1
.end method

.method public final onSizeChanged(IIII)V
    .locals 1

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->onSizeChanged(IIII)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    if-eq p1, p3, :cond_c

    .line 5
    .line 6
    iget p2, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 7
    .line 8
    const/4 v0, 0x4

    invoke-virtual {p0, p1, p3, p2, p2}, Landroidx/viewpager/widget/ViewPager;->r(IIII)V

    .line 9
    .line 10
    .line 11
    :cond_c
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 9

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_f

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getEdgeFlags()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_f

    .line 13
    .line 14
    goto/16 :goto_1d3

    .line 15
    .line 16
    :cond_f
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 17
    .line 18
    if-eqz v0, :cond_1d3

    .line 19
    .line 20
    invoke-virtual {v0}, Lnfb;->c()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/4 v8, 0x4

    if-nez v0, :cond_1d

    .line 25
    .line 26
    const/4 v8, 0x7

    goto/16 :goto_1d3

    .line 27
    .line 28
    :cond_1d
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 29
    .line 30
    const/4 v8, 0x4

    if-nez v0, :cond_29

    .line 31
    .line 32
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    const/4 v8, 0x4

    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 37
    .line 38
    :cond_29
    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 39
    .line 40
    .line 41
    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    const/4 v8, 0x3

    and-int/lit16 v0, v0, 0xff

    .line 46
    .line 47
    const/4 v2, 0x1

    .line 48
    const/4 v8, 0x6

    if-eqz v0, :cond_1a5

    .line 49
    .line 50
    const/4 v8, 0x6

    if-eq v0, v2, :cond_106

    .line 51
    .line 52
    const/4 v3, 0x2

    .line 53
    if-eq v0, v3, :cond_82

    .line 54
    .line 55
    const/4 v3, 0x3

    .line 56
    const/4 v8, 0x5

    if-eq v0, v3, :cond_71

    .line 57
    .line 58
    const/4 v3, 0x5

    .line 59
    if-eq v0, v3, :cond_5e

    .line 60
    .line 61
    const/4 v3, 0x6

    .line 62
    if-eq v0, v3, :cond_4b

    .line 63
    .line 64
    const/4 v8, 0x7

    goto/16 :goto_1c8

    .line 65
    .line 66
    :cond_4b
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->l(Landroid/view/MotionEvent;)V

    .line 67
    .line 68
    .line 69
    const/4 v8, 0x1

    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 70
    .line 71
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 80
    .line 81
    goto/16 :goto_1c8

    .line 82
    .line 83
    :cond_5e
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    const/4 v8, 0x1

    iput v3, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 92
    .line 93
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 98
    .line 99
    goto/16 :goto_1c8

    .line 100
    .line 101
    :cond_71
    const/4 v8, 0x0

    iget-boolean p1, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 102
    .line 103
    if-eqz p1, :cond_1c8

    .line 104
    .line 105
    iget p1, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 106
    .line 107
    const/4 v8, 0x3

    invoke-virtual {p0, p1, v1, v2, v1}, Landroidx/viewpager/widget/ViewPager;->t(IIZZ)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->s()Z

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    goto/16 :goto_1c8

    .line 115
    .line 116
    :cond_82
    const/4 v8, 0x5

    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 117
    .line 118
    if-nez v0, :cond_f0

    .line 119
    .line 120
    const/4 v8, 0x3

    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 121
    .line 122
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    const/4 v8, 0x7

    const/4 v3, -0x1

    .line 127
    if-ne v0, v3, :cond_99

    .line 128
    .line 129
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->s()Z

    .line 130
    .line 131
    .line 132
    move-result v1

    .line 133
    const/4 v8, 0x5

    goto/16 :goto_1c8

    .line 134
    .line 135
    :cond_99
    const/4 v8, 0x2

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 140
    .line 141
    const/4 v8, 0x4

    sub-float v4, v3, v4

    .line 142
    .line 143
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    .line 144
    .line 145
    .line 146
    move-result v4

    .line 147
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    const/4 v8, 0x0

    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->D:F

    .line 152
    .line 153
    sub-float v5, v0, v5

    .line 154
    .line 155
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 156
    .line 157
    .line 158
    move-result v5

    .line 159
    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->B:I

    .line 160
    .line 161
    int-to-float v7, v6

    .line 162
    cmpl-float v7, v4, v7

    .line 163
    .line 164
    if-lez v7, :cond_f0

    .line 165
    .line 166
    cmpl-float v4, v4, v5

    .line 167
    .line 168
    if-lez v4, :cond_f0

    .line 169
    .line 170
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 171
    .line 172
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 173
    .line 174
    .line 175
    move-result-object v4

    .line 176
    const/4 v8, 0x4

    if-eqz v4, :cond_cb

    .line 177
    .line 178
    invoke-interface {v4, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 179
    .line 180
    .line 181
    :cond_cb
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->E:F

    .line 182
    .line 183
    sub-float/2addr v3, v4

    .line 184
    const/4 v5, 0x0

    .line 185
    const/4 v8, 0x1

    cmpl-float v3, v3, v5

    .line 186
    .line 187
    if-lez v3, :cond_d8

    .line 188
    .line 189
    int-to-float v3, v6

    .line 190
    const/4 v8, 0x3

    add-float/2addr v4, v3

    .line 191
    goto :goto_da

    .line 192
    :cond_d8
    int-to-float v3, v6

    .line 193
    sub-float/2addr v4, v3

    .line 194
    :goto_da
    const/4 v8, 0x4

    iput v4, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 195
    .line 196
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->D:F

    .line 197
    .line 198
    invoke-virtual {p0, v2}, Landroidx/viewpager/widget/ViewPager;->setScrollState(I)V

    .line 199
    .line 200
    .line 201
    const/4 v8, 0x7

    invoke-direct {p0, v2}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    const/4 v8, 0x7

    if-eqz v0, :cond_f0

    .line 209
    .line 210
    invoke-interface {v0, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 211
    .line 212
    .line 213
    :cond_f0
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 214
    .line 215
    if-eqz v0, :cond_1c8

    .line 216
    .line 217
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 218
    .line 219
    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 224
    .line 225
    .line 226
    move-result p1

    .line 227
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->o(F)Z

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    const/4 v8, 0x7

    goto/16 :goto_1c8

    .line 232
    .line 233
    :cond_106
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 234
    .line 235
    if-eqz v0, :cond_1c8

    .line 236
    .line 237
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 238
    .line 239
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->J:I

    .line 240
    .line 241
    int-to-float v3, v3

    .line 242
    const/16 v4, 0x3e8

    .line 243
    .line 244
    const/4 v8, 0x2

    invoke-virtual {v0, v4, v3}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 245
    .line 246
    .line 247
    const/4 v8, 0x3

    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 248
    .line 249
    invoke-virtual {v0, v3}, Landroid/view/VelocityTracker;->getXVelocity(I)F

    .line 250
    .line 251
    .line 252
    move-result v0

    .line 253
    float-to-int v0, v0

    .line 254
    iput-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 255
    .line 256
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 257
    .line 258
    .line 259
    move-result v3

    .line 260
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 261
    .line 262
    .line 263
    move-result v4

    .line 264
    const/4 v8, 0x6

    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->i()Lx5h;

    .line 265
    .line 266
    .line 267
    move-result-object v5

    .line 268
    const/4 v8, 0x4

    iget v6, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 269
    .line 270
    int-to-float v6, v6

    .line 271
    const/4 v8, 0x1

    int-to-float v3, v3

    .line 272
    div-float/2addr v6, v3

    .line 273
    iget v7, v5, Lx5h;->b:I

    .line 274
    .line 275
    int-to-float v4, v4

    .line 276
    div-float/2addr v4, v3

    .line 277
    const/4 v8, 0x5

    iget v3, v5, Lx5h;->e:F

    .line 278
    .line 279
    sub-float/2addr v4, v3

    .line 280
    iget v3, v5, Lx5h;->d:F

    .line 281
    .line 282
    add-float/2addr v3, v6

    .line 283
    div-float/2addr v4, v3

    .line 284
    const/4 v8, 0x3

    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 285
    .line 286
    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 287
    .line 288
    .line 289
    move-result v3

    .line 290
    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->getX(I)F

    .line 291
    .line 292
    .line 293
    move-result p1

    .line 294
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->E:F

    .line 295
    .line 296
    sub-float/2addr p1, v3

    .line 297
    float-to-int p1, p1

    .line 298
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    .line 299
    .line 300
    .line 301
    move-result p1

    .line 302
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->K:I

    .line 303
    .line 304
    if-le p1, v3, :cond_167

    .line 305
    .line 306
    const/4 v8, 0x3

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 307
    .line 308
    .line 309
    move-result p1

    .line 310
    const/4 v8, 0x3

    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->I:I

    .line 311
    .line 312
    if-le p1, v3, :cond_167

    .line 313
    .line 314
    if-lez v0, :cond_163

    .line 315
    .line 316
    goto :goto_177

    .line 317
    :cond_163
    const/4 v8, 0x6

    add-int/lit8 v7, v7, 0x1

    .line 318
    .line 319
    goto :goto_177

    .line 320
    :cond_167
    iget p1, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 321
    .line 322
    const/4 v8, 0x6

    if-lt v7, p1, :cond_171

    .line 323
    .line 324
    const/4 v8, 0x7

    const p1, 0x3ecccccd    # 0.4f

    .line 325
    .line 326
    .line 327
    goto :goto_174

    .line 328
    :cond_171
    const p1, 0x3f19999a    # 0.6f

    .line 329
    .line 330
    .line 331
    :goto_174
    add-float/2addr v4, p1

    .line 332
    float-to-int p1, v4

    .line 333
    add-int/2addr v7, p1

    .line 334
    :goto_177
    const/4 v8, 0x2

    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 335
    .line 336
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 337
    .line 338
    .line 339
    move-result v3

    .line 340
    if-lez v3, :cond_19b

    .line 341
    .line 342
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    check-cast v1, Lx5h;

    .line 347
    .line 348
    const/4 v8, 0x5

    invoke-static {p1, v2}, Lhvb;->t(Ljava/util/ArrayList;I)Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    move-result-object p1

    .line 352
    check-cast p1, Lx5h;

    .line 353
    .line 354
    const/4 v8, 0x2

    iget v1, v1, Lx5h;->b:I

    .line 355
    .line 356
    iget p1, p1, Lx5h;->b:I

    .line 357
    .line 358
    invoke-static {v7, p1}, Ljava/lang/Math;->min(II)I

    .line 359
    .line 360
    .line 361
    move-result p1

    .line 362
    const/4 v8, 0x0

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    .line 363
    .line 364
    .line 365
    move-result v7

    .line 366
    :cond_19b
    const/4 v8, 0x3

    invoke-virtual {p0, v7, v0, v2, v2}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->s()Z

    .line 370
    .line 371
    .line 372
    move-result v1

    .line 373
    const/4 v8, 0x3

    goto :goto_1c8

    .line 374
    :cond_1a5
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 375
    .line 376
    const/4 v8, 0x1

    invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V

    .line 377
    .line 378
    .line 379
    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 380
    .line 381
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 382
    .line 383
    .line 384
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 385
    .line 386
    .line 387
    move-result v0

    .line 388
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->E:F

    .line 389
    .line 390
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->C:F

    .line 391
    .line 392
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 393
    .line 394
    .line 395
    move-result v0

    .line 396
    const/4 v8, 0x1

    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->F:F

    .line 397
    .line 398
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->D:F

    .line 399
    .line 400
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 401
    .line 402
    .line 403
    move-result p1

    .line 404
    const/4 v8, 0x6

    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 405
    .line 406
    :cond_1c8
    :goto_1c8
    const/4 v8, 0x7

    if-eqz v1, :cond_1d2

    .line 407
    .line 408
    const/4 v8, 0x1

    sget-object p1, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 409
    .line 410
    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 411
    .line 412
    .line 413
    :cond_1d2
    return v2

    .line 414
    :cond_1d3
    :goto_1d3
    const/4 v8, 0x7

    return v1
.end method

.method public final p()V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->q(I)V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x4

    return-void
.end method

.method public final q(I)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 6
    .line 7
    if-eq v2, v1, :cond_11

    .line 8
    .line 9
    invoke-virtual {v0, v2}, Landroidx/viewpager/widget/ViewPager;->j(I)Lx5h;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    iput v1, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 14
    .line 15
    goto :goto_12

    .line 16
    :cond_11
    const/4 v2, 0x0

    .line 17
    :goto_12
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 18
    .line 19
    if-nez v1, :cond_1a

    .line 20
    .line 21
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->w()V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_1a
    iget-boolean v1, v0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 26
    .line 27
    if-eqz v1, :cond_22

    .line 28
    .line 29
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->w()V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_22
    invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    if-nez v1, :cond_2a

    .line 38
    .line 39
    goto/16 :goto_32b

    .line 40
    .line 41
    :cond_2a
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 42
    .line 43
    invoke-virtual {v1, v0}, Lnfb;->k(Landroidx/viewpager/widget/ViewPager;)V

    .line 44
    .line 45
    .line 46
    iget v1, v0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 47
    .line 48
    iget v4, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 49
    .line 50
    sub-int/2addr v4, v1

    .line 51
    const/4 v5, 0x0

    .line 52
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    .line 53
    .line 54
    .line 55
    move-result v4

    .line 56
    iget-object v6, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 57
    .line 58
    invoke-virtual {v6}, Lnfb;->c()I

    .line 59
    .line 60
    .line 61
    move-result v6

    .line 62
    add-int/lit8 v7, v6, -0x1

    .line 63
    .line 64
    iget v8, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 65
    .line 66
    add-int/2addr v8, v1

    .line 67
    invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    iget v7, v0, Landroidx/viewpager/widget/ViewPager;->a:I

    .line 72
    .line 73
    if-ne v6, v7, :cond_32c

    .line 74
    .line 75
    move v7, v5

    .line 76
    :goto_4d
    iget-object v8, v0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 77
    .line 78
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 79
    .line 80
    .line 81
    move-result v9

    .line 82
    if-ge v7, v9, :cond_67

    .line 83
    .line 84
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v9

    .line 88
    check-cast v9, Lx5h;

    .line 89
    .line 90
    iget v10, v9, Lx5h;->b:I

    .line 91
    .line 92
    iget v11, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 93
    .line 94
    if-lt v10, v11, :cond_64

    .line 95
    .line 96
    if-ne v10, v11, :cond_67

    .line 97
    .line 98
    goto :goto_68

    .line 99
    :cond_64
    add-int/lit8 v7, v7, 0x1

    .line 100
    .line 101
    goto :goto_4d

    .line 102
    :cond_67
    const/4 v9, 0x0

    .line 103
    :goto_68
    if-nez v9, :cond_72

    .line 104
    .line 105
    if-lez v6, :cond_72

    .line 106
    .line 107
    iget v9, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 108
    .line 109
    invoke-virtual {v0, v9, v7}, Landroidx/viewpager/widget/ViewPager;->a(II)Lx5h;

    .line 110
    .line 111
    .line 112
    move-result-object v9

    .line 113
    :cond_72
    if-eqz v9, :cond_2a6

    .line 114
    .line 115
    add-int/lit8 v11, v7, -0x1

    .line 116
    .line 117
    if-ltz v11, :cond_7f

    .line 118
    .line 119
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v12

    .line 123
    check-cast v12, Lx5h;

    .line 124
    .line 125
    goto :goto_80

    .line 126
    :cond_7f
    const/4 v12, 0x0

    .line 127
    :goto_80
    invoke-direct {v0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 128
    .line 129
    .line 130
    move-result v13

    .line 131
    const/high16 v14, 0x40000000    # 2.0f

    .line 132
    .line 133
    if-gtz v13, :cond_8a

    .line 134
    .line 135
    const/4 v3, 0x0

    .line 136
    goto :goto_96

    .line 137
    :cond_8a
    iget v15, v9, Lx5h;->d:F

    .line 138
    .line 139
    sub-float v15, v14, v15

    .line 140
    .line 141
    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    .line 142
    .line 143
    .line 144
    move-result v3

    .line 145
    int-to-float v3, v3

    .line 146
    int-to-float v5, v13

    .line 147
    div-float/2addr v3, v5

    .line 148
    add-float/2addr v3, v15

    .line 149
    :goto_96
    iget v5, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 150
    .line 151
    add-int/lit8 v5, v5, -0x1

    .line 152
    .line 153
    const/4 v15, 0x0

    .line 154
    :goto_9b
    if-ltz v5, :cond_a5

    .line 155
    .line 156
    cmpl-float v16, v15, v3

    .line 157
    .line 158
    if-ltz v16, :cond_cc

    .line 159
    .line 160
    if-ge v5, v4, :cond_cc

    .line 161
    .line 162
    if-nez v12, :cond_a8

    .line 163
    .line 164
    :cond_a5
    const/16 v16, 0x0

    .line 165
    .line 166
    goto :goto_f9

    .line 167
    :cond_a8
    const/16 v16, 0x0

    .line 168
    .line 169
    iget v10, v12, Lx5h;->b:I

    .line 170
    .line 171
    if-ne v5, v10, :cond_f6

    .line 172
    .line 173
    iget-boolean v10, v12, Lx5h;->c:Z

    .line 174
    .line 175
    if-nez v10, :cond_f6

    .line 176
    .line 177
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    iget-object v10, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 181
    .line 182
    iget-object v12, v12, Lx5h;->a:Ljava/lang/Object;

    .line 183
    .line 184
    invoke-virtual {v10, v5, v12}, Lnfb;->a(ILjava/lang/Object;)V

    .line 185
    .line 186
    .line 187
    add-int/lit8 v11, v11, -0x1

    .line 188
    .line 189
    add-int/lit8 v7, v7, -0x1

    .line 190
    .line 191
    if-ltz v11, :cond_c9

    .line 192
    .line 193
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v10

    .line 197
    check-cast v10, Lx5h;

    .line 198
    .line 199
    goto :goto_ca

    .line 200
    :cond_c9
    const/4 v10, 0x0

    .line 201
    :goto_ca
    move-object v12, v10

    .line 202
    goto :goto_f6

    .line 203
    :cond_cc
    const/16 v16, 0x0

    .line 204
    .line 205
    if-eqz v12, :cond_e2

    .line 206
    .line 207
    iget v10, v12, Lx5h;->b:I

    .line 208
    .line 209
    if-ne v5, v10, :cond_e2

    .line 210
    .line 211
    iget v10, v12, Lx5h;->d:F

    .line 212
    .line 213
    add-float/2addr v15, v10

    .line 214
    add-int/lit8 v11, v11, -0x1

    .line 215
    .line 216
    if-ltz v11, :cond_c9

    .line 217
    .line 218
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v10

    .line 222
    check-cast v10, Lx5h;

    .line 223
    .line 224
    goto :goto_ca

    .line 225
    :cond_e2
    add-int/lit8 v10, v11, 0x1

    .line 226
    .line 227
    invoke-virtual {v0, v5, v10}, Landroidx/viewpager/widget/ViewPager;->a(II)Lx5h;

    .line 228
    .line 229
    .line 230
    move-result-object v10

    .line 231
    iget v10, v10, Lx5h;->d:F

    .line 232
    .line 233
    add-float/2addr v15, v10

    .line 234
    add-int/lit8 v7, v7, 0x1

    .line 235
    .line 236
    if-ltz v11, :cond_c9

    .line 237
    .line 238
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v10

    .line 242
    check-cast v10, Lx5h;

    .line 243
    .line 244
    goto :goto_ca

    .line 245
    :cond_f6
    :goto_f6
    add-int/lit8 v5, v5, -0x1

    .line 246
    .line 247
    goto :goto_9b

    .line 248
    :goto_f9
    iget v3, v9, Lx5h;->d:F

    .line 249
    .line 250
    add-int/lit8 v4, v7, 0x1

    .line 251
    .line 252
    cmpg-float v5, v3, v14

    .line 253
    .line 254
    if-gez v5, :cond_17e

    .line 255
    .line 256
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 257
    .line 258
    .line 259
    move-result v5

    .line 260
    if-ge v4, v5, :cond_10e

    .line 261
    .line 262
    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v5

    .line 266
    check-cast v5, Lx5h;

    .line 267
    .line 268
    goto :goto_10f

    .line 269
    :cond_10e
    const/4 v5, 0x0

    .line 270
    :goto_10f
    if-gtz v13, :cond_114

    .line 271
    .line 272
    move/from16 v10, v16

    .line 273
    .line 274
    goto :goto_11c

    .line 275
    :cond_114
    invoke-virtual {v0}, Landroid/view/View;->getPaddingRight()I

    .line 276
    .line 277
    .line 278
    move-result v10

    .line 279
    int-to-float v10, v10

    .line 280
    int-to-float v11, v13

    .line 281
    div-float/2addr v10, v11

    .line 282
    add-float/2addr v10, v14

    .line 283
    :goto_11c
    iget v11, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 284
    .line 285
    add-int/lit8 v11, v11, 0x1

    .line 286
    .line 287
    move v12, v4

    move v12, v4

    .line 288
    :goto_122
    if-ge v11, v6, :cond_17e

    .line 289
    .line 290
    cmpl-float v13, v3, v10

    .line 291
    .line 292
    if-ltz v13, :cond_14e

    .line 293
    .line 294
    if-le v11, v1, :cond_14e

    .line 295
    .line 296
    if-nez v5, :cond_12d

    .line 297
    .line 298
    goto :goto_17e

    .line 299
    :cond_12d
    iget v13, v5, Lx5h;->b:I

    .line 300
    .line 301
    if-ne v11, v13, :cond_17b

    .line 302
    .line 303
    iget-boolean v13, v5, Lx5h;->c:Z

    .line 304
    .line 305
    if-nez v13, :cond_17b

    .line 306
    .line 307
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    iget-object v13, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 311
    .line 312
    iget-object v5, v5, Lx5h;->a:Ljava/lang/Object;

    .line 313
    .line 314
    invoke-virtual {v13, v11, v5}, Lnfb;->a(ILjava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 318
    .line 319
    .line 320
    move-result v5

    .line 321
    if-ge v12, v5, :cond_14c

    .line 322
    .line 323
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object v5

    .line 327
    check-cast v5, Lx5h;

    .line 328
    .line 329
    goto :goto_17b

    .line 330
    :cond_14c
    const/4 v5, 0x0

    .line 331
    goto :goto_17b

    .line 332
    :cond_14e
    if-eqz v5, :cond_166

    .line 333
    .line 334
    iget v13, v5, Lx5h;->b:I

    .line 335
    .line 336
    if-ne v11, v13, :cond_166

    .line 337
    .line 338
    iget v5, v5, Lx5h;->d:F

    .line 339
    .line 340
    add-float/2addr v3, v5

    .line 341
    add-int/lit8 v12, v12, 0x1

    .line 342
    .line 343
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 344
    .line 345
    .line 346
    move-result v5

    .line 347
    if-ge v12, v5, :cond_14c

    .line 348
    .line 349
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v5

    .line 353
    check-cast v5, Lx5h;

    .line 354
    .line 355
    goto :goto_17b

    .line 356
    :cond_166
    invoke-virtual {v0, v11, v12}, Landroidx/viewpager/widget/ViewPager;->a(II)Lx5h;

    .line 357
    .line 358
    .line 359
    move-result-object v5

    .line 360
    add-int/lit8 v12, v12, 0x1

    .line 361
    .line 362
    iget v5, v5, Lx5h;->d:F

    .line 363
    .line 364
    add-float/2addr v3, v5

    .line 365
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 366
    .line 367
    .line 368
    move-result v5

    .line 369
    if-ge v12, v5, :cond_14c

    .line 370
    .line 371
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    move-result-object v5

    .line 375
    check-cast v5, Lx5h;

    .line 376
    .line 377
    :cond_17b
    :goto_17b
    add-int/lit8 v11, v11, 0x1

    .line 378
    .line 379
    goto :goto_122

    .line 380
    :cond_17e
    :goto_17e
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 381
    .line 382
    invoke-virtual {v1}, Lnfb;->c()I

    .line 383
    .line 384
    .line 385
    move-result v1

    .line 386
    invoke-direct {v0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 387
    .line 388
    .line 389
    move-result v3

    .line 390
    if-lez v3, :cond_190

    .line 391
    .line 392
    iget v5, v0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 393
    .line 394
    int-to-float v5, v5

    .line 395
    int-to-float v3, v3

    .line 396
    div-float/2addr v5, v3

    .line 397
    goto :goto_192

    .line 398
    :cond_190
    move/from16 v5, v16

    .line 399
    .line 400
    :goto_192
    const/high16 v3, 0x3f800000    # 1.0f

    .line 401
    .line 402
    if-eqz v2, :cond_221

    .line 403
    .line 404
    iget v6, v2, Lx5h;->b:I

    .line 405
    .line 406
    iget v10, v9, Lx5h;->b:I

    .line 407
    .line 408
    if-ge v6, v10, :cond_1e2

    .line 409
    .line 410
    iget v10, v2, Lx5h;->e:F

    .line 411
    .line 412
    iget v2, v2, Lx5h;->d:F

    .line 413
    .line 414
    add-float/2addr v10, v2

    .line 415
    add-float/2addr v10, v5

    .line 416
    add-int/lit8 v6, v6, 0x1

    .line 417
    .line 418
    const/4 v2, 0x0

    .line 419
    :goto_1a5
    iget v11, v9, Lx5h;->b:I

    .line 420
    .line 421
    if-gt v6, v11, :cond_221

    .line 422
    .line 423
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 424
    .line 425
    .line 426
    move-result v11

    .line 427
    if-ge v2, v11, :cond_221

    .line 428
    .line 429
    invoke-virtual {v8, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v11

    .line 433
    check-cast v11, Lx5h;

    .line 434
    .line 435
    :goto_1b5
    iget v12, v11, Lx5h;->b:I

    .line 436
    .line 437
    if-le v6, v12, :cond_1ca

    .line 438
    .line 439
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 440
    .line 441
    .line 442
    move-result v12

    .line 443
    add-int/lit8 v12, v12, -0x1

    .line 444
    .line 445
    if-ge v2, v12, :cond_1ca

    .line 446
    .line 447
    add-int/lit8 v2, v2, 0x1

    .line 448
    .line 449
    invoke-virtual {v8, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 450
    .line 451
    .line 452
    move-result-object v11

    .line 453
    check-cast v11, Lx5h;

    .line 454
    .line 455
    goto :goto_1b5

    .line 456
    :cond_1ca
    :goto_1ca
    iget v12, v11, Lx5h;->b:I

    .line 457
    .line 458
    if-ge v6, v12, :cond_1d9

    .line 459
    .line 460
    iget-object v12, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 461
    .line 462
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 463
    .line 464
    .line 465
    add-float v12, v3, v5

    .line 466
    .line 467
    add-float/2addr v10, v12

    .line 468
    add-int/lit8 v6, v6, 0x1

    .line 469
    .line 470
    goto :goto_1ca

    .line 471
    :cond_1d9
    iput v10, v11, Lx5h;->e:F

    .line 472
    .line 473
    iget v11, v11, Lx5h;->d:F

    .line 474
    .line 475
    add-float/2addr v11, v5

    .line 476
    add-float/2addr v10, v11

    .line 477
    add-int/lit8 v6, v6, 0x1

    .line 478
    .line 479
    goto :goto_1a5

    .line 480
    :cond_1e2
    if-le v6, v10, :cond_221

    .line 481
    .line 482
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 483
    .line 484
    .line 485
    move-result v10

    .line 486
    add-int/lit8 v10, v10, -0x1

    .line 487
    .line 488
    iget v2, v2, Lx5h;->e:F

    .line 489
    .line 490
    add-int/lit8 v6, v6, -0x1

    .line 491
    .line 492
    :goto_1ee
    iget v11, v9, Lx5h;->b:I

    .line 493
    .line 494
    if-lt v6, v11, :cond_221

    .line 495
    .line 496
    if-ltz v10, :cond_221

    .line 497
    .line 498
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 499
    .line 500
    .line 501
    move-result-object v11

    .line 502
    check-cast v11, Lx5h;

    .line 503
    .line 504
    :goto_1fa
    iget v12, v11, Lx5h;->b:I

    .line 505
    .line 506
    if-ge v6, v12, :cond_209

    .line 507
    .line 508
    if-lez v10, :cond_209

    .line 509
    .line 510
    add-int/lit8 v10, v10, -0x1

    .line 511
    .line 512
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object v11

    .line 516
    check-cast v11, Lx5h;

    .line 517
    .line 518
    goto :goto_1fa

    .line 519
    :cond_209
    :goto_209
    iget v12, v11, Lx5h;->b:I

    .line 520
    .line 521
    if-le v6, v12, :cond_218

    .line 522
    .line 523
    iget-object v12, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 524
    .line 525
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 526
    .line 527
    .line 528
    add-float v12, v3, v5

    .line 529
    .line 530
    sub-float/2addr v2, v12

    .line 531
    add-int/lit8 v6, v6, -0x1

    .line 532
    .line 533
    goto :goto_209

    .line 534
    :cond_218
    iget v12, v11, Lx5h;->d:F

    .line 535
    .line 536
    add-float/2addr v12, v5

    .line 537
    sub-float/2addr v2, v12

    .line 538
    iput v2, v11, Lx5h;->e:F

    .line 539
    .line 540
    add-int/lit8 v6, v6, -0x1

    .line 541
    .line 542
    goto :goto_1ee

    .line 543
    :cond_221
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 544
    .line 545
    .line 546
    move-result v2

    .line 547
    iget v6, v9, Lx5h;->e:F

    .line 548
    .line 549
    iget v10, v9, Lx5h;->b:I

    .line 550
    .line 551
    add-int/lit8 v11, v10, -0x1

    .line 552
    .line 553
    if-nez v10, :cond_22f

    .line 554
    .line 555
    move v12, v6

    .line 556
    goto :goto_232

    .line 557
    :cond_22f
    const v12, -0x800001

    .line 558
    .line 559
    .line 560
    :goto_232
    iput v12, v0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 561
    .line 562
    add-int/lit8 v1, v1, -0x1

    .line 563
    .line 564
    if-ne v10, v1, :cond_23d

    .line 565
    .line 566
    iget v10, v9, Lx5h;->d:F

    .line 567
    .line 568
    add-float/2addr v10, v6

    .line 569
    sub-float/2addr v10, v3

    .line 570
    goto :goto_240

    .line 571
    :cond_23d
    const v10, 0x7f7fffff    # Float.MAX_VALUE

    .line 572
    .line 573
    .line 574
    :goto_240
    iput v10, v0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 575
    .line 576
    add-int/lit8 v7, v7, -0x1

    .line 577
    .line 578
    :goto_244
    if-ltz v7, :cond_26a

    .line 579
    .line 580
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 581
    .line 582
    .line 583
    move-result-object v10

    .line 584
    check-cast v10, Lx5h;

    .line 585
    .line 586
    :goto_24c
    iget v12, v10, Lx5h;->b:I

    .line 587
    .line 588
    if-le v11, v12, :cond_25b

    .line 589
    .line 590
    iget-object v12, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 591
    .line 592
    add-int/lit8 v11, v11, -0x1

    .line 593
    .line 594
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 595
    .line 596
    .line 597
    add-float v12, v3, v5

    .line 598
    .line 599
    sub-float/2addr v6, v12

    .line 600
    goto :goto_24c

    .line 601
    :cond_25b
    iget v13, v10, Lx5h;->d:F

    .line 602
    .line 603
    add-float/2addr v13, v5

    .line 604
    sub-float/2addr v6, v13

    .line 605
    iput v6, v10, Lx5h;->e:F

    .line 606
    .line 607
    if-nez v12, :cond_265

    .line 608
    .line 609
    iput v6, v0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 610
    .line 611
    :cond_265
    add-int/lit8 v7, v7, -0x1

    .line 612
    .line 613
    add-int/lit8 v11, v11, -0x1

    .line 614
    .line 615
    goto :goto_244

    .line 616
    :cond_26a
    iget v6, v9, Lx5h;->e:F

    .line 617
    .line 618
    iget v7, v9, Lx5h;->d:F

    .line 619
    .line 620
    add-float/2addr v6, v7

    .line 621
    add-float/2addr v6, v5

    .line 622
    iget v7, v9, Lx5h;->b:I

    .line 623
    .line 624
    :goto_272
    add-int/lit8 v7, v7, 0x1

    .line 625
    .line 626
    if-ge v4, v2, :cond_29c

    .line 627
    .line 628
    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 629
    .line 630
    .line 631
    move-result-object v10

    .line 632
    check-cast v10, Lx5h;

    .line 633
    .line 634
    :goto_27c
    iget v11, v10, Lx5h;->b:I

    .line 635
    .line 636
    if-ge v7, v11, :cond_28b

    .line 637
    .line 638
    iget-object v11, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 639
    .line 640
    add-int/lit8 v7, v7, 0x1

    .line 641
    .line 642
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 643
    .line 644
    .line 645
    add-float v11, v3, v5

    .line 646
    .line 647
    add-float/2addr v6, v11

    .line 648
    goto :goto_27c

    .line 649
    :cond_28b
    if-ne v11, v1, :cond_293

    .line 650
    .line 651
    iget v11, v10, Lx5h;->d:F

    .line 652
    .line 653
    add-float/2addr v11, v6

    .line 654
    sub-float/2addr v11, v3

    .line 655
    iput v11, v0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 656
    .line 657
    :cond_293
    iput v6, v10, Lx5h;->e:F

    .line 658
    .line 659
    iget v10, v10, Lx5h;->d:F

    .line 660
    .line 661
    add-float/2addr v10, v5

    .line 662
    add-float/2addr v6, v10

    .line 663
    add-int/lit8 v4, v4, 0x1

    .line 664
    .line 665
    goto :goto_272

    .line 666
    :cond_29c
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 667
    .line 668
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 669
    .line 670
    iget-object v3, v9, Lx5h;->a:Ljava/lang/Object;

    .line 671
    .line 672
    invoke-virtual {v1, v0, v2, v3}, Lnfb;->i(Landroidx/viewpager/widget/ViewPager;ILjava/lang/Object;)V

    .line 673
    .line 674
    .line 675
    goto :goto_2a8

    .line 676
    :cond_2a6
    const/16 v16, 0x0

    .line 677
    .line 678
    :goto_2a8
    iget-object v1, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 679
    .line 680
    invoke-virtual {v1}, Lnfb;->b()V

    .line 681
    .line 682
    .line 683
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 684
    .line 685
    .line 686
    move-result v1

    .line 687
    const/4 v2, 0x0

    .line 688
    :goto_2b2
    if-ge v2, v1, :cond_2db

    .line 689
    .line 690
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 691
    .line 692
    .line 693
    move-result-object v3

    .line 694
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 695
    .line 696
    .line 697
    move-result-object v4

    .line 698
    check-cast v4, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 699
    .line 700
    iput v2, v4, Landroidx/viewpager/widget/ViewPager$LayoutParams;->f:I

    .line 701
    .line 702
    iget-boolean v5, v4, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 703
    .line 704
    if-nez v5, :cond_2d8

    .line 705
    .line 706
    iget v5, v4, Landroidx/viewpager/widget/ViewPager$LayoutParams;->c:F

    .line 707
    .line 708
    cmpl-float v5, v5, v16

    .line 709
    .line 710
    if-nez v5, :cond_2d8

    .line 711
    .line 712
    invoke-virtual {v0, v3}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 713
    .line 714
    .line 715
    move-result-object v3

    .line 716
    if-eqz v3, :cond_2d8

    .line 717
    .line 718
    iget v5, v3, Lx5h;->d:F

    .line 719
    .line 720
    iput v5, v4, Landroidx/viewpager/widget/ViewPager$LayoutParams;->c:F

    .line 721
    .line 722
    iget v3, v3, Lx5h;->b:I

    .line 723
    .line 724
    iput v3, v4, Landroidx/viewpager/widget/ViewPager$LayoutParams;->e:I

    .line 725
    .line 726
    :cond_2d8
    add-int/lit8 v2, v2, 0x1

    .line 727
    .line 728
    goto :goto_2b2

    .line 729
    :cond_2db
    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->w()V

    .line 730
    .line 731
    .line 732
    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    .line 733
    .line 734
    .line 735
    move-result v1

    .line 736
    if-eqz v1, :cond_32b

    .line 737
    .line 738
    invoke-virtual {v0}, Landroid/view/View;->findFocus()Landroid/view/View;

    .line 739
    .line 740
    .line 741
    move-result-object v1

    .line 742
    if-eqz v1, :cond_300

    .line 743
    .line 744
    :goto_2ea
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 745
    .line 746
    .line 747
    move-result-object v2

    .line 748
    if-eq v2, v0, :cond_2fb

    .line 749
    .line 750
    if-eqz v2, :cond_300

    .line 751
    .line 752
    instance-of v1, v2, Landroid/view/View;

    .line 753
    .line 754
    if-nez v1, :cond_2f7

    .line 755
    .line 756
    goto :goto_300

    .line 757
    :cond_2f7
    move-object v1, v2

    .line 758
    check-cast v1, Landroid/view/View;

    .line 759
    .line 760
    goto :goto_2ea

    .line 761
    :cond_2fb
    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 762
    .line 763
    .line 764
    move-result-object v3

    .line 765
    goto :goto_301

    .line 766
    :cond_300
    :goto_300
    const/4 v3, 0x0

    .line 767
    :goto_301
    if-eqz v3, :cond_309

    .line 768
    .line 769
    iget v1, v3, Lx5h;->b:I

    .line 770
    .line 771
    iget v2, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 772
    .line 773
    if-eq v1, v2, :cond_32b

    .line 774
    .line 775
    :cond_309
    const/4 v5, 0x0

    .line 776
    :goto_30a
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 777
    .line 778
    .line 779
    move-result v1

    .line 780
    if-ge v5, v1, :cond_32b

    .line 781
    .line 782
    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 783
    .line 784
    .line 785
    move-result-object v1

    .line 786
    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->h(Landroid/view/View;)Lx5h;

    .line 787
    .line 788
    .line 789
    move-result-object v2

    .line 790
    if-eqz v2, :cond_328

    .line 791
    .line 792
    iget v2, v2, Lx5h;->b:I

    .line 793
    .line 794
    iget v3, v0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 795
    .line 796
    if-ne v2, v3, :cond_328

    .line 797
    .line 798
    const/4 v2, 0x2

    .line 799
    invoke-virtual {v1, v2}, Landroid/view/View;->requestFocus(I)Z

    .line 800
    .line 801
    .line 802
    move-result v1

    .line 803
    if-eqz v1, :cond_328

    .line 804
    .line 805
    goto :goto_32b

    .line 806
    :cond_328
    add-int/lit8 v5, v5, 0x1

    .line 807
    .line 808
    goto :goto_30a

    .line 809
    :cond_32b
    :goto_32b
    return-void

    .line 810
    :cond_32c
    :try_start_32c
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 811
    .line 812
    .line 813
    move-result-object v1

    .line 814
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 815
    .line 816
    .line 817
    move-result v2

    .line 818
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 819
    .line 820
    .line 821
    move-result-object v1
    :try_end_338
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_32c .. :try_end_338} :catch_339

    .line 822
    goto :goto_341

    .line 823
    :catch_339
    invoke-virtual {v0}, Landroid/view/View;->getId()I

    .line 824
    .line 825
    .line 826
    move-result v1

    .line 827
    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 828
    .line 829
    .line 830
    move-result-object v1

    .line 831
    :goto_341
    new-instance v2, Ljava/lang/StringBuilder;

    .line 832
    .line 833
    const-string v3, "The application\'s PagerAdapter changed the adapter\'s contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: "

    .line 834
    .line 835
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 836
    .line 837
    .line 838
    iget v3, v0, Landroidx/viewpager/widget/ViewPager;->a:I

    .line 839
    .line 840
    const-string v4, ", found: "

    .line 841
    .line 842
    const-string v5, " Pager id: "

    .line 843
    .line 844
    invoke-static {v2, v3, v4, v6, v5}, Ljb3;->M(Ljava/lang/StringBuilder;ILjava/lang/String;ILjava/lang/String;)V

    .line 845
    .line 846
    .line 847
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 848
    .line 849
    .line 850
    const-string v1, " Pager class: "

    .line 851
    .line 852
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 853
    .line 854
    .line 855
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 856
    .line 857
    .line 858
    move-result-object v1

    .line 859
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 860
    .line 861
    .line 862
    const-string v1, " Problematic adapter: "

    .line 863
    .line 864
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 865
    .line 866
    .line 867
    iget-object v0, v0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 868
    .line 869
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 870
    .line 871
    .line 872
    move-result-object v0

    .line 873
    invoke-static {v0, v2}, Lvrh;->f(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    .line 874
    .line 875
    .line 876
    return-void
.end method

.method public final r(IIII)V
    .locals 3

    .line 1
    const/4 v2, 0x2

    if-lez p2, :cond_53

    .line 2
    .line 3
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v2, 0x3

    if-nez v0, :cond_53

    .line 10
    .line 11
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 12
    .line 13
    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_25

    .line 18
    .line 19
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v2, 0x5

    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    const/4 v2, 0x0

    mul-int/2addr p1, p0

    .line 28
    invoke-virtual {v0, p1}, Landroid/widget/Scroller;->setFinalX(I)V

    .line 29
    .line 30
    .line 31
    const/4 v2, 0x6

    return-void

    .line 32
    :cond_25
    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    sub-int/2addr p1, v0

    .line 37
    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    sub-int/2addr p1, v0

    .line 42
    add-int/2addr p1, p3

    .line 43
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 44
    .line 45
    .line 46
    move-result p3

    .line 47
    const/4 v2, 0x0

    sub-int/2addr p2, p3

    .line 48
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 49
    .line 50
    .line 51
    move-result p3

    .line 52
    sub-int/2addr p2, p3

    .line 53
    add-int/2addr p2, p4

    .line 54
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 55
    .line 56
    .line 57
    move-result p3

    .line 58
    int-to-float p3, p3

    .line 59
    const/4 v2, 0x2

    int-to-float p2, p2

    .line 60
    div-float/2addr p3, p2

    .line 61
    int-to-float p1, p1

    .line 62
    const/4 v2, 0x3

    mul-float/2addr p3, p1

    .line 63
    float-to-int p1, p3

    .line 64
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 65
    .line 66
    .line 67
    move-result p2

    .line 68
    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->scrollTo(II)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :cond_53
    iget p2, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 73
    .line 74
    invoke-virtual {p0, p2}, Landroidx/viewpager/widget/ViewPager;->j(I)Lx5h;

    .line 75
    .line 76
    .line 77
    move-result-object p2

    .line 78
    const/4 v2, 0x6

    if-eqz p2, :cond_66

    .line 79
    .line 80
    iget p2, p2, Lx5h;->e:F

    .line 81
    .line 82
    iget p3, p0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 83
    .line 84
    const/4 v2, 0x4

    invoke-static {p2, p3}, Ljava/lang/Math;->min(FF)F

    .line 85
    .line 86
    .line 87
    move-result p2

    .line 88
    goto :goto_67

    .line 89
    :cond_66
    const/4 p2, 0x0

    .line 90
    :goto_67
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 91
    .line 92
    .line 93
    move-result p3

    .line 94
    sub-int/2addr p1, p3

    .line 95
    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 96
    .line 97
    .line 98
    move-result p3

    .line 99
    const/4 v2, 0x1

    sub-int/2addr p1, p3

    .line 100
    int-to-float p1, p1

    .line 101
    mul-float/2addr p2, p1

    .line 102
    float-to-int p1, p2

    .line 103
    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 104
    .line 105
    .line 106
    move-result p2

    .line 107
    if-eq p1, p2, :cond_88

    .line 108
    .line 109
    const/4 p2, 0x0

    .line 110
    invoke-virtual {p0, p2}, Landroidx/viewpager/widget/ViewPager;->d(Z)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 114
    .line 115
    .line 116
    move-result p2

    .line 117
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->scrollTo(II)V

    .line 118
    .line 119
    .line 120
    :cond_88
    return-void
.end method

.method public final removeView(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->t:Z

    .line 2
    .line 3
    const/4 v1, 0x4

    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->removeViewInLayout(Landroid/view/View;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_9
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final s()Z
    .locals 3

    .line 1
    const/4 v2, 0x2

    const/4 v0, -0x1

    .line 2
    iput v0, p0, Landroidx/viewpager/widget/ViewPager;->G:I

    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->x:Z

    .line 6
    .line 7
    const/4 v2, 0x3

    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->y:Z

    .line 8
    .line 9
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 10
    .line 11
    const/4 v2, 0x1

    if-eqz v1, :cond_16

    .line 12
    .line 13
    const/4 v2, 0x5

    invoke-virtual {v1}, Landroid/view/VelocityTracker;->recycle()V

    .line 14
    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->H:Landroid/view/VelocityTracker;

    .line 18
    .line 19
    :cond_16
    const/4 v2, 0x2

    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->M:Landroid/widget/EdgeEffect;

    .line 20
    .line 21
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 22
    .line 23
    .line 24
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->N:Landroid/widget/EdgeEffect;

    .line 25
    .line 26
    invoke-virtual {p0}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    const/4 v2, 0x4

    if-nez v1, :cond_31

    .line 34
    .line 35
    invoke-virtual {p0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    if-eqz p0, :cond_2f

    .line 40
    .line 41
    goto :goto_31

    .line 42
    :cond_2f
    const/4 v2, 0x2

    return v0

    .line 43
    :cond_31
    :goto_31
    const/4 v2, 0x2

    const/4 p0, 0x1

    .line 44
    return p0
.end method

.method public setAdapter(Lnfb;)V
    .locals 9

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 2
    .line 3
    const/4 v8, 0x4

    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 4
    .line 5
    const/4 v2, 0x1

    const/4 v2, 0x0

    .line 6
    const/4 v8, 0x1

    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    const/4 v8, 0x3

    if-eqz v1, :cond_69

    .line 9
    .line 10
    monitor-enter v1

    .line 11
    :try_start_e
    iput-object v2, v1, Lnfb;->b:Landroid/database/DataSetObserver;

    .line 12
    .line 13
    monitor-exit v1
    :try_end_11
    .catchall {:try_start_e .. :try_end_11} :catchall_66

    .line 14
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 15
    .line 16
    invoke-virtual {v1, p0}, Lnfb;->k(Landroidx/viewpager/widget/ViewPager;)V

    .line 17
    .line 18
    .line 19
    const/4 v8, 0x1

    move v1, v4

    .line 20
    :goto_18
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 21
    .line 22
    .line 23
    move-result v5

    .line 24
    const/4 v8, 0x4

    if-ge v1, v5, :cond_34

    .line 25
    .line 26
    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    const/4 v8, 0x4

    check-cast v5, Lx5h;

    .line 31
    .line 32
    const/4 v8, 0x7

    iget-object v6, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 33
    .line 34
    iget v7, v5, Lx5h;->b:I

    .line 35
    .line 36
    iget-object v5, v5, Lx5h;->a:Ljava/lang/Object;

    .line 37
    .line 38
    invoke-virtual {v6, v7, v5}, Lnfb;->a(ILjava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    add-int/lit8 v1, v1, 0x1

    .line 42
    .line 43
    goto :goto_18

    .line 44
    :cond_34
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 45
    .line 46
    const/4 v8, 0x7

    invoke-virtual {v1}, Lnfb;->b()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 50
    .line 51
    .line 52
    move v0, v4

    .line 53
    :goto_3e
    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-ge v0, v1, :cond_5f

    .line 58
    .line 59
    const/4 v8, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    const/4 v8, 0x0

    check-cast v1, Landroidx/viewpager/widget/ViewPager$LayoutParams;

    .line 68
    .line 69
    const/4 v8, 0x1

    iget-boolean v1, v1, Landroidx/viewpager/widget/ViewPager$LayoutParams;->a:Z

    .line 70
    .line 71
    const/4 v8, 0x0

    if-nez v1, :cond_5c

    .line 72
    .line 73
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeViewAt(I)V

    .line 74
    .line 75
    .line 76
    add-int/lit8 v0, v0, -0x1

    .line 77
    .line 78
    :cond_5c
    add-int/2addr v0, v3

    .line 79
    const/4 v8, 0x3

    goto :goto_3e

    .line 80
    :cond_5f
    const/4 v8, 0x2

    iput v4, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 81
    .line 82
    invoke-virtual {p0, v4, v4}, Landroid/view/View;->scrollTo(II)V

    .line 83
    .line 84
    .line 85
    goto :goto_69

    .line 86
    :catchall_66
    move-exception p0

    .line 87
    :try_start_67
    monitor-exit v1
    :try_end_68
    .catchall {:try_start_67 .. :try_end_68} :catchall_66

    .line 88
    throw p0

    .line 89
    :cond_69
    :goto_69
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 90
    .line 91
    const/4 v8, 0x7

    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 92
    .line 93
    const/4 v8, 0x4

    iput v4, p0, Landroidx/viewpager/widget/ViewPager;->a:I

    .line 94
    .line 95
    const/4 v8, 0x3

    if-eqz p1, :cond_c0

    .line 96
    .line 97
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->l:Loe3;

    .line 98
    .line 99
    if-nez v1, :cond_82

    .line 100
    .line 101
    new-instance v1, Loe3;

    .line 102
    .line 103
    const/4 v5, 0x3

    .line 104
    const/4 v8, 0x4

    invoke-direct {v1, p0, v5}, Loe3;-><init>(Ljava/lang/Object;I)V

    .line 105
    .line 106
    .line 107
    const/4 v8, 0x4

    iput-object v1, p0, Landroidx/viewpager/widget/ViewPager;->l:Loe3;

    .line 108
    .line 109
    :cond_82
    iget-object v5, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 110
    .line 111
    invoke-virtual {v5, v1}, Lnfb;->j(Loe3;)V

    .line 112
    .line 113
    .line 114
    const/4 v8, 0x4

    iput-boolean v4, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 115
    .line 116
    iget-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 117
    .line 118
    iput-boolean v3, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 119
    .line 120
    const/4 v8, 0x6

    iget-object v5, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 121
    .line 122
    const/4 v8, 0x3

    invoke-virtual {v5}, Lnfb;->c()I

    .line 123
    .line 124
    .line 125
    move-result v5

    .line 126
    iput v5, p0, Landroidx/viewpager/widget/ViewPager;->a:I

    .line 127
    .line 128
    iget v5, p0, Landroidx/viewpager/widget/ViewPager;->g:I

    .line 129
    .line 130
    if-ltz v5, :cond_b5

    .line 131
    .line 132
    const/4 v8, 0x5

    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 133
    .line 134
    iget-object v5, p0, Landroidx/viewpager/widget/ViewPager;->h:Landroid/os/Parcelable;

    .line 135
    .line 136
    iget-object v6, p0, Landroidx/viewpager/widget/ViewPager;->i:Ljava/lang/ClassLoader;

    .line 137
    .line 138
    invoke-virtual {v1, v5, v6}, Lnfb;->g(Landroid/os/Parcelable;Ljava/lang/ClassLoader;)V

    .line 139
    .line 140
    .line 141
    iget v1, p0, Landroidx/viewpager/widget/ViewPager;->g:I

    .line 142
    .line 143
    invoke-virtual {p0, v1, v4, v4, v3}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 144
    .line 145
    .line 146
    const/4 v8, 0x4

    const/4 v1, -0x1

    .line 147
    iput v1, p0, Landroidx/viewpager/widget/ViewPager;->g:I

    .line 148
    .line 149
    iput-object v2, p0, Landroidx/viewpager/widget/ViewPager;->h:Landroid/os/Parcelable;

    .line 150
    .line 151
    iput-object v2, p0, Landroidx/viewpager/widget/ViewPager;->i:Ljava/lang/ClassLoader;

    .line 152
    .line 153
    const/4 v8, 0x1

    goto :goto_c0

    .line 154
    :cond_b5
    if-nez v1, :cond_bc

    .line 155
    .line 156
    const/4 v8, 0x3

    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 157
    .line 158
    .line 159
    goto :goto_c0

    .line 160
    :cond_bc
    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 161
    .line 162
    .line 163
    :cond_c0
    :goto_c0
    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->U:Ljava/util/ArrayList;

    .line 164
    .line 165
    if-eqz v1, :cond_e4

    .line 166
    .line 167
    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    if-nez v1, :cond_e4

    .line 172
    .line 173
    const/4 v8, 0x0

    iget-object v1, p0, Landroidx/viewpager/widget/ViewPager;->U:Ljava/util/ArrayList;

    .line 174
    .line 175
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 176
    .line 177
    .line 178
    move-result v1

    .line 179
    :goto_d2
    if-ge v4, v1, :cond_e4

    .line 180
    .line 181
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->U:Ljava/util/ArrayList;

    .line 182
    .line 183
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    const/4 v8, 0x4

    check-cast v2, Ly5h;

    .line 188
    .line 189
    invoke-interface {v2, p0, v0, p1}, Ly5h;->a(Landroidx/viewpager/widget/ViewPager;Lnfb;Lnfb;)V

    .line 190
    .line 191
    .line 192
    const/4 v8, 0x2

    add-int/lit8 v4, v4, 0x1

    .line 193
    .line 194
    goto :goto_d2

    .line 195
    :cond_e4
    const/4 v8, 0x2

    return-void
.end method

.method public setCurrentItem(I)V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Landroidx/viewpager/widget/ViewPager;->v:Z

    .line 3
    .line 4
    const/4 v2, 0x2

    iget-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 5
    .line 6
    const/4 v2, 0x0

    xor-int/lit8 v1, v1, 0x1

    .line 7
    .line 8
    invoke-virtual {p0, p1, v0, v1, v0}, Landroidx/viewpager/widget/ViewPager;->u(IIZZ)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setOffscreenPageLimit(I)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    move v4, v0

    .line 2
    if-ge p1, v0, :cond_12

    .line 3
    .line 4
    const/4 v4, 0x3

    const-string v1, "Requested offscreen page limit "

    .line 5
    .line 6
    const/4 v4, 0x2

    const-string v2, "otsttnau  odllm g1 ef l;ioa"

    const-string v2, " too small; defaulting to 1"

    .line 7
    .line 8
    const-string v3, "ViewPager"

    .line 9
    .line 10
    invoke-static {p1, v1, v2, v3}, Lhvb;->E(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    move p1, v0

    .line 14
    :cond_12
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 15
    .line 16
    if-eq p1, v0, :cond_1c

    .line 17
    .line 18
    const/4 v4, 0x3

    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 19
    .line 20
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 21
    .line 22
    .line 23
    :cond_1c
    return-void
.end method

.method public setOnPageChangeListener(Lz5h;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->S:Lz5h;

    .line 2
    .line 3
    const/4 v0, 0x5

    return-void
.end method

.method public setPageMargin(I)V
    .locals 3

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 2
    .line 3
    const/4 v2, 0x7

    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x4

    invoke-virtual {p0, v1, v1, p1, v0}, Landroidx/viewpager/widget/ViewPager;->r(IIII)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public setPageMarginDrawable(I)V
    .locals 2

    .line 20
    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lw63;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->setPageMarginDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setPageMarginDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->n:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    if-eqz p1, :cond_8

    .line 4
    .line 5
    const/4 v0, 0x7

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 6
    .line 7
    .line 8
    :cond_8
    if-nez p1, :cond_d

    .line 9
    .line 10
    const/4 v0, 0x7

    const/4 p1, 0x1

    .line 11
    goto :goto_f

    .line 12
    :cond_d
    const/4 v0, 0x1

    const/4 p1, 0x0

    .line 13
    :goto_f
    invoke-virtual {p0, p1}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public setScrollState(I)V
    .locals 8

    .line 1
    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->d0:I

    .line 2
    .line 3
    if-ne v0, p1, :cond_5

    .line 4
    .line 5
    goto :goto_5f

    .line 6
    :cond_5
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->d0:I

    .line 7
    .line 8
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->V:Lde3;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    if-eqz v0, :cond_30

    .line 12
    .line 13
    if-eqz p1, :cond_10

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    goto :goto_12

    .line 17
    :cond_10
    const/4 v7, 0x0

    move v0, v1

    .line 18
    :goto_12
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    const/4 v7, 0x5

    move v3, v1

    move v3, v1

    .line 23
    :goto_19
    if-ge v3, v2, :cond_30

    .line 24
    .line 25
    if-eqz v0, :cond_21

    .line 26
    .line 27
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 28
    .line 29
    const/4 v7, 0x3

    goto :goto_22

    .line 30
    :cond_21
    move v4, v1

    .line 31
    :goto_22
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    const/4 v7, 0x1

    const/4 v6, 0x0

    .line 36
    const/4 v7, 0x0

    invoke-virtual {v5, v4, v6}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    .line 37
    .line 38
    .line 39
    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    .line 40
    .line 41
    goto :goto_19

    .line 42
    :cond_30
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->S:Lz5h;

    .line 43
    .line 44
    if-eqz v0, :cond_37

    .line 45
    .line 46
    invoke-interface {v0, p1}, Lz5h;->c(I)V

    .line 47
    .line 48
    .line 49
    :cond_37
    const/4 v7, 0x4

    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->R:Ljava/util/ArrayList;

    .line 50
    .line 51
    if-eqz v0, :cond_58

    .line 52
    .line 53
    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    :goto_41
    const/4 v7, 0x3

    if-ge v1, v0, :cond_58

    .line 58
    .line 59
    const/4 v7, 0x6

    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->R:Ljava/util/ArrayList;

    .line 60
    .line 61
    const/4 v7, 0x1

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    check-cast v2, Lz5h;

    .line 66
    .line 67
    if-eqz v2, :cond_53

    .line 68
    .line 69
    invoke-interface {v2, p1}, Lz5h;->c(I)V

    .line 70
    .line 71
    .line 72
    :cond_53
    const/4 v7, 0x1

    add-int/lit8 v1, v1, 0x1

    .line 73
    .line 74
    const/4 v7, 0x6

    goto :goto_41

    .line 75
    :cond_58
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->T:Lz5h;

    .line 76
    .line 77
    if-eqz p0, :cond_5f

    .line 78
    .line 79
    invoke-interface {p0, p1}, Lz5h;->c(I)V

    .line 80
    .line 81
    .line 82
    :cond_5f
    :goto_5f
    return-void
.end method

.method public final t(IIZZ)V
    .locals 11

    .line 1
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->j(I)Lx5h;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v10, 0x5

    const/4 v1, 0x0

    .line 6
    const/4 v10, 0x2

    if-eqz v0, :cond_24

    .line 7
    .line 8
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    int-to-float v2, v2

    .line 13
    const/4 v10, 0x6

    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->q:F

    .line 14
    .line 15
    const/4 v10, 0x5

    iget v0, v0, Lx5h;->e:F

    .line 16
    .line 17
    iget v4, p0, Landroidx/viewpager/widget/ViewPager;->r:F

    .line 18
    .line 19
    const/4 v10, 0x1

    invoke-static {v0, v4}, Ljava/lang/Math;->min(FF)F

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v3, v0}, Ljava/lang/Math;->max(FF)F

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    const/4 v10, 0x7

    mul-float/2addr v0, v2

    .line 28
    float-to-int v0, v0

    .line 29
    const/4 v10, 0x2

    goto :goto_26

    .line 30
    :cond_24
    const/4 v10, 0x0

    move v0, v1

    .line 31
    :goto_26
    if-eqz p3, :cond_ff

    .line 32
    .line 33
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 34
    .line 35
    .line 36
    move-result p3

    .line 37
    if-nez p3, :cond_33

    .line 38
    .line 39
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 40
    .line 41
    .line 42
    goto/16 :goto_f8

    .line 43
    .line 44
    :cond_33
    iget-object p3, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 45
    .line 46
    const/4 v10, 0x4

    if-eqz p3, :cond_5b

    .line 47
    .line 48
    const/4 v10, 0x1

    invoke-virtual {p3}, Landroid/widget/Scroller;->isFinished()Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    const/4 v10, 0x5

    if-nez v2, :cond_5b

    .line 53
    .line 54
    const/4 v10, 0x6

    iget-boolean v2, p0, Landroidx/viewpager/widget/ViewPager;->k:Z

    .line 55
    .line 56
    const/4 v10, 0x1

    if-eqz v2, :cond_4c

    .line 57
    .line 58
    const/4 v10, 0x6

    invoke-virtual {p3}, Landroid/widget/Scroller;->getCurrX()I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    goto :goto_51

    .line 63
    :cond_4c
    const/4 v10, 0x6

    invoke-virtual {p3}, Landroid/widget/Scroller;->getStartX()I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    :goto_51
    const/4 v10, 0x1

    invoke-virtual {p3}, Landroid/widget/Scroller;->abortAnimation()V

    .line 68
    .line 69
    .line 70
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 71
    .line 72
    .line 73
    :goto_58
    const/4 v10, 0x4

    move v4, v2

    .line 74
    goto :goto_61

    .line 75
    :cond_5b
    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    .line 76
    .line 77
    .line 78
    move-result v2

    .line 79
    const/4 v10, 0x4

    goto :goto_58

    .line 80
    :goto_61
    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    .line 81
    .line 82
    .line 83
    move-result v5

    .line 84
    const/4 v10, 0x2

    sub-int v6, v0, v4

    .line 85
    .line 86
    const/4 v10, 0x0

    rsub-int/lit8 v7, v5, 0x0

    .line 87
    .line 88
    const/4 v10, 0x1

    if-nez v6, :cond_7b

    .line 89
    .line 90
    const/4 v10, 0x4

    if-nez v7, :cond_7b

    .line 91
    .line 92
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->d(Z)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 96
    .line 97
    .line 98
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollState(I)V

    .line 99
    .line 100
    .line 101
    goto :goto_f8

    .line 102
    :cond_7b
    const/4 v10, 0x0

    const/4 p3, 0x1

    .line 103
    invoke-direct {p0, p3}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 104
    .line 105
    .line 106
    const/4 p3, 0x2

    .line 107
    invoke-virtual {p0, p3}, Landroidx/viewpager/widget/ViewPager;->setScrollState(I)V

    .line 108
    .line 109
    .line 110
    invoke-direct {p0}, Landroidx/viewpager/widget/ViewPager;->getClientWidth()I

    .line 111
    .line 112
    .line 113
    move-result p3

    .line 114
    div-int/lit8 v0, p3, 0x2

    .line 115
    .line 116
    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    const/4 v10, 0x7

    int-to-float v2, v2

    .line 121
    const/high16 v3, 0x3f800000    # 1.0f

    .line 122
    .line 123
    const/4 v10, 0x7

    mul-float/2addr v2, v3

    .line 124
    int-to-float p3, p3

    .line 125
    div-float/2addr v2, p3

    .line 126
    invoke-static {v3, v2}, Ljava/lang/Math;->min(FF)F

    .line 127
    .line 128
    .line 129
    move-result v2

    .line 130
    int-to-float v0, v0

    .line 131
    const/high16 v8, 0x3f000000    # 0.5f

    .line 132
    .line 133
    const/4 v10, 0x0

    sub-float/2addr v2, v8

    .line 134
    const v8, 0x3ef1463b

    .line 135
    .line 136
    .line 137
    mul-float/2addr v2, v8

    .line 138
    const/4 v10, 0x4

    float-to-double v8, v2

    .line 139
    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    .line 140
    .line 141
    .line 142
    move-result-wide v8

    .line 143
    double-to-float v2, v8

    .line 144
    mul-float/2addr v2, v0

    .line 145
    const/4 v10, 0x6

    add-float/2addr v2, v0

    .line 146
    const/4 v10, 0x0

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    .line 147
    .line 148
    .line 149
    move-result p2

    .line 150
    const/4 v10, 0x0

    if-lez p2, :cond_cb

    .line 151
    .line 152
    const/4 v10, 0x6

    int-to-float p2, p2

    .line 153
    const/4 v10, 0x1

    div-float/2addr v2, p2

    .line 154
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 155
    .line 156
    .line 157
    move-result p2

    .line 158
    const/4 v10, 0x6

    const/high16 p3, 0x447a0000    # 1000.0f

    .line 159
    .line 160
    mul-float/2addr p2, p3

    .line 161
    const/4 v10, 0x5

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 162
    .line 163
    .line 164
    move-result p2

    .line 165
    const/4 v10, 0x0

    mul-int/lit8 p2, p2, 0x4

    .line 166
    .line 167
    const/4 v10, 0x2

    goto :goto_e3

    .line 168
    :cond_cb
    const/4 v10, 0x2

    iget-object p2, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 169
    .line 170
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 171
    .line 172
    .line 173
    mul-float/2addr p3, v3

    .line 174
    const/4 v10, 0x5

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    .line 175
    .line 176
    .line 177
    move-result p2

    .line 178
    int-to-float p2, p2

    .line 179
    const/4 v10, 0x0

    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->m:I

    .line 180
    .line 181
    int-to-float v0, v0

    .line 182
    add-float/2addr p3, v0

    .line 183
    div-float/2addr p2, p3

    .line 184
    add-float/2addr p2, v3

    .line 185
    const/high16 p3, 0x42c80000    # 100.0f

    .line 186
    .line 187
    mul-float/2addr p2, p3

    .line 188
    float-to-int p2, p2

    .line 189
    :goto_e3
    const/16 p3, 0x258

    .line 190
    .line 191
    const/4 v10, 0x0

    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    .line 192
    .line 193
    .line 194
    move-result v8

    .line 195
    const/4 v10, 0x5

    iput-boolean v1, p0, Landroidx/viewpager/widget/ViewPager;->k:Z

    .line 196
    .line 197
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->j:Landroid/widget/Scroller;

    .line 198
    .line 199
    invoke-virtual/range {v3 .. v8}, Landroid/widget/Scroller;->startScroll(IIIII)V

    .line 200
    .line 201
    .line 202
    sget-object p2, Ln3h;->a:Ljava/util/WeakHashMap;

    .line 203
    .line 204
    const/4 v10, 0x3

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 205
    .line 206
    .line 207
    :goto_f8
    if-eqz p4, :cond_fe

    .line 208
    .line 209
    const/4 v10, 0x4

    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->f(I)V

    .line 210
    .line 211
    .line 212
    :cond_fe
    return-void

    .line 213
    :cond_ff
    if-eqz p4, :cond_104

    .line 214
    .line 215
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->f(I)V

    .line 216
    .line 217
    .line 218
    :cond_104
    invoke-virtual {p0, v1}, Landroidx/viewpager/widget/ViewPager;->d(Z)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {p0, v0, v1}, Landroid/view/View;->scrollTo(II)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {p0, v0}, Landroidx/viewpager/widget/ViewPager;->n(I)Z

    .line 225
    .line 226
    .line 227
    return-void
.end method

.method public final u(IIZZ)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_76

    .line 5
    .line 6
    invoke-virtual {v0}, Lnfb;->c()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-gtz v0, :cond_c

    .line 11
    .line 12
    goto :goto_76

    .line 13
    :cond_c
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b:Ljava/util/ArrayList;

    .line 14
    .line 15
    const/4 v5, 0x5

    if-nez p4, :cond_21

    .line 16
    .line 17
    const/4 v5, 0x5

    iget p4, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 18
    .line 19
    if-ne p4, p1, :cond_21

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 22
    .line 23
    .line 24
    move-result p4

    .line 25
    const/4 v5, 0x2

    if-eqz p4, :cond_21

    .line 26
    .line 27
    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_21
    const/4 v5, 0x7

    const/4 p4, 0x1

    .line 32
    if-gez p1, :cond_28

    .line 33
    .line 34
    const/4 v5, 0x6

    move p1, v1

    .line 35
    goto :goto_37

    .line 36
    :cond_28
    iget-object v2, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 37
    .line 38
    invoke-virtual {v2}, Lnfb;->c()I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-lt p1, v2, :cond_37

    .line 43
    .line 44
    iget-object p1, p0, Landroidx/viewpager/widget/ViewPager;->e:Lnfb;

    .line 45
    .line 46
    invoke-virtual {p1}, Lnfb;->c()I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    sub-int/2addr p1, p4

    .line 51
    :cond_37
    :goto_37
    iget v2, p0, Landroidx/viewpager/widget/ViewPager;->w:I

    .line 52
    .line 53
    iget v3, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 54
    .line 55
    const/4 v5, 0x5

    add-int v4, v3, v2

    .line 56
    .line 57
    if-gt p1, v4, :cond_43

    .line 58
    .line 59
    sub-int/2addr v3, v2

    .line 60
    if-ge p1, v3, :cond_58

    .line 61
    .line 62
    :cond_43
    move v2, v1

    move v2, v1

    .line 63
    :goto_45
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    const/4 v5, 0x7

    if-ge v2, v3, :cond_58

    .line 68
    .line 69
    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    check-cast v3, Lx5h;

    .line 74
    .line 75
    iput-boolean p4, v3, Lx5h;->c:Z

    .line 76
    .line 77
    add-int/lit8 v2, v2, 0x1

    .line 78
    .line 79
    goto :goto_45

    .line 80
    :cond_58
    const/4 v5, 0x3

    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 81
    .line 82
    const/4 v5, 0x2

    if-eq v0, p1, :cond_5f

    .line 83
    .line 84
    move v1, p4

    .line 85
    :cond_5f
    iget-boolean p4, p0, Landroidx/viewpager/widget/ViewPager;->O:Z

    .line 86
    .line 87
    if-eqz p4, :cond_6f

    .line 88
    .line 89
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->f:I

    .line 90
    .line 91
    const/4 v5, 0x0

    if-eqz v1, :cond_6b

    .line 92
    .line 93
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->f(I)V

    .line 94
    .line 95
    .line 96
    :cond_6b
    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_6f
    invoke-virtual {p0, p1}, Landroidx/viewpager/widget/ViewPager;->q(I)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {p0, p1, p2, p3, v1}, Landroidx/viewpager/widget/ViewPager;->t(IIZZ)V

    .line 104
    .line 105
    .line 106
    return-void

    .line 107
    :cond_76
    :goto_76
    const/4 v5, 0x7

    invoke-direct {p0, v1}, Landroidx/viewpager/widget/ViewPager;->setScrollingCacheEnabled(Z)V

    .line 108
    .line 109
    .line 110
    const/4 v5, 0x1

    return-void
.end method

.method public final v(Lde3;)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->V:Lde3;

    .line 2
    .line 3
    const/4 v2, 0x4

    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_8

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    goto :goto_b

    .line 8
    :cond_8
    const/4 v2, 0x1

    move v0, v1

    move v0, v1

    .line 9
    :goto_b
    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/viewpager/widget/ViewPager;->V:Lde3;

    .line 10
    .line 11
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->setChildrenDrawingOrderEnabled(Z)V

    .line 12
    .line 13
    .line 14
    const/4 p1, 0x2

    .line 15
    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->a0:I

    .line 16
    .line 17
    const/4 v2, 0x6

    iput p1, p0, Landroidx/viewpager/widget/ViewPager;->W:I

    .line 18
    .line 19
    if-eqz v0, :cond_1c

    .line 20
    .line 21
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->p()V

    .line 22
    .line 23
    .line 24
    :cond_1c
    const/4 v2, 0x1

    return-void
.end method

.method public final verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 2

    .line 1
    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x2

    if-nez v0, :cond_11

    .line 6
    .line 7
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->n:Landroid/graphics/drawable/Drawable;

    .line 8
    .line 9
    if-ne p1, p0, :cond_e

    .line 10
    .line 11
    const/4 v1, 0x5

    goto :goto_11

    .line 12
    :cond_e
    const/4 v1, 0x7

    const/4 p0, 0x0

    .line 13
    return p0

    .line 14
    :cond_11
    :goto_11
    const/4 p0, 0x1

    .line 15
    return p0
.end method

.method public final w()V
    .locals 5

    .line 1
    const/4 v4, 0x3

    iget v0, p0, Landroidx/viewpager/widget/ViewPager;->a0:I

    .line 2
    .line 3
    const/4 v4, 0x5

    if-eqz v0, :cond_34

    .line 4
    .line 5
    iget-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b0:Ljava/util/ArrayList;

    .line 6
    .line 7
    if-nez v0, :cond_14

    .line 8
    .line 9
    const/4 v4, 0x4

    new-instance v0, Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Landroidx/viewpager/widget/ViewPager;->b0:Ljava/util/ArrayList;

    .line 15
    .line 16
    const/4 v4, 0x2

    goto :goto_18

    .line 17
    :cond_14
    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 18
    .line 19
    .line 20
    :goto_18
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    const/4 v1, 0x0

    .line 25
    :goto_1d
    if-ge v1, v0, :cond_2c

    .line 26
    .line 27
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    iget-object v3, p0, Landroidx/viewpager/widget/ViewPager;->b0:Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    .line 37
    .line 38
    goto :goto_1d

    .line 39
    :cond_2c
    iget-object p0, p0, Landroidx/viewpager/widget/ViewPager;->b0:Ljava/util/ArrayList;

    .line 40
    .line 41
    const/4 v4, 0x0

    sget-object v0, Landroidx/viewpager/widget/ViewPager;->h0:Landroidx/viewpager/widget/b;

    .line 42
    .line 43
    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 44
    .line 45
    .line 46
    :cond_34
    return-void
.end method
