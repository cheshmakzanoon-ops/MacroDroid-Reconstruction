.class public final Loe3;
.super Landroid/database/DataSetObserver;
.source "r8-map-id-43b0b16dc0073b4b53e316177ca478d827b877826459072a6fdbad625fa2dd5f"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 1

    .line 1
    iput p2, p0, Loe3;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Loe3;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onChanged()V
    .locals 2

    .line 1
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Loe3;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Loe3;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_34

    .line 6
    .line 7
    .line 8
    check-cast p0, Landroidx/viewpager/widget/ViewPager;

    .line 9
    .line 10
    invoke-virtual {p0}, Landroidx/viewpager/widget/ViewPager;->e()V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_f
    const/4 v1, 0x7

    check-cast p0, Landroidx/appcompat/widget/ListPopupWindow;

    .line 15
    .line 16
    iget-object v0, p0, Landroidx/appcompat/widget/ListPopupWindow;->z:Landroid/widget/PopupWindow;

    .line 17
    .line 18
    const/4 v1, 0x4

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    const/4 v1, 0x3

    if-eqz v0, :cond_1f

    .line 23
    .line 24
    invoke-virtual {p0}, Landroidx/appcompat/widget/ListPopupWindow;->show()V

    .line 25
    .line 26
    .line 27
    :cond_1f
    const/4 v1, 0x1

    return-void

    .line 28
    :pswitch_21
    check-cast p0, Lagency/tango/materialintroscreen/widgets/InkPageIndicator;

    .line 29
    .line 30
    invoke-static {p0}, Lagency/tango/materialintroscreen/widgets/InkPageIndicator;->a(Lagency/tango/materialintroscreen/widgets/InkPageIndicator;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-static {p0, v0}, Lagency/tango/materialintroscreen/widgets/InkPageIndicator;->e(Lagency/tango/materialintroscreen/widgets/InkPageIndicator;I)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :pswitch_2b
    check-cast p0, Lpcf;

    .line 39
    .line 40
    const/4 v0, 0x1

    .line 41
    iput-boolean v0, p0, Lpe3;->a:Z

    .line 42
    .line 43
    invoke-virtual {p0}, Lpcf;->notifyDataSetChanged()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_2b
        :pswitch_21
        :pswitch_f
    .end packed-switch
.end method

.method public onInvalidated()V
    .locals 3

    .line 1
    iget v0, p0, Loe3;->a:I

    .line 2
    .line 3
    const/4 v2, 0x1

    iget-object v1, p0, Loe3;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_24

    .line 6
    .line 7
    .line 8
    :pswitch_8
    const/4 v2, 0x5

    invoke-super {p0}, Landroid/database/DataSetObserver;->onInvalidated()V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_d
    check-cast v1, Landroidx/viewpager/widget/ViewPager;

    .line 13
    .line 14
    invoke-virtual {v1}, Landroidx/viewpager/widget/ViewPager;->e()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_13
    check-cast v1, Landroidx/appcompat/widget/ListPopupWindow;

    .line 19
    .line 20
    invoke-virtual {v1}, Landroidx/appcompat/widget/ListPopupWindow;->dismiss()V

    .line 21
    .line 22
    .line 23
    const/4 v2, 0x6

    return-void

    .line 24
    :pswitch_1a
    check-cast v1, Lpcf;

    .line 25
    .line 26
    const/4 p0, 0x0

    move v2, p0

    .line 27
    iput-boolean p0, v1, Lpe3;->a:Z

    .line 28
    .line 29
    invoke-virtual {v1}, Lpcf;->notifyDataSetInvalidated()V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_8
        :pswitch_13
        :pswitch_d
    .end packed-switch
.end method
