.class public final Lt2h;
.super Ljava/lang/Object;
.source "r8-map-id-43b0b16dc0073b4b53e316177ca478d827b877826459072a6fdbad625fa2dd5f"

# interfaces
.implements Lz5h;


# instance fields
.field public final a:Lcre;

.field public final b:Ljava/util/ArrayList;

.field public final c:Ljava/util/ArrayList;

.field public final d:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Lcre;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x6

    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 v1, 0x4

    iput-object v0, p0, Lt2h;->b:Ljava/util/ArrayList;

    .line 10
    .line 11
    new-instance v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    const/4 v1, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lt2h;->c:Ljava/util/ArrayList;

    .line 17
    .line 18
    new-instance v0, Ljava/util/ArrayList;

    .line 19
    .line 20
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Lt2h;->d:Ljava/util/ArrayList;

    .line 24
    .line 25
    iput-object p1, p0, Lt2h;->a:Lcre;

    .line 26
    .line 27
    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final b(IFI)V
    .locals 8

    .line 1
    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 p3, 0x1

    .line 2
    const/4 v7, 0x6

    iget-object v0, p0, Lt2h;->c:Ljava/util/ArrayList;

    .line 3
    .line 4
    const/4 v7, 0x5

    if-nez p1, :cond_24

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    :goto_d
    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_65

    .line 15
    .line 16
    const/4 v7, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Lmra;

    .line 21
    .line 22
    iget-object v2, v1, Lmra;->b:Lip7;

    .line 23
    .line 24
    iget-object v1, v1, Lmra;->a:Landroid/view/View;

    .line 25
    .line 26
    invoke-interface {v2, p2, v1}, Lip7;->u(FLandroid/view/View;)V

    .line 27
    .line 28
    .line 29
    const/4 v7, 0x2

    goto :goto_d

    .line 30
    :cond_24
    const/4 v7, 0x2

    iget-object v1, p0, Lt2h;->a:Lcre;

    .line 31
    .line 32
    invoke-virtual {v1}, Lcre;->n()I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    const/4 v7, 0x5

    sub-int/2addr v1, p3

    .line 37
    const/4 v7, 0x4

    if-ne p1, v1, :cond_4c

    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    :goto_34
    const/4 v7, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    const/4 v7, 0x4

    if-eqz v1, :cond_65

    .line 48
    .line 49
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lmra;

    .line 54
    .line 55
    const/4 v7, 0x2

    iget-object v2, v1, Lmra;->c:Lip7;

    .line 56
    .line 57
    iget-object v1, v1, Lmra;->a:Landroid/view/View;

    .line 58
    .line 59
    invoke-interface {v2, p2, v1}, Lip7;->u(FLandroid/view/View;)V

    .line 60
    .line 61
    .line 62
    const/4 v7, 0x3

    goto :goto_34

    .line 63
    :cond_4c
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    :goto_50
    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    if-eqz v1, :cond_65

    .line 72
    .line 73
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    check-cast v1, Lmra;

    .line 78
    .line 79
    iget-object v2, v1, Lmra;->d:Lip7;

    .line 80
    .line 81
    iget-object v1, v1, Lmra;->a:Landroid/view/View;

    .line 82
    .line 83
    invoke-interface {v2, p2, v1}, Lip7;->u(FLandroid/view/View;)V

    .line 84
    .line 85
    .line 86
    goto :goto_50

    .line 87
    :cond_65
    iget-object p0, p0, Lt2h;->d:Ljava/util/ArrayList;

    .line 88
    .line 89
    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    :cond_6b
    :goto_6b
    const/4 v7, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-eqz v0, :cond_1d7

    .line 98
    .line 99
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    const/4 v7, 0x6

    check-cast v0, Lty9;

    .line 104
    .line 105
    const/4 v7, 0x3

    iget v1, v0, Lty9;->a:I

    .line 106
    .line 107
    packed-switch v1, :pswitch_data_1d8

    .line 108
    .line 109
    .line 110
    const/4 v7, 0x2

    iget-object v0, v0, Lty9;->b:Ljava/lang/Object;

    .line 111
    .line 112
    const/4 v7, 0x6

    check-cast v0, Lcre;

    .line 113
    .line 114
    invoke-virtual {v0}, Lcre;->n()I

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-eq p1, v1, :cond_6b

    .line 119
    .line 120
    invoke-virtual {v0, p1}, Lcre;->m(I)Lxpe;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    invoke-virtual {v0}, Lcre;->n()I

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    const/4 v7, 0x6

    sub-int/2addr v2, p3

    .line 129
    if-ge p1, v2, :cond_a0

    .line 130
    .line 131
    const/4 v7, 0x5

    add-int/lit8 v2, p1, 0x1

    .line 132
    .line 133
    invoke-virtual {v0, v2}, Lcre;->m(I)Lxpe;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    const/4 v7, 0x0

    goto :goto_a2

    .line 138
    :cond_a0
    const/4 v7, 0x7

    const/4 v0, 0x0

    .line 139
    :goto_a2
    if-eqz v1, :cond_a7

    .line 140
    .line 141
    invoke-virtual {v1, p2}, Lqib;->setOffset(F)V

    .line 142
    .line 143
    .line 144
    :cond_a7
    if-eqz v0, :cond_6b

    .line 145
    .line 146
    const/4 v7, 0x0

    if-eqz v1, :cond_6b

    .line 147
    .line 148
    const/high16 v1, 0x3f800000    # 1.0f

    .line 149
    .line 150
    sub-float v1, p2, v1

    .line 151
    .line 152
    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Lqib;->setOffset(F)V

    .line 153
    .line 154
    .line 155
    goto :goto_6b

    .line 156
    :pswitch_b5
    iget-object v1, v0, Lty9;->b:Ljava/lang/Object;

    .line 157
    .line 158
    check-cast v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;

    .line 159
    .line 160
    iget-object v2, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 161
    .line 162
    iget-object v2, v2, Lcre;->i:Ljava/util/ArrayList;

    .line 163
    .line 164
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    const/4 v7, 0x6

    sub-int/2addr v2, p3

    .line 169
    const/4 v7, 0x0

    if-ge p1, v2, :cond_180

    .line 170
    .line 171
    sget v2, Lagency/tango/materialintroscreen/MaterialIntroActivity;->A:I

    .line 172
    .line 173
    const/4 v7, 0x2

    iget-object v2, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->s:Landroid/animation/ArgbEvaluator;

    .line 174
    .line 175
    iget-object v3, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 176
    .line 177
    invoke-virtual {v3, p1}, Lcre;->m(I)Lxpe;

    .line 178
    .line 179
    .line 180
    move-result-object v3

    .line 181
    invoke-virtual {v3}, Lxpe;->n()I

    .line 182
    .line 183
    .line 184
    move-result v3

    .line 185
    const/4 v7, 0x4

    invoke-static {v1, v3}, Lw63;->getColor(Landroid/content/Context;I)I

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 190
    .line 191
    .line 192
    move-result-object v3

    .line 193
    const/4 v7, 0x0

    iget-object v4, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 194
    .line 195
    add-int/lit8 v5, p1, 0x1

    .line 196
    .line 197
    invoke-virtual {v4, v5}, Lcre;->m(I)Lxpe;

    .line 198
    .line 199
    .line 200
    move-result-object v4

    .line 201
    invoke-virtual {v4}, Lxpe;->n()I

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    invoke-static {v1, v4}, Lw63;->getColor(Landroid/content/Context;I)I

    .line 206
    .line 207
    .line 208
    move-result v4

    .line 209
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 210
    .line 211
    .line 212
    move-result-object v4

    .line 213
    const/4 v7, 0x3

    invoke-virtual {v2, p2, v3, v4}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 214
    .line 215
    .line 216
    move-result-object v3

    .line 217
    check-cast v3, Ljava/lang/Integer;

    .line 218
    .line 219
    const/4 v7, 0x0

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 220
    .line 221
    .line 222
    move-result v3

    .line 223
    const/4 v7, 0x1

    iget-object v4, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->j:Lagency/tango/materialintroscreen/widgets/SwipeableViewPager;

    .line 224
    .line 225
    invoke-virtual {v4, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 226
    .line 227
    .line 228
    iget-object v4, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->q:Landroid/widget/Button;

    .line 229
    .line 230
    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 231
    .line 232
    .line 233
    iget-object v3, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 234
    .line 235
    invoke-virtual {v3, p1}, Lcre;->m(I)Lxpe;

    .line 236
    .line 237
    .line 238
    move-result-object v3

    .line 239
    const/4 v7, 0x5

    invoke-virtual {v3}, Lxpe;->o()I

    .line 240
    .line 241
    .line 242
    move-result v3

    .line 243
    invoke-static {v1, v3}, Lw63;->getColor(Landroid/content/Context;I)I

    .line 244
    .line 245
    .line 246
    move-result v3

    .line 247
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 248
    .line 249
    .line 250
    move-result-object v3

    .line 251
    iget-object v4, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 252
    .line 253
    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Lcre;->m(I)Lxpe;

    .line 254
    .line 255
    .line 256
    move-result-object v4

    .line 257
    const/4 v7, 0x2

    invoke-virtual {v4}, Lxpe;->o()I

    .line 258
    .line 259
    .line 260
    move-result v4

    .line 261
    invoke-static {v1, v4}, Lw63;->getColor(Landroid/content/Context;I)I

    .line 262
    .line 263
    .line 264
    move-result v4

    .line 265
    const/4 v7, 0x4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 266
    .line 267
    .line 268
    move-result-object v4

    .line 269
    const/4 v7, 0x4

    invoke-virtual {v2, p2, v3, v4}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v3

    .line 273
    check-cast v3, Ljava/lang/Integer;

    .line 274
    .line 275
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 276
    .line 277
    .line 278
    move-result v3

    .line 279
    const/4 v7, 0x5

    iget-object v4, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 280
    .line 281
    invoke-virtual {v4, p1}, Lcre;->m(I)Lxpe;

    .line 282
    .line 283
    .line 284
    move-result-object v4

    .line 285
    const/4 v7, 0x2

    invoke-virtual {v4}, Lxpe;->p()I

    .line 286
    .line 287
    .line 288
    move-result v4

    .line 289
    invoke-static {v1, v4}, Lw63;->getColor(Landroid/content/Context;I)I

    .line 290
    .line 291
    .line 292
    move-result v4

    .line 293
    const/4 v7, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 294
    .line 295
    .line 296
    move-result-object v4

    .line 297
    const/4 v7, 0x6

    iget-object v6, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 298
    .line 299
    invoke-virtual {v6, v5}, Lcre;->m(I)Lxpe;

    .line 300
    .line 301
    .line 302
    move-result-object v5

    .line 303
    invoke-virtual {v5}, Lxpe;->o()I

    .line 304
    .line 305
    .line 306
    move-result v5

    .line 307
    invoke-static {v1, v5}, Lw63;->getColor(Landroid/content/Context;I)I

    .line 308
    .line 309
    .line 310
    move-result v5

    .line 311
    const/4 v7, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 312
    .line 313
    .line 314
    move-result-object v5

    .line 315
    invoke-virtual {v2, p2, v4, v5}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v2

    .line 319
    check-cast v2, Ljava/lang/Integer;

    .line 320
    .line 321
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 322
    .line 323
    .line 324
    move-result v2

    .line 325
    iget-object v1, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->k:Lagency/tango/materialintroscreen/widgets/InkPageIndicator;

    .line 326
    .line 327
    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Lagency/tango/materialintroscreen/widgets/InkPageIndicator;->setPageIndicatorColor(I)V

    .line 328
    .line 329
    .line 330
    const/4 v7, 0x4

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    invoke-virtual {v0, v1}, Lty9;->a(Landroid/content/res/ColorStateList;)V

    .line 335
    .line 336
    .line 337
    goto/16 :goto_6b

    .line 338
    .line 339
    :cond_180
    iget-object v2, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 340
    .line 341
    iget-object v2, v2, Lcre;->i:Ljava/util/ArrayList;

    .line 342
    .line 343
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 344
    .line 345
    .line 346
    move-result v2

    .line 347
    const/4 v7, 0x7

    if-ne v2, p3, :cond_6b

    .line 348
    .line 349
    iget-object v2, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->j:Lagency/tango/materialintroscreen/widgets/SwipeableViewPager;

    .line 350
    .line 351
    const/4 v7, 0x5

    iget-object v3, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 352
    .line 353
    invoke-virtual {v3, p1}, Lcre;->m(I)Lxpe;

    .line 354
    .line 355
    .line 356
    move-result-object v3

    .line 357
    const/4 v7, 0x6

    invoke-virtual {v3}, Lxpe;->n()I

    .line 358
    .line 359
    .line 360
    move-result v3

    .line 361
    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 362
    .line 363
    .line 364
    const/4 v7, 0x1

    iget-object v2, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->q:Landroid/widget/Button;

    .line 365
    .line 366
    iget-object v3, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 367
    .line 368
    invoke-virtual {v3, p1}, Lcre;->m(I)Lxpe;

    .line 369
    .line 370
    .line 371
    move-result-object v3

    .line 372
    invoke-virtual {v3}, Lxpe;->n()I

    .line 373
    .line 374
    .line 375
    move-result v3

    .line 376
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 377
    .line 378
    .line 379
    iget-object v1, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->l:Lcre;

    .line 380
    .line 381
    invoke-virtual {v1, p1}, Lcre;->m(I)Lxpe;

    .line 382
    .line 383
    .line 384
    move-result-object v1

    .line 385
    const/4 v7, 0x0

    invoke-virtual {v1}, Lxpe;->o()I

    .line 386
    .line 387
    .line 388
    move-result v1

    .line 389
    const/4 v7, 0x4

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 390
    .line 391
    .line 392
    move-result-object v1

    .line 393
    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Lty9;->a(Landroid/content/res/ColorStateList;)V

    .line 394
    .line 395
    .line 396
    goto/16 :goto_6b

    .line 397
    .line 398
    :pswitch_1c2
    const/4 v7, 0x4

    iget-object v1, v0, Lty9;->b:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;

    .line 401
    .line 402
    const/4 v7, 0x7

    iget-object v1, v1, Lagency/tango/materialintroscreen/MaterialIntroActivity;->j:Lagency/tango/materialintroscreen/widgets/SwipeableViewPager;

    .line 403
    .line 404
    new-instance v2, Llt1;

    .line 405
    .line 406
    const/4 v7, 0x7

    const/4 v3, 0x4

    .line 407
    invoke-direct {v2, v0, p1, v3}, Llt1;-><init>(Ljava/lang/Object;II)V

    .line 408
    .line 409
    .line 410
    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 411
    .line 412
    .line 413
    const/4 v7, 0x5

    goto/16 :goto_6b

    .line 414
    .line 415
    :cond_1d7
    return-void

    .line 416
    .line 417
    :pswitch_data_1d8
    .packed-switch 0x0
        :pswitch_1c2
        :pswitch_b5
    .end packed-switch
.end method

.method public final c(I)V
    .locals 1

    .line 1
    return-void
.end method

.method public final d(I)V
    .locals 2

    .line 1
    iget-object p0, p0, Lt2h;->b:Ljava/util/ArrayList;

    .line 2
    .line 3
    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    :goto_7
    const/4 v1, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1b

    .line 12
    .line 13
    const/4 v1, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const/4 v1, 0x1

    check-cast v0, Lln7;

    .line 18
    .line 19
    const/4 v1, 0x7

    invoke-interface {v0, p1}, Lln7;->a(I)V

    .line 20
    .line 21
    .line 22
    goto :goto_7

    .line 23
    :cond_1b
    return-void
.end method
