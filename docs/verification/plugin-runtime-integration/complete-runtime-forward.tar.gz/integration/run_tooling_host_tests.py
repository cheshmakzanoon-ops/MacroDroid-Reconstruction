#!/usr/bin/env python3
"""Hash-copy the repository tools, overlay the frozen runtime slice, and test.

Only the private temporary copy is executed. This is a host integration check;
it does not start an emulator or provide Android runtime evidence.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile

CHECKPOINT_SHA256 = '4587be10a5ef1a6df2e3794762144da6729b8817c325cf0313f2bf78fb490b0f'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, stage, output = args.repo.resolve(), args.stage.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    checkpoint = stage / 'reports/runtime-tools-checkpoint.json'
    if digest(checkpoint) != CHECKPOINT_SHA256:
        raise ValueError('Frozen runtime checkpoint changed')
    manifest = json.loads(checkpoint.read_text())
    for item in manifest['files']:
        path = stage / item['path']
        if path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
            raise ValueError('Frozen runtime file changed: ' + item['path'])
    selected = [item for item in manifest['files'] if not item['path'].startswith('reports/')]
    if len(selected) != 8:
        raise ValueError('Expected exactly the frozen eight tool/workflow entries')
    report = {
        'status': 'INCOMPLETE', 'started_utc': datetime.now(timezone.utc).isoformat(),
        'checkpoint_sha256': CHECKPOINT_SHA256, 'repository': str(repo),
        'python_version': sys.version, 'base_files': [], 'fixture_files': [],
        'overlaid_files': [], 'frozen_checkpoint_unchanged': False,
        'android_runtime_executed': False, 'full_runtime_1_to_1_established': False,
    }

    with tempfile.TemporaryDirectory(prefix='macrodroid-tooling-integration-', dir='/tmp') as temporary:
        private = Path(temporary)
        report['private_copy'] = str(private)

        def copy_file(source, target, relative):
            if source.is_symlink() or not source.is_file():
                raise ValueError('Unexpected input type: ' + str(source))
            data = source.read_bytes()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            item = {'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            if target.stat().st_size != item['bytes'] or digest(target) != item['sha256']:
                raise ValueError('Copied bytes differ: ' + relative)
            return item

        for source in sorted((repo / 'tools/android').rglob('*')):
            if source.is_dir():
                continue
            relative = str(source.relative_to(repo))
            report['base_files'].append(copy_file(source, private / relative, relative))
        fixtures = repo / 'docs/verification/android-ci-bebf448/capture-device'
        for source in sorted(fixtures.rglob('*')):
            if source.is_dir():
                continue
            relative = str(source.relative_to(repo))
            report['fixture_files'].append(copy_file(source, private / relative, relative))
        for item in selected:
            copied = copy_file(stage / item['path'], private / item['path'], item['path'])
            if copied != item:
                raise ValueError('Overlay differs from frozen identity: ' + item['path'])
            report['overlaid_files'].append(copied)
        command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tools/android', '-p', 'test_*.py', '-v']
        report['command'] = command
        run = subprocess.run(command, cwd=private, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             check=False, timeout=120)
        log = output / 'tooling-host-integration.log'
        log.write_bytes(run.stdout)
        match = re.search(rb'Ran (\d+) tests in ([0-9.]+)s', run.stdout)
        report.update(exit_code=run.returncode, tests_run=int(match[1]) if match else None,
                      reported_test_seconds=float(match[2]) if match else None,
                      log={'path': log.name, 'bytes': len(run.stdout), 'sha256': digest(log)})
        report['status'] = ('ALL_27_TOOLING_HOST_TESTS_PASSED' if run.returncode == 0 and report['tests_run'] == 27
                            else 'TOOLING_HOST_INTEGRATION_FAILED')
    report['private_copy_removed'] = not Path(report['private_copy']).exists()
    report['frozen_checkpoint_unchanged'] = (digest(checkpoint) == CHECKPOINT_SHA256 and
        all((stage / item['path']).stat().st_size == item['bytes'] and digest(stage / item['path']) == item['sha256']
            for item in manifest['files']))
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (output / 'tooling-host-integration.json').write_text(json.dumps(report, indent=2) + '\n')
    sys.stdout.buffer.write(run.stdout)
    print(json.dumps({key: report[key] for key in ['status', 'exit_code', 'tests_run',
        'private_copy_removed', 'frozen_checkpoint_unchanged']}, indent=2))
    return 0 if report['status'] == 'ALL_27_TOOLING_HOST_TESTS_PASSED' and report['frozen_checkpoint_unchanged'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
